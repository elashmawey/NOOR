import express from 'express';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import crypto from 'crypto';
import https from 'https';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(express.json());

// Initialize Gemini API with modern @google/genai SDK
const apiKey = process.env.GEMINI_API_KEY || '';
const ai = apiKey ? new GoogleGenAI({ apiKey }) : null;

// Endpoint: Explain a word or everyday Egyptian text for adult learners
app.post('/api/gemini/explain-word', async (req, res) => {
  try {
    const { word, category } = req.body;
    if (!word) {
      return res.status(400).json({ error: 'الرجاء إدخال الكلمة' });
    }

    if (!ai) {
      // Return a rich, warm, helpful fallback response if no key is set yet
      return res.json({
        word,
        spelling: word.split('').join(' - '),
        meaning: `كلمة "${word}" كلمة دارجة ومهمة في حياتنا اليومية بمصر.`,
        example: `شفت كلمة "${word}" مكتوبة بخط واضح في الشارع أو على اليافطة.`,
        tip: 'احفظ شكل الحرف الأول وكرر قراءتها بصوت عالي مرتين وثلاثة، الشطارة بتيجي بالممارسة!'
      });
    }

    const prompt = `
أنت "عم صلاح"، معلم مصري خبير وصبور ومحبوب في فصول محو الأمية في مصر.
المتعلم شخص بالغ يتعلم القراءة والكتابة، يحتاج تشجيعاً كبيراً وأسلوباً مصرياً بسيطاً ودافئاً ومحترماً جداً.

المطلوب:
اشرح الكلمة التالية: "${word}" (في سياق: ${category || 'الحياة اليومية في مصر'})

أجب بصيغة JSON فقط بهذا الشكل:
{
  "word": "${word}",
  "spelling": "الحروف مفصولة بشرطة مثل: ش - م - س",
  "meaning": "شرح بسيط جدا ومفهوم لمعنى الكلمة في سطر واحد بالعامية المصرية الودودة",
  "example": "موقف يومي مصري واقعي يظهر فيه استخدام هذه الكلمة (مثلاً في السوق، الميكروباص، الدواء، البنك)",
  "tip": "نصيحة ذهبية قصيرة ومحفزة من عم صلاح للمتعلم لحفظ الكلمة وقراءتها بسهولة"
}
`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const text = response.text || '{}';
    const parsed = JSON.parse(text);
    return res.json(parsed);
  } catch (error: any) {
    console.error('Gemini error:', error);
    return res.status(500).json({
      error: 'حدث عطل في الاتصال، حاول مرة أخرى',
      fallback: true,
    });
  }
});

// Endpoint: Ask Teacher "عم صلاح" anything
app.post('/api/gemini/ask-teacher', async (req, res) => {
  try {
    const { question } = req.body;
    if (!question) {
      return res.status(400).json({ error: 'الرجاء إدخال السؤال' });
    }

    if (!ai) {
      return res.json({
        reply: `أهلاً بيك يا بطل! سؤالك ممتاز. الخطوة الأولى في تعلم القراءة والكتابة هي الصبر وتكرار نطق الحروف بصوت عالي. اسمع نطق الحروف في التطبيق ودرب إيدك على السبورة التفاعلية، ومع الأيام هتلاقي نفسك بتقرأ كل يافطة في الشارع بكل فخر!`,
        suggestedPractice: 'جرب تتدرب على كتابة حروف اسمك على سبورة التوقيع في التطبيق.'
      });
    }

    const prompt = `
أنت "عم صلاح"، معلم محو الأمية المصري الحنون والصبور والداعم في منصة "نور".
تخاطب مواطناً مصرياً عزيزاً يخطو خطواته الأولى في القراءة والكتابة.
تحدث بالعامية المصرية المهذبة والمشجعة المليئة بالدفء ("يا غالي"، "يا بطل"، "الله ينور عليك"، "خطوة بخطوة").

سؤال المتعلم: "${question}"

اكتب الرد بصيغة JSON فقط:
{
  "reply": "إجابة عم صلاح بالعامية المصرية الواضحة والمشجعة، لا تزيد عن 3 أو 4 أسطر قصيرة وواضحة جدا",
  "suggestedPractice": "اقتراح تدريب عملي وسهل ينفذه المتعلم فوراً"
}
`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const parsed = JSON.parse(response.text || '{}');
    return res.json(parsed);
  } catch (error: any) {
    console.error('Teacher chat error:', error);
    return res.status(500).json({
      reply: 'يا غالي، خليك دايماً واثق في نفسك. القراءة والكتابة مفتاح نور لحياتك، وكل حرف بتتعلمه بيبني مستقبلك.',
      suggestedPractice: 'راجع حروف المستوى الأول واضغط على زر السماعة لسماع نطقها.'
    });
  }
});

// Server-side in-memory cache and persistent disk cache
const ttsCache = new Map<string, string>();
let ttsCooldownUntil = 0;
const AUDIO_CACHE_DIR = path.join(__dirname, 'public', 'audio', 'cache');

// Ensure cache directory exists
if (!fs.existsSync(AUDIO_CACHE_DIR)) {
  fs.mkdirSync(AUDIO_CACHE_DIR, { recursive: true });
}

function getAudioHash(text: string): string {
  return crypto.createHash('md5').update(text.trim()).digest('hex');
}

// Helper: Fetch audio from Lovable Egyptian Voice Gateway
async function fetchFromUpstreamVoice(text: string, voiceName: string): Promise<string | null> {
  return new Promise((resolve) => {
    try {
      const postData = JSON.stringify({ text, voiceName });
      const req = https.request('https://project-archive-transit.lovable.app/api/voice/tts', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(postData),
        },
        timeout: 10000,
      }, (res) => {
        let data = '';
        res.on('data', (chunk) => { data += chunk; });
        res.on('end', () => {
          try {
            const parsed = JSON.parse(data);
            if (parsed.audioBase64) {
              resolve(parsed.audioBase64);
            } else {
              resolve(null);
            }
          } catch {
            resolve(null);
          }
        });
      });

      req.on('error', () => resolve(null));
      req.on('timeout', () => {
        req.destroy();
        resolve(null);
      });
      req.write(postData);
      req.end();
    } catch {
      resolve(null);
    }
  });
}

// Endpoint: Generate authentic Egyptian colloquial speech with multi-layered fallback
app.post('/api/voice/tts', async (req, res) => {
  try {
    const { text, voiceName = 'Puck' } = req.body;
    if (!text || typeof text !== 'string') {
      return res.status(400).json({ error: 'نص الصوت مطلوب' });
    }

    const cleanText = text.normalize('NFC').trim().replace(/\s+/g, ' ');
    if (!cleanText) {
      return res.json({ fallback: true });
    }

    const cacheKey = `${voiceName}_${cleanText}`;
    const hash = getAudioHash(cleanText);
    const diskPath = path.join(AUDIO_CACHE_DIR, `${voiceName}_${hash}.wav`);

    // 1. Check in-memory server cache
    if (ttsCache.has(cacheKey)) {
      return res.json({
        audioBase64: ttsCache.get(cacheKey),
        format: 'audio/wav',
        text: cleanText,
        cached: true,
      });
    }

    // 2. Check disk cache
    if (fs.existsSync(diskPath)) {
      try {
        const fileData = fs.readFileSync(diskPath);
        const base64 = fileData.toString('base64');
        ttsCache.set(cacheKey, base64);
        return res.json({
          audioBase64: base64,
          format: 'audio/wav',
          text: cleanText,
          cached: true,
        });
      } catch (err) {
        console.warn('Failed to read from disk cache:', err);
      }
    }

    let base64Audio: string | null = null;

    // 3. Try Gemini TTS if available and not on cooldown
    if (ai && Date.now() >= ttsCooldownUntil) {
      try {
        const response = await ai.models.generateContent({
          model: 'gemini-3.8-flash-lite-tts',
          contents: [
            {
              role: 'user',
              parts: [
                {
                  text: cleanText,
                  speechMetadata: {
                    style: 'Warm, encouraging, natural Egyptian Arabic speaker named Om Salah speaking to an adult learner in Egypt',
                  },
                },
              ],
            },
          ],
          config: {
            responseModalities: ['AUDIO'],
            speechConfig: {
              voiceConfig: {
                prebuiltVoiceConfig: { voiceName: voiceName || 'Puck' },
              },
            },
          },
        });

        const data = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
        if (data) {
          base64Audio = data;
        }
      } catch (error: any) {
        const errMsg = error?.message || String(error);
        if (errMsg.includes('429') || errMsg.includes('RESOURCE_EXHAUSTED')) {
          ttsCooldownUntil = Date.now() + 60000;
          console.warn('Gemini TTS rate limited, seamlessly routing to authentic Egyptian voice gateway.');
        } else {
          console.warn('Gemini TTS error, checking fallback gateway:', errMsg);
        }
      }
    }

    // 4. Try Upstream Egyptian Voice Gateway (Lovable Reference Backend)
    if (!base64Audio) {
      base64Audio = await fetchFromUpstreamVoice(cleanText, voiceName);
    }

    // If audio was produced, cache to memory and disk!
    if (base64Audio) {
      ttsCache.set(cacheKey, base64Audio);
      try {
        fs.writeFileSync(diskPath, Buffer.from(base64Audio, 'base64'));
      } catch (err) {
        console.warn('Could not write audio to disk cache:', err);
      }
      return res.json({
        audioBase64: base64Audio,
        format: 'audio/wav',
        text: cleanText,
      });
    }

    return res.json({ fallback: true });
  } catch (error: any) {
    console.error('TTS endpoint error:', error);
    return res.json({ fallback: true });
  }
});

// Endpoint: Convert text into vocalized Egyptian colloquial Arabic
app.post('/api/voice/egyptianize', async (req, res) => {
  try {
    const { text } = req.body;
    if (!text) return res.status(400).json({ error: 'Text required' });

    if (!ai) {
      return res.json({ egyptianText: text });
    }

    const prompt = `
حوّل الجملة التالية إلى لهجة عامية مصرية محببة وواضحة جداً ومشجعة، مع تشكيل الحروف تشكيلاً مصرياً صوتياً دقيقاً، لكي ينطقها محرك الصوت كمعلم مصري أصيل ("عم صلاح") يشجع دارساً مصرياً بالغاً في فصول محو الأمية.

الجملة الأصلية: "${text}"

أجب فقط بالنص المصري المشكّل في سطر واحد بدون أي تعليقات أو علامات ترقيم زائدة.
`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
    });

    const egyptianText = response.text?.trim() || text;
    return res.json({ egyptianText });
  } catch (e: any) {
    return res.json({ egyptianText: req.body.text });
  }
});

// Endpoint: Generate dynamic everyday practice
app.post('/api/gemini/generate-practice', async (req, res) => {
  try {
    const { topic } = req.body; // e.g. "market", "transport", "health", "bank"

    if (!ai) {
      return res.json({
        scenario: 'ركوب ميكروباص من ميدان الجيزة',
        signText: 'ميدان التحرير',
        question: 'الميكروباص ده رايح فين؟',
        options: ['التحرير', 'رمسيس', 'المعادي', 'مدينة نصر'],
        correctIndex: 0,
        explanation: 'الكلمة الأولى هي "ميدان" وتبدأ بحرف الميم، والكلمة الثانية "التحرير" وتبدأ بألف ولام ثم تاء وحاء.'
      });
    }

    const prompt = `
أنت تضع سؤالاً تفاعلياً لدارس محو أمية مصري بالغ.
الموضوع المختار: ${topic || 'المواصلات ويافطات الشارع'}.
المطلوب سؤال من واقع الحياة اليومية المصرية الملموسة (مثل قراءة لافتة ميكروباص، علبة دواء، رسالة موبايل، أو كارت شحن).
اللغة واضحة وبسيطة.

أجب بـ JSON فقط:
{
  "scenario": "وصف الموقف الواقعي في سطر واحد (مثال: يافطة أوتوبيس في محطة رمسيس)",
  "signText": "النص المكتوب على اليافطة أو الرسالة بوضوح",
  "question": "السؤال الموجه للمتعلم",
  "options": ["الخيار الأول", "الخيار الثاني", "الخيار الثالث", "الخيار الرابع"],
  "correctIndex": 0,
  "explanation": "شرح لطيف كيف يتهجى الدارس الكلمة الصحيحة بحروفها"
}
`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const parsed = JSON.parse(response.text || '{}');
    return res.json(parsed);
  } catch (error: any) {
    console.error('Practice gen error:', error);
    return res.json({
      scenario: 'يافطة محل في السوق',
      signText: 'مخبز بلدي',
      question: 'المحل ده بيبيع إيه؟',
      options: ['عيش وخبز', 'دواء وعلاج', 'خضار وفاكهة', 'لحوم وجزارة'],
      correctIndex: 0,
      explanation: 'كلمة "مخبز" مشتقة من الخَبْز، والعيش هو الخبز البلدي المصري.'
    });
  }
});

// Port and Vite middleware configuration
const PORT = 3000;

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    // In production serve dist directory
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
