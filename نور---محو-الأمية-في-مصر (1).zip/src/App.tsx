/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { AlphabetSection } from './components/AlphabetSection';
import { WordsSection } from './components/WordsSection';
import { NumbersSection } from './components/NumbersSection';
import { LifeSituationsSection } from './components/LifeSituationsSection';
import { TracingCanvas } from './components/TracingCanvas';
import { TeacherOmSalah } from './components/TeacherOmSalah';
import { QuizSection } from './components/QuizSection';
import { CertificateModal } from './components/CertificateModal';
import { audioService } from './utils/audio';
import { Volume2, PhoneCall, Award, Heart, HelpCircle, Sparkles } from 'lucide-react';

import { PhonicsLaboratory } from './components/PhonicsLaboratory';
import { MasterAudioPlayer } from './components/MasterAudioPlayer';
import { OfficialDossierSection } from './components/OfficialDossierSection';
import { OfficialExamSection } from './components/OfficialExamSection';
import { AdultLifeSimulator } from './components/AdultLifeSimulator';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('alphabet');
  const [audioEnabled, setAudioEnabled] = useState<boolean>(true);
  const [fontSize, setFontSize] = useState<'normal' | 'large' | 'huge'>('normal');
  const [isCertificateOpen, setIsCertificateOpen] = useState<boolean>(false);
  const [tracingLetter, setTracingLetter] = useState<string>('أ');

  // Welcome greeting on mount
  useEffect(() => {
    const timer = setTimeout(() => {
      audioService.playSound('pop');
      audioService.speak('أهلاً بيك في منصة نور لمحو الأمية بمصر! القراءة والكتابة سهلة وخطوة بخطوة هتنور طريقك.');
    }, 800);
    return () => clearTimeout(timer);
  }, []);

  const handleSelectLetterForCanvas = (letter: string) => {
    setTracingLetter(letter);
    setActiveTab('canvas');
  };

  const playTabGuide = () => {
    const guides: Record<string, string> = {
      alphabet: 'يا هلا بيك في قسم الحروف! هنا تمانية وعشرين حرف، اضغط على أي حرف عشان تسمع صوته بالتشكيل، وتتعلم ترسمه خطوة بخطوة.',
      'phonics-lab': 'أهلاً بيك في معمل أسرار القرائية! هنا هتفك لغز النقط بين الباء والتاء والثاء، وتتعلم سر قراءة أي يافطة في الشارع بتبدأ بألف ولام.',
      words: 'يا بطل، ده قسم تكوين الكلمات! ركب الحروف جنب بعض، واكتب أي كلمة مصرية تحب نفككها ونشرحها لك بالصوت.',
      numbers: 'ده قسم الفلوس والأرقام المصرية! اتعرف على كل فئات الجنيه المصري، ودرب نفسك على حساب الباقي في السوق عشان محدش يضحك عليك.',
      life: 'ده قسم مواقف الشارع! اتعلم تقرأ يافطة الميكروباص ومحطة المترو، وتفهم مواعيد الدواء وتاريخ الصلاحية، وتحافظ على سر بطاقتك وفودافون كاش.',
      simulator: 'ده محاكي المعاملات الحياتية! اتدرب على سحب فلوسك من ماكينة الصراف الآلي ATM بنفسك، واقرأ فواتير الكهرباء والمياه ورسائل المعاش، واتدرب على ملء الاستمارات الرسمية، وامشي في خطة التحدي تلاتين يوم.',
      canvas: 'هنا سبورتك الخاصة! درب إيدك ومسكة القلم، وتتبع رسم الحروف، واتعلم تمضي اسمك بخط جميل للأوراق الرسمية.',
      teacher: 'معاك عم صلاح، اسألني في أي حاجة محيرانك وهرد عليك بالصوت فوراً وبكل صبر ومحبة.',
      quiz: 'ده وقت التحدي! جاوب على الأسئلة واكسب نجوم عشان تاخد شهادة التقدير الرسمية باسمك وتفرح بيها حبايبك.',
      exam: 'ده الامتحان الوطني المعتمد للهيئة العامة لتعليم الكبار! فيه قراءة وظيفية وإملاء وتوقيع بالاسم وحساب يومي، وهتاخد استمارة نجاح رسمية مؤقتة بكود تحقق.',
      dossier: 'ده ملف العرض والاعتماد الرسمي الموجه للهيئات الحكومية ومبادرة حياة كريمة، ومعاه لوحة تحكم المشرف الميداني للفصول.',
    };
    audioService.speak(guides[activeTab] || 'أهلاً بيك في منصة نور لمحو الأمية بمصر.');
  };

  const emergencyNumbers = [
    { name: 'الإسعاف', number: '123', icon: '🚑' },
    { name: 'النجدة والشرطة', number: '122', icon: '🚓' },
    { name: 'المطافئ', number: '180', icon: '🚒' },
    { name: 'طوارئ الغاز', number: '129', icon: '🔥' },
    { name: 'طوارئ الكهرباء', number: '121', icon: '⚡' },
  ];

  // Font size scale class for entire container
  const fontSizeClass =
    fontSize === 'huge'
      ? 'text-lg [&_h1]:text-4xl [&_h2]:text-3xl [&_h3]:text-2xl [&_p]:text-lg'
      : fontSize === 'large'
      ? 'text-base [&_h1]:text-3xl [&_h2]:text-2xl [&_h3]:text-xl [&_p]:text-base'
      : '';

  return (
    <div className={`min-h-screen flex flex-col bg-[#fffbf2] text-slate-900 ${fontSizeClass}`}>
      {/* Navigation */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        audioEnabled={audioEnabled}
        setAudioEnabled={setAudioEnabled}
        fontSize={fontSize}
        setFontSize={setFontSize}
        onOpenCertificate={() => setIsCertificateOpen(true)}
      />

      {/* Main Learning Canvas */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-10 space-y-8">
        {/* Master Studio Audio Player (One-click complete course) */}
        <MasterAudioPlayer />

        {activeTab === 'alphabet' && (
          <AlphabetSection onSelectLetterForCanvas={handleSelectLetterForCanvas} />
        )}
        {activeTab === 'phonics-lab' && <PhonicsLaboratory />}
        {activeTab === 'words' && <WordsSection />}
        {activeTab === 'numbers' && <NumbersSection />}
        {activeTab === 'life' && <LifeSituationsSection />}
        {activeTab === 'simulator' && <AdultLifeSimulator />}
        {activeTab === 'canvas' && <TracingCanvas initialLetter={tracingLetter} />}
        {activeTab === 'teacher' && <TeacherOmSalah />}
        {activeTab === 'quiz' && (
          <QuizSection onOpenCertificate={() => setIsCertificateOpen(true)} />
        )}
        {activeTab === 'exam' && <OfficialExamSection />}
        {activeTab === 'dossier' && <OfficialDossierSection />}

        {/* Quick Egyptian Emergency Hotline Drawer */}
        <section className="bg-white rounded-3xl p-6 border border-amber-200/90 shadow-xs space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div className="flex items-center gap-2.5">
              <PhoneCall className="w-5 h-5 text-rose-600" />
              <h3 className="text-base sm:text-lg font-black text-slate-900">
                أرقام الطوارئ المصرية السريعة (احفظها في بالك)
              </h3>
            </div>
            <button
              onClick={() => {
                audioService.speak(
                  'أرقام الطوارئ في مصر: الإسعاف 123، نجدة الشرطة 122، المطافئ 180، طوارئ الغاز 129، طوارئ الكهرباء 121.'
                );
              }}
              className="flex items-center gap-1.5 text-xs font-bold text-slate-600 hover:text-slate-900 bg-slate-100 px-3 py-1.5 rounded-xl w-fit"
            >
              <Volume2 className="w-4 h-4 text-amber-600" />
              <span>استمع لكل الأرقام</span>
            </button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
            {emergencyNumbers.map((item) => (
              <div
                key={item.number}
                onClick={() => {
                  audioService.playSound('pop');
                  audioService.speak(`رقم ${item.name} في مصر هو ${item.number}.`);
                }}
                className="p-3 bg-slate-50 hover:bg-rose-50 border border-slate-200 hover:border-rose-300 rounded-2xl cursor-pointer transition-all flex items-center justify-between group"
              >
                <div className="flex items-center gap-2">
                  <span className="text-xl">{item.icon}</span>
                  <div>
                    <span className="text-xs font-bold text-slate-700 block">{item.name}</span>
                    <span className="text-lg font-black font-mono text-rose-700 tracking-wider">
                      {item.number}
                    </span>
                  </div>
                </div>
                <Volume2 className="w-4 h-4 text-slate-400 group-hover:text-rose-600 transition-colors" />
              </div>
            ))}
          </div>
        </section>
      </main>

      {/* Egyptian Adult Education Pride Footer */}
      <footer className="bg-slate-950 text-white mt-12 py-10 border-t border-amber-900/40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4 text-center md:text-right">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-amber-500 text-white flex items-center justify-center font-bold text-xl">
                ن
              </div>
              <div>
                <span className="text-lg font-black font-['Alexandria',sans-serif]">
                  منصة نور لمحو الأمية في مصر
                </span>
                <p className="text-xs text-slate-400">
                  القراءة والكتابة حق لكل مصري ومصرية بكرامة وعزة نفس
                </p>
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-center gap-4 text-xs font-bold text-slate-400">
              <button
                onClick={() => {
                  setActiveTab('alphabet');
                  audioService.speak('الحروف الهجائية والأصوات');
                }}
                className="hover:text-amber-400 transition-colors"
              >
                الحروف والأصوات
              </button>
              <span>·</span>
              <button
                onClick={() => {
                  setActiveTab('numbers');
                  audioService.speak('الأرقام والفلوس المصرية');
                }}
                className="hover:text-amber-400 transition-colors"
              >
                الأرقام والفلوس
              </button>
              <span>·</span>
              <button
                onClick={() => {
                  setActiveTab('life');
                  audioService.speak('مواقف الحياة اليومية');
                }}
                className="hover:text-amber-400 transition-colors"
              >
                يافطات الشارع والدواء
              </button>
              <span>·</span>
              <button
                onClick={() => {
                  setActiveTab('canvas');
                  audioService.speak('سبورة التوقيع والرسم');
                }}
                className="hover:text-amber-400 transition-colors"
              >
                تدريب التوقيع بالاسم
              </button>
              <span>·</span>
              <button
                onClick={() => {
                  setActiveTab('simulator');
                  audioService.speak('محاكي الـ ATM والفواتير والمعاملات الحياتية');
                }}
                className="hover:text-amber-400 text-emerald-300 font-extrabold transition-colors"
              >
                محاكي الـ ATM والفواتير 🏧
              </button>
              <span>·</span>
              <button
                onClick={() => {
                  setActiveTab('exam');
                  audioService.speak('الامتحان الوطني المعتمد');
                }}
                className="hover:text-amber-400 transition-colors"
              >
                الامتحان المعتمد
              </button>
              <span>·</span>
              <button
                onClick={() => {
                  setActiveTab('dossier');
                  audioService.speak('ملف الاعتماد الحكومي ومبادرة حياة كريمة');
                }}
                className="hover:text-amber-400 text-amber-300 font-extrabold transition-colors"
              >
                ملف العرض الرسمي 🏛️
              </button>
            </div>
          </div>

          <div className="border-t border-slate-800 pt-6 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-500">
            <p>مبادرة تعليمية مصرية مجانية ومفتوحة لكل أهلنا في مصر والوطن العربي.</p>
            <div className="flex items-center gap-1.5 text-amber-400 font-bold">
              <span>العلم نور والجهل ظلام</span>
              <span>🇪🇬</span>
            </div>
          </div>
        </div>
      </footer>

      {/* Floating Egyptian Voice Guide Assistant */}
      <div className="fixed bottom-5 left-5 z-40">
        <button
          onClick={playTabGuide}
          className="flex items-center gap-2.5 px-4 py-3 bg-gradient-to-r from-amber-600 via-amber-700 to-yellow-700 hover:from-amber-700 hover:to-amber-800 text-white rounded-2xl shadow-xl hover:shadow-2xl hover:scale-105 active:scale-95 transition-all border-2 border-amber-300 font-extrabold text-xs sm:text-sm select-none"
          title="اضغط لسماع شرح هذه الصفحة بالصوت المصري"
        >
          <div className="w-7 h-7 rounded-xl bg-white/20 flex items-center justify-center text-lg">
            👨‍🏫
          </div>
          <span>عم صلاح بيشرح لك الصفحة</span>
          <Volume2 className="w-4 h-4 text-amber-200 animate-pulse" />
        </button>
      </div>

      {/* Diploma / Certificate Modal */}
      <CertificateModal
        isOpen={isCertificateOpen}
        onClose={() => setIsCertificateOpen(false)}
      />
    </div>
  );
}
