/**
 * Comprehensive Egyptian Adult Literacy Curriculum Data
 * Built on the Egyptian Reading Methodology (القرائية المصرية ونور البيان)
 * Focuses on phonics, syllables, similar letter differentiation, sun/moon lam, and real life scenarios.
 */

export interface LetterInfo {
  letter: string;
  name: string;
  nameAr: string;
  egyptianPhonic: string; // How Egyptian teachers explain it
  strokeGuide: {
    steps: string[];
    audioTip: string;
  };
  soundWithVowels: {
    fatha: { text: string; label: string; sound: string; egyptianSpoken: string };
    damma: { text: string; label: string; sound: string; egyptianSpoken: string };
    kasra: { text: string; label: string; sound: string; egyptianSpoken: string };
    sukoon: { text: string; label: string; sound: string; egyptianSpoken: string };
  };
  forms: {
    isolated: string;
    initial: string;
    medial: string;
    final: string;
  };
  examples: Array<{
    word: string;
    meaning: string;
    emoji: string;
    highlightLetter: string;
    syllables: string[];
    egyptianAudio: string;
  }>;
}

export const ARABIC_ALPHABET: LetterInfo[] = [
  {
    letter: 'أ',
    name: 'Alif',
    nameAr: 'أَلِف',
    egyptianPhonic: 'الألف عمود النور المستقيم، وفوقيه الهمزة زي العصفورة الصغيورة',
    strokeGuide: {
      steps: ['١. انزل بعصاية مستقيمة من فوق لتحت لحد السطر', '٢. ارسم نص دايرة صغيرة للهمزة', '٣. شد شرطة مايلة تحت الهمزة'],
      audioTip: 'انزل بعصاية مستقيمة من فوق لحد السطر، وماتنزلش تحت السطر، وحط الهمزة فوقيها بروقان!',
    },
    soundWithVowels: {
      fatha: { text: 'أَ', label: 'أَ (فتحة فوق)', sound: 'أَ زي أسد وأمي', egyptianSpoken: 'أَ... افتح بقك لفوق: أَ!' },
      damma: { text: 'أُ', label: 'أُ (ضمة واو صغيرة)', sound: 'أُ زي أختي وأستاذ', egyptianSpoken: 'أُ... ضم شفايفك: أُ!' },
      kasra: { text: 'إِ', label: 'إِ (كسرة تحت)', sound: 'إِ زي إبرة وإنسان', egyptianSpoken: 'إِ... ابتسم واكسر لتحت: إِ!' },
      sukoon: { text: 'أْ', label: 'أْ (سكون دايرة)', sound: 'أْ زي رأس وكأس', egyptianSpoken: 'أْ... اقف على الحرف ساكن: أْ!' },
    },
    forms: { isolated: 'أ', initial: 'أ...', medial: '...ـأ...', final: '...ـأ' },
    examples: [
      { word: 'أُمِّي', meaning: 'أمي الغالية ست الكل', emoji: '❤️', highlightLetter: 'أ', syllables: ['أُمْـ', 'ـمِي'], egyptianAudio: 'أُمِّي... أمي الغالية نبع الحنان' },
      { word: 'أَسَد', meaning: 'ملك الغابة القوي', emoji: '🦁', highlightLetter: 'أ', syllables: ['أَ', 'سَـ', 'ـدْ'], egyptianAudio: 'أَسَد... ملك الغابة' },
      { word: 'أَرْض', meaning: 'أرض مصر الطيبة والخير', emoji: '🌾', highlightLetter: 'أ', syllables: ['أَرْ', 'ضْ'], egyptianAudio: 'أَرْض... أرض مصر الطيبة والزرع' },
    ],
  },
  {
    letter: 'ب',
    name: 'Baa',
    nameAr: 'بَاء',
    egyptianPhonic: 'الباء طبق واسع وتحتيه نقطة واحدة (البرتقالة وقعت تحت الطبق)',
    strokeGuide: {
      steps: ['١. سنة صغيرة نازلة على السطر', '٢. امشي خط مستقيم على السطر', '٣. اطلع بسنة تانية واقفل الطبق', '٤. حط نقطة واحدة تحت الطبق'],
      audioTip: 'طبق واسع قاعد على السطر، وتحتيه نقطة واحدة بس! اوعى تنسى النقطة تحت.',
    },
    soundWithVowels: {
      fatha: { text: 'بَ', label: 'بَ (فتحة)', sound: 'بَ زي بيت وباب', egyptianSpoken: 'بَ... باء فتحة: بَـ!' },
      damma: { text: 'بُ', label: 'بُ (ضمة)', sound: 'بُ زي بُرج وبندق', egyptianSpoken: 'بُ... باء ضمة: بُـ!' },
      kasra: { text: 'بِ', label: 'بِ (كسرة)', sound: 'بِ زي بنت وبطاقة', egyptianSpoken: 'بِ... باء كسرة: بِـ!' },
      sukoon: { text: 'بْ', label: 'بْ (سكون)', sound: 'بْ زي حبل وخَبز', egyptianSpoken: 'بْ... باء سكون: بْ!' },
    },
    forms: { isolated: 'ب', initial: 'بـ', medial: 'ـبـ', final: 'ـب' },
    examples: [
      { word: 'بَيْت', meaning: 'البيت والعيلة والستر', emoji: '🏠', highlightLetter: 'ب', syllables: ['بَيْـ', 'ـتْ'], egyptianAudio: 'بَيْت... بيتنا الجميل المليان بركة' },
      { word: 'بَاب', meaning: 'باب الشقة أو المحل', emoji: '🚪', highlightLetter: 'ب', syllables: ['بَا', 'بْ'], egyptianAudio: 'بَاب... افتح الباب للرزق والخير' },
      { word: 'بَلَد', meaning: 'بلدنا مصر الحبيبة', emoji: '🇪🇬', highlightLetter: 'ب', syllables: ['بَـ', 'لَـ', 'ـدْ'], egyptianAudio: 'بَلَد... بلدنا الغالية مصر' },
    ],
  },
  {
    letter: 'ت',
    name: 'Taa',
    nameAr: 'تَاء',
    egyptianPhonic: 'التاء طبق جميل وجواه تفاحتين (نقطتين فوق الطبق)',
    strokeGuide: {
      steps: ['١. سنة صغيرة نازلة على السطر', '٢. امشي على السطر', '٣. اطلع بسنة واقفل الطبق', '٤. حط نقطتين جنب بعض جوه الطبق'],
      audioTip: 'طبق التاء نفس شكل طبق الباء، بس النقطتين الاتنين فوق جوه الطبق زي العينين!',
    },
    soundWithVowels: {
      fatha: { text: 'تَ', label: 'تَ (فتحة)', sound: 'تَ زي تمر وتفاح', egyptianSpoken: 'تَ... تاء فتحة: تَـ!' },
      damma: { text: 'تُ', label: 'تُ (ضمة)', sound: 'تُ زي توت وتجار', egyptianSpoken: 'تُ... تاء ضمة: تُـ!' },
      kasra: { text: 'تِ', label: 'تِ (كسرة)', sound: 'تِ زي تليفون وتمساح', egyptianSpoken: 'تِ... تاء كسرة: تِـ!' },
      sukoon: { text: 'تْ', label: 'تْ (سكون)', sound: 'تْ زي كتكوت ومكتوب', egyptianSpoken: 'تْ... تاء سكون: تْ!' },
    },
    forms: { isolated: 'ت', initial: 'تـ', medial: 'ـتـ', final: 'ـت' },
    examples: [
      { word: 'تَمْر', meaning: 'بلح وتمر الواحات وسيوة', emoji: '🌴', highlightLetter: 'ت', syllables: ['تَمْـ', 'ـرْ'], egyptianAudio: 'تَمْر... بلح مسكر ومغذي' },
      { word: 'تُفَّاح', meaning: 'فاكهة التفاح الأحمر', emoji: '🍎', highlightLetter: 'ت', syllables: ['تُفْـ', 'فَا', 'حْ'], egyptianAudio: 'تُفَّاح... التفاح المسكر' },
      { word: 'تِلِفُون', meaning: 'الموبايل والتليفون المحمول', emoji: '📱', highlightLetter: 'ت', syllables: ['تِـ', 'لِـ', 'فُونْ'], egyptianAudio: 'تِلِفُون... الموبايل ورناته' },
    ],
  },
  {
    letter: 'ث',
    name: 'Thaa',
    nameAr: 'ثَاء',
    egyptianPhonic: 'الثاء طبق وعليه تلات نقط (طلع طرف لسانك برقة وأنت بتنطقها)',
    strokeGuide: {
      steps: ['١. ارسم نفس طبق الباء والتاء', '٢. حط تلات نقط فوق على شكل مثلث (اتنين تحت وواحدة فوقيهم)'],
      audioTip: 'طلع طرف لسانك الصغير بين سنانك برقة: ثـ.. ثـ.. زي ثوم وثوب!',
    },
    soundWithVowels: {
      fatha: { text: 'ثَ', label: 'ثَ (فتحة)', sound: 'ثَ زي ثوم وثوب', egyptianSpoken: 'ثَ... ثاء فتحة: ثَـ!' },
      damma: { text: 'ثُ', label: 'ثُ (ضمة)', sound: 'ثُ زي ثعبان وثلث', egyptianSpoken: 'ثُ... ثاء ضمة: ثُـ!' },
      kasra: { text: 'ثِ', label: 'ثِ (كسرة)', sound: 'ثِ زي ثياب وثمار', egyptianSpoken: 'ثِ... ثاء كسرة: ثِـ!' },
      sukoon: { text: 'ثْ', label: 'ثْ (سكون)', sound: 'ثْ زي عثمان ومثلث', egyptianSpoken: 'ثْ... ثاء سكون: ثْ!' },
    },
    forms: { isolated: 'ث', initial: 'ثـ', medial: 'ـثـ', final: 'ـث' },
    examples: [
      { word: 'ثَوْم', meaning: 'توم الطبخ البلدي', emoji: '🧄', highlightLetter: 'ث', syllables: ['ثَوْ', 'مْ'], egyptianAudio: 'ثَوْم... توم الأكل اللي بيقوي المناعة' },
      { word: 'ثَوْب', meaning: 'توب قماش أو جلابية', emoji: '👕', highlightLetter: 'ث', syllables: ['ثَوْ', 'بْ'], egyptianAudio: 'ثَوْب... التوب واللبس الجديد' },
      { word: 'ثِمَار', meaning: 'خير الشجر والخضار والفاكهة', emoji: '🍇', highlightLetter: 'ث', syllables: ['ثِـ', 'مَا', 'رْ'], egyptianAudio: 'ثِمَار... ثمار الخير والبركة' },
    ],
  },
  {
    letter: 'ج',
    name: 'Jeem',
    nameAr: 'جِيم',
    egyptianPhonic: 'الجيم حاجب عين وتحتيه بطن مدورة وفي بطنها نقطة (الجيم شبعانة بلعت نقطة)',
    strokeGuide: {
      steps: ['١. شرطة مموجة فوق السطر من الشمال لليمين', '٢. نص دايرة كبيرة بتنزل تحت السطر زي البطن', '٣. حط نقطة واحدة جوه بطنها'],
      audioTip: 'الجيم بطنها مدورة وجواها نقطة زي اللقمة في بطنها!',
    },
    soundWithVowels: {
      fatha: { text: 'جَ', label: 'جَ (فتحة)', sound: 'جَ زي جامع وجنيه', egyptianSpoken: 'جَ... جيم فتحة: جَـ!' },
      damma: { text: 'جُ', label: 'جُ (ضمة)', sound: 'جُ زي جبن وجمل', egyptianSpoken: 'جُ... جيم ضمة: جُـ!' },
      kasra: { text: 'جِ', label: 'جِ (كسرة)', sound: 'جِ زي جسر وجيران', egyptianSpoken: 'جِ... جيم كسرة: جِـ!' },
      sukoon: { text: 'جْ', label: 'جْ (سكون)', sound: 'جْ زي فجر ونجار', egyptianSpoken: 'جْ... جيم سكون: جْ!' },
    },
    forms: { isolated: 'ج', initial: 'جـ', medial: 'ـجـ', final: 'ـج' },
    examples: [
      { word: 'جَامِع', meaning: 'المسجد والجامع للصلاة والسكينة', emoji: '🕌', highlightLetter: 'ج', syllables: ['جَا', 'مِـ', 'ـعْ'], egyptianAudio: 'جَامِع... جامع الصلاة والأذان' },
      { word: 'جُنَيْه', meaning: 'الجنيه المصري والفلوس الحلال', emoji: '💵', highlightLetter: 'ج', syllables: ['جُـ', 'نَيْـ', 'ـهْ'], egyptianAudio: 'جُنَيْه... الجنيه المصري والرزق الحلال' },
      { word: 'جَبَل', meaning: 'جبال البحر الأحمر ومصر العالية', emoji: '⛰️', highlightLetter: 'ج', syllables: ['جَـ', 'بَـ', 'ـلْ'], egyptianAudio: 'جَبَل... الجبل الصامد' },
    ],
  },
  {
    letter: 'ح',
    name: 'Haa',
    nameAr: 'حَاء',
    egyptianPhonic: 'الحاء أخت الجيم بس بطنها فاضية من غير نقط (حافية وجعانة)',
    strokeGuide: {
      steps: ['١. شرطة مموجة فوق السطر', '٢. نص دايرة كبيرة تحت السطر', '٣. متسيبش أي نقطة، حافية تماماً!'],
      audioTip: 'الحاء زي الجيم والخاء تمام في الرسم، بس معندهاش ولا نقطة.. حافية!',
    },
    soundWithVowels: {
      fatha: { text: 'حَ', label: 'حَ (فتحة)', sound: 'حَ زي حبيب وحساب', egyptianSpoken: 'حَ... حاء فتحة: حَـ!' },
      damma: { text: 'حُ', label: 'حُ (ضمة)', sound: 'حُ زي حوت وحب', egyptianSpoken: 'حُ... حاء ضمة: حُـ!' },
      kasra: { text: 'حِ', label: 'حِ (كسرة)', sound: 'حِ زي حصان وحبر', egyptianSpoken: 'حِ... حاء كسرة: حِـ!' },
      sukoon: { text: 'حْ', label: 'حْ (سكون)', sound: 'حْ زي بحر ولحم', egyptianSpoken: 'حْ... حاء سكون: حْ!' },
    },
    forms: { isolated: 'ح', initial: 'حـ', medial: 'ـحـ', final: 'ـح' },
    examples: [
      { word: 'حَبِيبِي', meaning: 'الابن والحبيب والقريب الغالي', emoji: '❤️', highlightLetter: 'ح', syllables: ['حَـ', 'بِيـ', 'ـبِي'], egyptianAudio: 'حَبِيبِي... يا حبيبي ربنا يحفظك' },
      { word: 'حِسَاب', meaning: 'حساب الفلوس والدفتر بالقرش', emoji: '🧮', highlightLetter: 'ح', syllables: ['حِـ', 'سَا', 'بْ'], egyptianAudio: 'حِسَاب... الحساب المضبوط يريح الاتنين' },
      { word: 'حِمَار', meaning: 'صديق الفلاح الصبور في الغيط', emoji: '🫏', highlightLetter: 'ح', syllables: ['حِـ', 'مَا', 'رْ'], egyptianAudio: 'حِمَار... صبور وبيساعد في الغيط' },
    ],
  },
  {
    letter: 'خ',
    name: 'Khaa',
    nameAr: 'خَاء',
    egyptianPhonic: 'الخاء أختهم التالتة حاطة طاقية ونقطة فوق راسها عشان الشمس',
    strokeGuide: {
      steps: ['١. شرطة مموجة فوق السطر', '٢. نص دايرة بطن كبيرة تحت السطر', '٣. حط نقطة واحدة فوق راسها من فوق!'],
      audioTip: 'الخاء عليها نقطة فوق راسها.. خـ.. خـ.. زي خضار وخبز!',
    },
    soundWithVowels: {
      fatha: { text: 'خَ', label: 'خَ (فتحة)', sound: 'خَ زي خبز وخضار', egyptianSpoken: 'خَ... خاء فتحة: خَـ!' },
      damma: { text: 'خُ', label: 'خُ (ضمة)', sound: 'خُ زي خروج وخوخ', egyptianSpoken: 'خُ... خاء ضمة: خُـ!' },
      kasra: { text: 'خِ', label: 'خِ (كسرة)', sound: 'خِ زي خيار وخيط', egyptianSpoken: 'خِ... خاء كسرة: خِـ!' },
      sukoon: { text: 'خْ', label: 'خْ (سكون)', sound: 'خْ زي نخلة ومخبز', egyptianSpoken: 'خْ... خاء سكون: خْ!' },
    },
    forms: { isolated: 'خ', initial: 'خـ', medial: 'ـخـ', final: 'ـخ' },
    examples: [
      { word: 'خُبْز', meaning: 'العيش البلدي الطازة من الفرن', emoji: '🥖', highlightLetter: 'خ', syllables: ['خُبْـ', 'ـزْ'], egyptianAudio: 'خُبْز... العيش البلدي الطازة' },
      { word: 'خُضَار', meaning: 'سوق الخضار والطماطم والخيار', emoji: '🥕', highlightLetter: 'خ', syllables: ['خُـ', 'ضَا', 'رْ'], egyptianAudio: 'خُضَار... خضار السوق الطازج' },
      { word: 'خَاتَم', meaning: 'دبلة وخاتم فضة وذهب', emoji: '💍', highlightLetter: 'خ', syllables: ['خَا', 'تَـ', 'ـمْ'], egyptianAudio: 'خَاتَم... خاتم الزواج والمحبة' },
    ],
  },
  {
    letter: 'د',
    name: 'Daal',
    nameAr: 'دَال',
    egyptianPhonic: 'الدال سنادة مفتوحة بتبص للشمال وقاعدة مرتاحة على السطر',
    strokeGuide: {
      steps: ['١. خط مايل صغير نازل على السطر', '٢. لفة زاوية وخط نايم على السطر للشمال'],
      audioTip: 'الدال حرف رقيق مرتاح على السطر.. دَ.. دَ.. زي دواء ودكان!',
    },
    soundWithVowels: {
      fatha: { text: 'دَ', label: 'دَ (فتحة)', sound: 'دَ زي دواء ودكان', egyptianSpoken: 'دَ... دال فتحة: دَـ!' },
      damma: { text: 'دُ', label: 'دُ (ضمة)', sound: 'دُ زي دكتور ودعاء', egyptianSpoken: 'دُ... دال ضمة: دُـ!' },
      kasra: { text: 'دِ', label: 'دِ (كسرة)', sound: 'دِ زي درهم ودفاع', egyptianSpoken: 'دِ... دال كسرة: دِـ!' },
      sukoon: { text: 'دْ', label: 'دْ (سكون)', sound: 'دْ زي بدر وميدان', egyptianSpoken: 'دْ... دال سكون: دْ!' },
    },
    forms: { isolated: 'د', initial: 'د', medial: 'ـد', final: 'ـد' },
    examples: [
      { word: 'دَوَاء', meaning: 'علاج الصيدلية والصحة والعافية', emoji: '💊', highlightLetter: 'د', syllables: ['دَ', 'وَا', 'ءْ'], egyptianAudio: 'دَوَاء... علاج الشفاء بإذن الله' },
      { word: 'دُكَّان', meaning: 'محل البقالة في الحارة', emoji: '🏪', highlightLetter: 'د', syllables: ['دُكْـ', 'كَا', 'نْ'], egyptianAudio: 'دُكَّان... دكان البقالة بالشارع' },
      { word: 'دَفْتَر', meaning: 'كشكول الحسابات والأوراق', emoji: '📒', highlightLetter: 'د', syllables: ['دَفْـ', 'تَـ', 'ـرْ'], egyptianAudio: 'دَفْتَر... دفتر الحسابات المنظم' },
    ],
  },
  {
    letter: 'ذ',
    name: 'Thaal',
    nameAr: 'ذَال',
    egyptianPhonic: 'الذال أخت الدال بس عليها نقطة وبتخرج طرف لسانك فيها',
    strokeGuide: {
      steps: ['١. ارسم نفس زاوية الدال', '٢. حط نقطة واحدة فوقيها'],
      audioTip: 'طلع طرف لسانك الصغير في الذال عشان تفرقها عن الزاي: ذَ.. ذَ.. زي ذهب!',
    },
    soundWithVowels: {
      fatha: { text: 'ذَ', label: 'ذَ (فتحة)', sound: 'ذَ زي ذهب وذرة', egyptianSpoken: 'ذَ... ذال فتحة: ذَـ!' },
      damma: { text: 'ذُ', label: 'ذُ (ضمة)', sound: 'ذُ زي ذرة وذباب', egyptianSpoken: 'ذُ... ذال ضمة: ذُـ!' },
      kasra: { text: 'ذِ', label: 'ذِ (كسرة)', sound: 'ذِ زي ذئب وذكرى', egyptianSpoken: 'ذِ... ذال كسرة: ذِـ!' },
      sukoon: { text: 'ذْ', label: 'ذْ (سكون)', sound: 'ذْ زي بذور وجذع', egyptianSpoken: 'ذْ... ذال سكون: ذْ!' },
    },
    forms: { isolated: 'ذ', initial: 'ذ', medial: 'ـذ', final: 'ـذ' },
    examples: [
      { word: 'ذَهَب', meaning: 'دهب الصاغة والشبكة والزينة', emoji: '✨', highlightLetter: 'ذ', syllables: ['ذَ', 'هَـ', 'ـبْ'], egyptianAudio: 'ذَهَب... دهب الصاغة والخير' },
      { word: 'ذُرَة', meaning: 'كوز ذرة مشوي على الكورنيش', emoji: '🌽', highlightLetter: 'ذ', syllables: ['ذُ', 'رَ', 'ة'], egyptianAudio: 'ذُرَة... ذرة مشوي سخن وجميل' },
      { word: 'ذِرَاع', meaning: 'دراع الإنسان وقوة الشغل', emoji: '💪', highlightLetter: 'ذ', syllables: ['ذِ', 'رَا', 'عْ'], egyptianAudio: 'ذِرَاع... دراعك وقوتك في الشغل' },
    ],
  },
  {
    letter: 'ر',
    name: 'Raa',
    nameAr: 'رَاء',
    egyptianPhonic: 'الراء زحليقة ناعمة بتنزل تحت السطر',
    strokeGuide: {
      steps: ['١. سنة صغيرة جداً فوق السطر', '٢. تزحلق بقوس لتحت السطر'],
      audioTip: 'الراء بتتزحلق لتحت السطر بنعومة.. رَ.. رَ.. زي رمسيس ورقم!',
    },
    soundWithVowels: {
      fatha: { text: 'رَ', label: 'رَ (فتحة)', sound: 'رَ زي رمسيس ورقم', egyptianSpoken: 'رَ... راء فتحة: رَـ!' },
      damma: { text: 'رُ', label: 'رُ (ضمة)', sound: 'رُ زي رمان وركوب', egyptianSpoken: 'رُ... راء ضمة: رُـ!' },
      kasra: { text: 'رِ', label: 'رِ (كسرة)', sound: 'رِ زي رسالة ورزق', egyptianSpoken: 'رِ... راء كسرة: رِـ!' },
      sukoon: { text: 'رْ', label: 'رْ (سكون)', sound: 'رْ زي مصر وقمر', egyptianSpoken: 'رْ... راء سكون: رْ!' },
    },
    forms: { isolated: 'ر', initial: 'ر', medial: 'ـر', final: 'ـر' },
    examples: [
      { word: 'رَمْسِيس', meaning: 'محطة مصر وميدان رمسيس المركزي', emoji: '🚂', highlightLetter: 'ر', syllables: ['رَمْـ', 'سِيـ', 'ـسْ'], egyptianAudio: 'رَمْسِيس... محطة قطارات مصر كلها' },
      { word: 'رَقَم', meaning: 'الرقم القومي ونمرة التليفون', emoji: '🔢', highlightLetter: 'ر', syllables: ['رَ', 'قَـ', 'ـمْ'], egyptianAudio: 'رَقَم... الرقم القومي ونمرتك' },
      { word: 'رِزْق', meaning: 'الرزق الحلال وبركة ربنا', emoji: '🤲', highlightLetter: 'ر', syllables: ['رِزْ', 'قْ'], egyptianAudio: 'رِزْق... الرزق الحلال الطيب' },
    ],
  },
  {
    letter: 'ز',
    name: 'Zayn',
    nameAr: 'زَاي',
    egyptianPhonic: 'الزاي أخت الراء وعليها نقطة من فوق وبتزن زي النحلة: زززز',
    strokeGuide: {
      steps: ['١. ارسم نفس زحليقة الراء', '٢. حط نقطة واحدة فوقيها'],
      audioTip: 'الزاي بتزن زي صوت النحلة: ززز.. من غير ما تطلع لسانك!',
    },
    soundWithVowels: {
      fatha: { text: 'زَ', label: 'زَ (فتحة)', sound: 'زَ زي زيت وزبون', egyptianSpoken: 'زَ... زاي فتحة: زَـ!' },
      damma: { text: 'زُ', label: 'زُ (ضمة)', sound: 'زُ زي زهور وزبدة', egyptianSpoken: 'زُ... زاي ضمة: زُـ!' },
      kasra: { text: 'زِ', label: 'زِ (كسرة)', sound: 'زِ زي زر وزينة', egyptianSpoken: 'زِ... زاي كسرة: زِـ!' },
      sukoon: { text: 'زْ', label: 'زْ (سكون)', sound: 'زْ زي مزمار وميزان', egyptianSpoken: 'زْ... زاي سكون: زْ!' },
    },
    forms: { isolated: 'ز', initial: 'ز', medial: 'ـز', final: 'ـز' },
    examples: [
      { word: 'زَيْت', meaning: 'زيت التموين والطبخ', emoji: '🫒', highlightLetter: 'ز', syllables: ['زَيْـ', 'ـتْ'], egyptianAudio: 'زَيْت... زيت التموين والطبخ' },
      { word: 'زَرْع', meaning: 'الغيط والأرض الخضرا في الريف', emoji: '🌱', highlightLetter: 'ز', syllables: ['زَرْ', 'عْ'], egyptianAudio: 'زَرْع... الزرع الأخضر وخير الأرض' },
      { word: 'زَبُون', meaning: 'الزبون الطيب في الدكان', emoji: '🤝', highlightLetter: 'ز', syllables: ['زَ', 'بُو', 'نْ'], egyptianAudio: 'زَبُون... الزبون العزيز في المحل' },
    ],
  },
  {
    letter: 'س',
    name: 'Seen',
    nameAr: 'سِين',
    egyptianPhonic: 'السين تلات سنان صغننين على السطر وطاسة بتنزل تلف تحت السطر',
    strokeGuide: {
      steps: ['١. سنة أولى وسنة تانية وسنة تالتة على السطر', '٢. طبق مدور غويط بينزل تحت السطر ويطلع'],
      audioTip: 'السين رقيقة وصوتها صفير خفيف: سـ.. سـ.. زي سوق وسكر!',
    },
    soundWithVowels: {
      fatha: { text: 'سَ', label: 'سَ (فتحة)', sound: 'سَ زي سوق وسلام', egyptianSpoken: 'سَ... سين فتحة: سَـ!' },
      damma: { text: 'سُ', label: 'سُ (ضمة)', sound: 'سُ زي سكر وسور', egyptianSpoken: 'سُ... سين ضمة: سُـ!' },
      kasra: { text: 'سِ', label: 'سِ (كسرة)', sound: 'سِ زي سيارة وسلاح', egyptianSpoken: 'سِ... سين كسرة: سِـ!' },
      sukoon: { text: 'سْ', label: 'سْ (سكون)', sound: 'سْ زي شمس ومسجد', egyptianSpoken: 'سْ... سين سكون: سْ!' },
    },
    forms: { isolated: 'س', initial: 'سـ', medial: 'ـسـ', final: 'ـس' },
    examples: [
      { word: 'سُوق', meaning: 'سوق الخضار والأسبوع', emoji: '🛍️', highlightLetter: 'س', syllables: ['سُو', 'قْ'], egyptianAudio: 'سُوق... سوق الخضار والطلبات' },
      { word: 'سُكَّر', meaning: 'سكر التموين والشاي المصري', emoji: '☕', highlightLetter: 'س', syllables: ['سُكْـ', 'ـكَـ', 'ـرْ'], egyptianAudio: 'سُكَّر... سكر الشاي المضبوط' },
      { word: 'سَلَام', meaning: 'السلام عليكم والتحية والأمان', emoji: '🕊️', highlightLetter: 'س', syllables: ['سَـ', 'لَا', 'مْ'], egyptianAudio: 'سَلَام... السلام عليكم والبركة' },
    ],
  },
  {
    letter: 'ش',
    name: 'Sheen',
    nameAr: 'شِين',
    egyptianPhonic: 'الشين تلات سنان وعليهم تلات نقط منورين زي نجوم السما',
    strokeGuide: {
      steps: ['١. ارسم تلات سنان السين', '٢. ارسم الطاسة الغويطة', '٣. حط تلات نقط فوق السنان على شكل هرم'],
      audioTip: 'الشين بتوش زي الشاي السخن على النار: شـ.. شـ.. زي شاي وشارع!',
    },
    soundWithVowels: {
      fatha: { text: 'شَ', label: 'شَ (فتحة)', sound: 'شَ زي شاي وشارع', egyptianSpoken: 'شَ... شين فتحة: شَـ!' },
      damma: { text: 'شُ', label: 'شُ (ضمة)', sound: 'شُ زي شباك وشكر', egyptianSpoken: 'شُ... شين ضمة: شُـ!' },
      kasra: { text: 'شِ', label: 'شِ (كسرة)', sound: 'شِ زي شتاء وشهادة', egyptianSpoken: 'شِ... شين كسرة: شِـ!' },
      sukoon: { text: 'شْ', label: 'شْ (سكون)', sound: 'شْ زي مشمش وعيش', egyptianSpoken: 'شْ... شين سكون: شْ!' },
    },
    forms: { isolated: 'ش', initial: 'شـ', medial: 'ـشـ', final: 'ـش' },
    examples: [
      { word: 'شَاي', meaning: 'كوباية الشاي المصري المظبوطة', emoji: '🫖', highlightLetter: 'ش', syllables: ['شَا', 'يْ'], egyptianAudio: 'شَاي... كوباية شاي في الخمسينة' },
      { word: 'شَارِع', meaning: 'شارع الحي والموقف والمحلات', emoji: '🛣️', highlightLetter: 'ش', syllables: ['شَا', 'رِ', 'عْ'], egyptianAudio: 'شَارِع... الشارع ويافطاته' },
      { word: 'شَمْس', meaning: 'شمس مصر الدافية المنورة', emoji: '☀️', highlightLetter: 'ش', syllables: ['شَمْـ', 'ـسْ'], egyptianAudio: 'شَمْس... شمس مصر المشرقة' },
    ],
  },
  {
    letter: 'ص',
    name: 'Saad',
    nameAr: 'صَاد',
    egyptianPhonic: 'الصاد كوبري مقفل بيطلع وينزل على السطر وسنة صغيرة وطاسة غويطة',
    strokeGuide: {
      steps: ['١. اطلع بكوبري مايل من السطر ولفه', '٢. انزل واقفل على السطر', '٣. اعمل سنة صغيورة', '٤. طاسة غويطة بتنزل تلف تحت السطر'],
      audioTip: 'الصاد حرف تخين ومفخم.. املأ بقك بيه: صـ.. صـ.. مش سين رقيقة!',
    },
    soundWithVowels: {
      fatha: { text: 'صَ', label: 'صَ (فتحة)', sound: 'صَ زي صيدلية وصحة', egyptianSpoken: 'صَ... صاد فتحة مفخمة: صَـ!' },
      damma: { text: 'صُ', label: 'صُ (ضمة)', sound: 'صُ زي صندوق وصور', egyptianSpoken: 'صُ... صاد ضمة: صُـ!' },
      kasra: { text: 'صِ', label: 'صِ (كسرة)', sound: 'صِ زي صراط وصحافة', egyptianSpoken: 'صِ... صاد كسرة: صِـ!' },
      sukoon: { text: 'صْ', label: 'صْ (سكون)', sound: 'صْ زي مصر وقصر', egyptianSpoken: 'صْ... صاد سكون: صْ!' },
    },
    forms: { isolated: 'ص', initial: 'صـ', medial: 'ـصـ', final: 'ـص' },
    examples: [
      { word: 'صَيْدَلِيَّة', meaning: 'الأجزخانة ومكان صرف الدواء', emoji: '⚕️', highlightLetter: 'ص', syllables: ['صَيْـ', 'ـدَ', 'لِيْـ', 'ـيَة'], egyptianAudio: 'صَيْدَلِيَّة... الصيدلية لشراء العلاج' },
      { word: 'صِحَّة', meaning: 'الصحة وتمام العافية والستر', emoji: '💪', highlightLetter: 'ص', syllables: ['صِحْـ', 'ـحَة'], egyptianAudio: 'صِحَّة... ربنا يديك الصحة وراحة البال' },
      { word: 'صَبَاح', meaning: 'صباح الخير والرزق والفل', emoji: '🌅', highlightLetter: 'ص', syllables: ['صَـ', 'بَا', 'حْ'], egyptianAudio: 'صَبَاح... صباح الخير والورد' },
    ],
  },
  {
    letter: 'ض',
    name: 'Daad',
    nameAr: 'ضَاد',
    egyptianPhonic: 'الضاد لغة أهل مصر والعرب، أخت الصاد وعليها نقطة مفخمة وقوية',
    strokeGuide: {
      steps: ['١. ارسم كوبري وسنة الصاد', '٢. ارسم الطاسة الغويطة', '٣. حط نقطة واحدة فوق الكوبري'],
      audioTip: 'الضاد حرف قوي ومميز.. اضغط بطرف لسانك على جمب ضرسك: ضـ.. ضـ.. زي ضوء وضابط!',
    },
    soundWithVowels: {
      fatha: { text: 'ضَ', label: 'ضَ (فتحة)', sound: 'ضَ زي ضوء وضيف', egyptianSpoken: 'ضَ... ضاد فتحة: ضَـ!' },
      damma: { text: 'ضُ', label: 'ضُ (ضمة)', sound: 'ضُ زي ضيوف وضحى', egyptianSpoken: 'ضُ... ضاد ضمة: ضُـ!' },
      kasra: { text: 'ضِ', label: 'ضِ (كسرة)', sound: 'ضِ زي ضرس وضياء', egyptianSpoken: 'ضِ... ضاد كسرة: ضِـ!' },
      sukoon: { text: 'ضْ', label: 'ضْ (سكون)', sound: 'ضْ زي خضار وأبيض', egyptianSpoken: 'ضْ... ضاد سكون: ضْ!' },
    },
    forms: { isolated: 'ض', initial: 'ضـ', medial: 'ـضـ', final: 'ـض' },
    examples: [
      { word: 'ضَوْء', meaning: 'نور اللمبة والشمس الساطعة', emoji: '💡', highlightLetter: 'ض', syllables: ['ضَوْ', 'ءْ'], egyptianAudio: 'ضَوْء... نور وشعاع يفتح البصيرة' },
      { word: 'ضَيْف', meaning: 'الضيف العزيز وإكرامه في البيت', emoji: '🍵', highlightLetter: 'ض', syllables: ['ضَيْـ', 'ـفْ'], egyptianAudio: 'ضَيْف... الضيف العزيز مرحب بيه' },
      { word: 'ضَابِط', meaning: 'ضابط الشرطة والأمن والأمان', emoji: '👮', highlightLetter: 'ض', syllables: ['ضَا', 'بِـ', 'ـطْ'], egyptianAudio: 'ضَابِط... ضابط الشرطة والأمان' },
    ],
  },
  {
    letter: 'ط',
    name: 'Taa (Emphatic)',
    nameAr: 'طَاء',
    egyptianPhonic: 'الطاء كوبري على السطر وواقف فوقيه عصاية طويلة مستقيمة',
    strokeGuide: {
      steps: ['١. كوبري مايل نايم على السطر', '٢. اقفل الكوبري بخط على السطر', '٣. انزل بعصاية مستقيمة من فوق لحد بداية الكوبري'],
      audioTip: 'الطاء حرف مفخم تخين.. طَ.. طَ.. مش تاء رقيقة.. زي طبيب وطماطم!',
    },
    soundWithVowels: {
      fatha: { text: 'طَ', label: 'طَ (فتحة)', sound: 'طَ زي طبيب وطريق', egyptianSpoken: 'طَ... طاء فتحة مفخمة: طَـ!' },
      damma: { text: 'طُ', label: 'طُ (ضمة)', sound: 'طُ زي طيور وطوب', egyptianSpoken: 'طُ... طاء ضمة: طُـ!' },
      kasra: { text: 'طِ', label: 'طِ (كسرة)', sound: 'طِ زي طفل وطيارة', egyptianSpoken: 'طِ... طاء كسرة: طِـ!' },
      sukoon: { text: 'طْ', label: 'طْ (سكون)', sound: 'طْ زي قطن ومطبخ', egyptianSpoken: 'طْ... طاء سكون: طْ!' },
    },
    forms: { isolated: 'ط', initial: 'طـ', medial: 'ـطـ', final: 'ـط' },
    examples: [
      { word: 'طَبِيب', meaning: 'الدكتور في الوحدة الصحية والمركز', emoji: '🩺', highlightLetter: 'ط', syllables: ['طَـ', 'بِيـ', 'ـبْ'], egyptianAudio: 'طَبِيب... دكتور الوحدة الصحية' },
      { word: 'طَرِيق', meaning: 'طريق السفر والمواصلات السريعة', emoji: '🛣️', highlightLetter: 'ط', syllables: ['طَـ', 'رِيـ', 'ـقْ'], egyptianAudio: 'طَرِيق... طريق السلامة يا مسافر' },
      { word: 'طَمَاطِم', meaning: 'القوطة والطماطم الحمرا في السوق', emoji: '🍅', highlightLetter: 'ط', syllables: ['طَـ', 'مَا', 'طِـ', 'ـمْ'], egyptianAudio: 'طَمَاطِم... طماطم مجنونة وحمرا' },
    ],
  },
  {
    letter: 'ظ',
    name: 'Dhaa',
    nameAr: 'ظَاء',
    egyptianPhonic: 'الظاء أخت الطاء بالعصاية الطويلة، وعليها نقطة وبتخرج لسانك فيها',
    strokeGuide: {
      steps: ['١. ارسم كوبري الطاء وعصايتها الطويلة', '٢. حط نقطة واحدة جنب العصاية'],
      audioTip: 'الظاء مفخمة ومعاها خروج طرف لسانك: ظَ.. ظَ.. زي ظرف وظل!',
    },
    soundWithVowels: {
      fatha: { text: 'ظَ', label: 'ظَ (فتحة)', sound: 'ظَ زي ظرف وظهيرة', egyptianSpoken: 'ظَ... ظاء فتحة: ظَـ!' },
      damma: { text: 'ظُ', label: 'ظُ (ضمة)', sound: 'ظُ زي ظهر وظفر', egyptianSpoken: 'ظُ... ظاء ضمة: ظُـ!' },
      kasra: { text: 'ظِ', label: 'ظِ (كسرة)', sound: 'ظِ زي ظل وظلال', egyptianSpoken: 'ظِ... ظاء كسرة: ظِـ!' },
      sukoon: { text: 'ظْ', label: 'ظْ (سكون)', sound: 'ظْ زي عظيم ومظلوم', egyptianSpoken: 'ظْ... ظاء سكون: ظْ!' },
    },
    forms: { isolated: 'ظ', initial: 'ظـ', medial: 'ـظـ', final: 'ـظ' },
    examples: [
      { word: 'ظَرْف', meaning: 'ظرف الجواب أو ظرف الفلوس المقفول', emoji: '✉️', highlightLetter: 'ظ', syllables: ['ظَرْ', 'فْ'], egyptianAudio: 'ظَرْف... ظرف الجواب والفلوس' },
      { word: 'ظُهْر', meaning: 'صلاة وأذان الظهر في الجامع', emoji: '☀️', highlightLetter: 'ظ', syllables: ['ظُهْـ', 'ـرْ'], egyptianAudio: 'ظُهْر... صلاة وأذان الظهر' },
      { word: 'ظِلّ', meaning: 'ضل الشجرة في عز حر الصيف', emoji: '🌳', highlightLetter: 'ظ', syllables: ['ظِلْـ', 'ـلْ'], egyptianAudio: 'ظِلّ... اقعد في الضل واستريح' },
    ],
  },
  {
    letter: 'ع',
    name: 'Ayn',
    nameAr: 'عَيْن',
    egyptianPhonic: 'العين نص دايرة صغيرة باصة لليمين، ونص دايرة كبيرة بتنزل تحت السطر',
    strokeGuide: {
      steps: ['١. نص دايرة صغيرة فوق السطر باصة للشمال', '٢. نص دايرة كبيرة بتنزل تلف تحت السطر'],
      audioTip: 'العين بتخرج من وسط الحلق بعمق: عَـ.. عَـ.. زي عيش وعمل!',
    },
    soundWithVowels: {
      fatha: { text: 'عَ', label: 'عَ (فتحة)', sound: 'عَ زي عمل وعيش', egyptianSpoken: 'عَ... عين فتحة: عَـ!' },
      damma: { text: 'عُ', label: 'عُ (ضمة)', sound: 'عُ زي عصفور وعمر', egyptianSpoken: 'عُ... عين ضمة: عُـ!' },
      kasra: { text: 'عِ', label: 'عِ (كسرة)', sound: 'عِ زي علاج وعلم', egyptianSpoken: 'عِ... عين كسرة: عِـ!' },
      sukoon: { text: 'عْ', label: 'عْ (سكون)', sound: 'عْ زي معهد وكعك', egyptianSpoken: 'عْ... عين سكون: عْ!' },
    },
    forms: { isolated: 'ع', initial: 'عـ', medial: 'ـعـ', final: 'ـع' },
    examples: [
      { word: 'عَيْش', meaning: 'رغيف العيش وسر الحياة والبركة', emoji: '🫓', highlightLetter: 'ع', syllables: ['عَيْـ', 'ـشْ'], egyptianAudio: 'عَيْش... رغيف العيش البلدي وبركة البيت' },
      { word: 'عَمَل', meaning: 'الشغل والكفاح والعمل عبادة', emoji: '🛠️', highlightLetter: 'ع', syllables: ['عَـ', 'مَـ', 'ـلْ'], egyptianAudio: 'عَمَل... العمل عبادة وكفاح شريف' },
      { word: 'عَتَبَة', meaning: 'سوق وميدان العتبة في وسط البلد', emoji: '🏬', highlightLetter: 'ع', syllables: ['عَـ', 'تَـ', 'ـبَة'], egyptianAudio: 'عَتَبَة... العتبة وسوقها التجاري' },
    ],
  },
  {
    letter: 'غ',
    name: 'Ghayn',
    nameAr: 'غَيْن',
    egyptianPhonic: 'الغين أخت العين التوأم، بس عليها نقطة من فوق',
    strokeGuide: {
      steps: ['١. ارسم نفس نصين دايرة العين', '٢. حط نقطة واحدة فوق راسها'],
      audioTip: 'الغين بتخرج من أعلى الحلق: غَـ.. غَـ.. زي غاز وغالي!',
    },
    soundWithVowels: {
      fatha: { text: 'غَ', label: 'غَ (فتحة)', sound: 'غَ زي غاز وغالي', egyptianSpoken: 'غَ... غين فتحة: غَـ!' },
      damma: { text: 'غُ', label: 'غُ (ضمة)', sound: 'غُ زي غرفة وغصن', egyptianSpoken: 'غُ... غين ضمة: غُـ!' },
      kasra: { text: 'غِ', label: 'غِ (كسرة)', sound: 'غِ زي غطاء وغذاء', egyptianSpoken: 'غِ... غين كسرة: غِـ!' },
      sukoon: { text: 'غْ', label: 'غْ (سكون)', sound: 'غْ زي مغسلة وبغداد', egyptianSpoken: 'غْ... غين سكون: غْ!' },
    },
    forms: { isolated: 'غ', initial: 'غـ', medial: 'ـغـ', final: 'ـغ' },
    examples: [
      { word: 'غَاز', meaning: 'غاز البوتاجاز وفاتورة الغاز الشهرية', emoji: '🔥', highlightLetter: 'غ', syllables: ['غَا', 'زْ'], egyptianAudio: 'غَاز... فاتورة الغاز الطبيعي' },
      { word: 'غَالِي', meaning: 'الحبيب العزيز وغالي المقام', emoji: '💎', highlightLetter: 'غ', syllables: ['غَا', 'لِي'], egyptianAudio: 'غَالِي... إنت غالي علينا وراسك مرفوعة' },
      { word: 'غَيْط', meaning: 'أرض الزراعة والخير في الريف', emoji: '🌾', highlightLetter: 'غ', syllables: ['غَيْـ', 'ـطْ'], egyptianAudio: 'غَيْط... أرض الغيط والزرع الأخضر' },
    ],
  },
  {
    letter: 'ف',
    name: 'Faa',
    nameAr: 'فَاء',
    egyptianPhonic: 'الفاء راس مدورة فوق السطر ورقبة وطبق نايم على السطر وعليه نقطة',
    strokeGuide: {
      steps: ['١. دايرة صغيرة فوق السطر', '٢. رقبة قصيرة نازلة على السطر', '٣. طبق نايم مسطح على السطر', '٤. نقطة واحدة فوق الدايرة'],
      audioTip: 'الفاء طبقها نايم على السطر مبينزلش تحته، وعليها نقطة واحدة.. فـ.. فـ.. زي فوري وفول!',
    },
    soundWithVowels: {
      fatha: { text: 'فَ', label: 'فَ (فتحة)', sound: 'فَ زي فوري وفول', egyptianSpoken: 'فَ... فاء فتحة: فَـ!' },
      damma: { text: 'فُ', label: 'فُ (ضمة)', sound: 'فُ زي فرصة وفندق', egyptianSpoken: 'فُ... فاء ضمة: فُـ!' },
      kasra: { text: 'فِ', label: 'فِ (كسرة)', sound: 'فِ زي فيصل وفكرة', egyptianSpoken: 'فِ... فاء كسرة: فِـ!' },
      sukoon: { text: 'فْ', label: 'فْ (سكون)', sound: 'فْ زي دفتر ودفء', egyptianSpoken: 'فْ... فاء سكون: فْ!' },
    },
    forms: { isolated: 'ف', initial: 'فـ', medial: 'ـفـ', final: 'ـف' },
    examples: [
      { word: 'فُول', meaning: 'فول الفطار المصري وقدرة الفول', emoji: '🍲', highlightLetter: 'ف', syllables: ['فُو', 'لْ'], egyptianAudio: 'فُول... طبق الفول بالزيت والليمون' },
      { word: 'فَوْرِي', meaning: 'دفع الفواتير بكشك وماكينة فوري', emoji: '💳', highlightLetter: 'ف', syllables: ['فَوْ', 'رِي'], egyptianAudio: 'فَوْرِي... دفع الفواتير من مكنة فوري' },
      { word: 'فَاتُورَة', meaning: 'فاتورة الكهرباء والمياه والغاز', emoji: '🧾', highlightLetter: 'ف', syllables: ['فَا', 'تُو', 'رَة'], egyptianAudio: 'فَاتُورَة... فاتورة النور والخدمات' },
    ],
  },
  {
    letter: 'ق',
    name: 'Qaaf',
    nameAr: 'قَاف',
    egyptianPhonic: 'القاف راس مدورة بتنزل بطاسة غويطة تحت السطر وعليها نقطتين',
    strokeGuide: {
      steps: ['١. دايرة صغيرة فوق السطر', '٢. انزل بطاسة غويطة بتلف تحت السطر وتطلع', '٣. حط نقطتين اتنين فوق الدايرة'],
      audioTip: 'القاف بتنزل تحت السطر وعليها نقطتين.. وصوتها قوي ومفخم: قـ.. قـ.. زي قاهرة وقراءة!',
    },
    soundWithVowels: {
      fatha: { text: 'قَ', label: 'قَ (فتحة)', sound: 'قَ زي قاهرة وقراءة', egyptianSpoken: 'قَ... قاف فتحة مفخمة: قَـ!' },
      damma: { text: 'قُ', label: 'قُ (ضمة)', sound: 'قُ زي قفل وقوة', egyptianSpoken: 'قُ... قاف ضمة: قُـ!' },
      kasra: { text: 'قِ', label: 'قِ (كسرة)', sound: 'قِ زي قطار وقرش', egyptianSpoken: 'قِ... قاف كسرة: قِـ!' },
      sukoon: { text: 'قْ', label: 'قْ (سكون)', sound: 'قْ زي سقف وسوق', egyptianSpoken: 'قْ... قاف سكون: قْ!' },
    },
    forms: { isolated: 'ق', initial: 'قـ', medial: 'ـقـ', final: 'ـق' },
    examples: [
      { word: 'قَاهِرَة', meaning: 'القاهرة المعز عاصمة مصر وحبيبة الكل', emoji: '🏛️', highlightLetter: 'ق', syllables: ['قَا', 'هِـ', 'ـرَة'], egyptianAudio: 'قَاهِرَة... مصر المحروسة والقاهرة' },
      { word: 'قِرَاءَة', meaning: 'نور العقل وفتح البصيرة والعزة', emoji: '📖', highlightLetter: 'ق', syllables: ['قِـ', 'رَا', 'ءَة'], egyptianAudio: 'قِرَاءَة... القراءة نور البصيرة' },
      { word: 'قِطَار', meaning: 'قطار السكة الحديد ومحطة مصر', emoji: '🚆', highlightLetter: 'ق', syllables: ['قِـ', 'طَا', 'رْ'], egyptianAudio: 'قِطَار... قطار السكة الحديد السريع' },
    ],
  },
  {
    letter: 'ك',
    name: 'Kaaf',
    nameAr: 'كَاف',
    egyptianPhonic: 'الكاف عصاية طويلة وطبق على السطر وجواه همزة كاف صغيورة',
    strokeGuide: {
      steps: ['١. عصاية طويلة نازلة من فوق لحد السطر', '٢. خط نايم على السطر مع طلعة سنة صغيرة', '٣. ارسم كاف صغيرة في قلبها'],
      audioTip: 'الكاف رقيقة وفي قلبها كاف صغيرة زي الهمزة.. كـ.. كـ.. زي كارت وكتاب!',
    },
    soundWithVowels: {
      fatha: { text: 'كَ', label: 'كَ (فتحة)', sound: 'كَ زي كارت وكتاب', egyptianSpoken: 'كَ... كاف فتحة رقيقة: كَـ!' },
      damma: { text: 'كُ', label: 'كُ (ضمة)', sound: 'كُ زي كتب وكرسي', egyptianSpoken: 'كُ... كاف ضمة: كُـ!' },
      kasra: { text: 'كِ', label: 'كِ (كسرة)', sound: 'كِ زي كيس وكيلو', egyptianSpoken: 'كِ... كاف كسرة: كِـ!' },
      sukoon: { text: 'كْ', label: 'كْ (سكون)', sound: 'كْ زي دكان وشكر', egyptianSpoken: 'كْ... كاف سكون: كْ!' },
    },
    forms: { isolated: 'ك', initial: 'كـ', medial: 'ـكـ', final: 'ـك' },
    examples: [
      { word: 'كَهْرَبَاء', meaning: 'عداد الكهرباء والإنارة', emoji: '⚡', highlightLetter: 'ك', syllables: ['كَهْـ', 'ـرَ', 'بَا', 'ءْ'], egyptianAudio: 'كَهْرَبَاء... شحن كارت عداد الكهرباء' },
      { word: 'كَارْت', meaning: 'كارت الشحن وبطاقة الصراف الآلي', emoji: '💳', highlightLetter: 'ك', syllables: ['كَارْ', 'تْ'], egyptianAudio: 'كَارْت... كارت الشحن وبطاقة البنك' },
      { word: 'كِتَاب', meaning: 'الكتاب المدرسي ودليل القراءة', emoji: '📚', highlightLetter: 'ك', syllables: ['كِـ', 'تَا', 'بْ'], egyptianAudio: 'كِتَاب... الكتاب خير جليس' },
    ],
  },
  {
    letter: 'ل',
    name: 'Laam',
    nameAr: 'لَام',
    egyptianPhonic: 'اللام عصاية شمسية طويلة بتنزل تلف تحت السطر زي يد الشمسية',
    strokeGuide: {
      steps: ['١. عصاية طويلة نازلة من فوق للسطر', '٢. انزل لفة نص دايرة تحت السطر واطلع بيها'],
      audioTip: 'اللام زي يد الشمسية المقلوبة.. لسانك يلمس سقف الحلق بروقان: لـ.. لـ.. زي ليمون ولحم!',
    },
    soundWithVowels: {
      fatha: { text: 'لَ', label: 'لَ (فتحة)', sound: 'لَ زي ليمون ولحم', egyptianSpoken: 'لَ... لام فتحة: لَـ!' },
      damma: { text: 'لُ', label: 'لُ (ضمة)', sound: 'لُ زي لقمة ولوبيا', egyptianSpoken: 'لُ... لام ضمة: لُـ!' },
      kasra: { text: 'لِ', label: 'لِ (كسرة)', sound: 'لِ زي لسان ولتر', egyptianSpoken: 'لِ... لام كسرة: لِـ!' },
      sukoon: { text: 'لْ', label: 'لْ (سكون)', sound: 'لْ زي قلب ونيل', egyptianSpoken: 'لْ... لام سكون: لْ!' },
    },
    forms: { isolated: 'ل', initial: 'لـ', medial: 'ـلـ', final: 'ـل' },
    examples: [
      { word: 'لَيْمُون', meaning: 'ليمون السوق والعصير البارد', emoji: '🍋', highlightLetter: 'ل', syllables: ['لَيْـ', 'ـمُو', 'نْ'], egyptianAudio: 'لَيْمُون... عصير ليمون مثلج ومنعش' },
      { word: 'لَحْم', meaning: 'جزارة اللحمة البلدي', emoji: '🥩', highlightLetter: 'ل', syllables: ['لَحْـ', 'ـمْ'], egyptianAudio: 'لَحْم... جزارة اللحوم البلدي' },
      { word: 'لَافِتَة', meaning: 'يافطة المحل والمحطة في الشارع', emoji: '🪧', highlightLetter: 'ل', syllables: ['لَا', 'فِـ', 'ـتَة'], egyptianAudio: 'لَافِتَة... يافطة الشارع والمحطة' },
    ],
  },
  {
    letter: 'م',
    name: 'Meem',
    nameAr: 'مِيم',
    egyptianPhonic: 'الميم راس صغيرة مدورة وعصاية نازلة تحت السطر.. ميم مصر أم الدنيا',
    strokeGuide: {
      steps: ['١. دايرة صغيرة قاعدة على السطر', '٢. خط صغير على السطر', '٣. انزل بعصاية مستقيمة تحت السطر'],
      audioTip: 'الميم شفايفك الاتنين يقفلوا مع بعض برقة: مـ.. مـ.. زي مصر ومترو ومستشفى!',
    },
    soundWithVowels: {
      fatha: { text: 'مَ', label: 'مَ (فتحة)', sound: 'مَ زي مصر ومكتب', egyptianSpoken: 'مَ... ميم فتحة: مَـ!' },
      damma: { text: 'مُ', label: 'مُ (ضمة)', sound: 'مُ زي مستشفى ومترو', egyptianSpoken: 'مُ... ميم ضمة: مُـ!' },
      kasra: { text: 'مِ', label: 'مِ (كسرة)', sound: 'مِ زي مفتاح وميدان', egyptianSpoken: 'مِ... ميم كسرة: مِـ!' },
      sukoon: { text: 'مْ', label: 'مْ (سكون)', sound: 'مْ زي شمس وتمر', egyptianSpoken: 'مْ... ميم سكون: مْ!' },
    },
    forms: { isolated: 'م', initial: 'مـ', medial: 'ـمـ', final: 'ـم' },
    examples: [
      { word: 'مِصْر', meaning: 'أم الدنيا ووطننا الغالي وعزوتنا', emoji: '🇪🇬', highlightLetter: 'م', syllables: ['مِصْـ', 'ـرْ'], egyptianAudio: 'مِصْر... مصر الحبيبة أم الدنيا' },
      { word: 'مِتْرُو', meaning: 'مترو الأنفاق السريع تحت الأرض', emoji: '🚇', highlightLetter: 'م', syllables: ['مِتْـ', 'ـرُو'], egyptianAudio: 'مِتْرُو... مترو الأنفاق السريع' },
      { word: 'مُسْتَشْفَى', meaning: 'المستشفى والمركز الطبي للعلاج', emoji: '🏥', highlightLetter: 'م', syllables: ['مُسْـ', 'ـتَشْـ', 'ـفَى'], egyptianAudio: 'مُسْتَشْفَى... المستشفى لعلاج المرضى' },
    ],
  },
  {
    letter: 'ن',
    name: 'Noon',
    nameAr: 'نُون',
    egyptianPhonic: 'النون طبق غويط بينزل تحت السطر وفوقيه نقطة واحدة زي اللؤلؤة',
    strokeGuide: {
      steps: ['١. سنة صغيرة فوق السطر', '٢. انزل بطبق غويط بيلف تحت السطر ويطلع', '٣. حط نقطة واحدة في النص من فوق'],
      audioTip: 'النون طبقها بينزل تحت السطر مش زي الباء المسطحة، ونقطتها في النص: نـ.. نـ.. زي نور ونيل!',
    },
    soundWithVowels: {
      fatha: { text: 'نَ', label: 'نَ (فتحة)', sound: 'نَ زي نيل ونور', egyptianSpoken: 'نَ... نون فتحة: نَـ!' },
      damma: { text: 'نُ', label: 'نُ (ضمة)', sound: 'نُ زي نور ونجوم', egyptianSpoken: 'نُ... نون ضمة: نُـ!' },
      kasra: { text: 'نِ', label: 'نِ (كسرة)', sound: 'نِ زي نسر ونظام', egyptianSpoken: 'نِ... نون كسرة: نِـ!' },
      sukoon: { text: 'نْ', label: 'نْ (سكون)', sound: 'نْ زي بنك وفندق', egyptianSpoken: 'نْ... نون سكون: نْ!' },
    },
    forms: { isolated: 'ن', initial: 'نـ', medial: 'ـنـ', final: 'ـن' },
    examples: [
      { word: 'نِيل', meaning: 'نيل مصر العذب شريان الحياة', emoji: '⛵', highlightLetter: 'ن', syllables: ['نِيـ', 'ـلْ'], egyptianAudio: 'نِيل... نيل مصر العذب وشريان الحياة' },
      { word: 'نُور', meaning: 'نور العلم والقراءة والتنوير', emoji: '✨', highlightLetter: 'ن', syllables: ['نُو', 'رْ'], egyptianAudio: 'نُور... نور العلم اللي بينور حياتك' },
      { word: 'نَمِرَة', meaning: 'نمرة العربية ونمرة التليفون والبطاقة', emoji: '🔢', highlightLetter: 'ن', syllables: ['نَـ', 'مِـ', 'ـرَة'], egyptianAudio: 'نَمِرَة... نمرة التليفون والعربية' },
    ],
  },
  {
    letter: 'هـ',
    name: 'Haa (Soft)',
    nameAr: 'هَاء',
    egyptianPhonic: 'الهاء دايرة كبيرة وجواها دايرة صغيورة بتلف على السطر زي الفيونكة',
    strokeGuide: {
      steps: ['١. قوس كوبري كبير فوق السطر', '٢. لفة دايرة صغيرة في قلبه', '٣. شد خط على السطر للشمال'],
      audioTip: 'الهاء بتخرج بنفس هادي من الصدر: هـ.. هـ.. زي هرم وهدية!',
    },
    soundWithVowels: {
      fatha: { text: 'هَـ', label: 'هَـ (فتحة)', sound: 'هَـ زي هرم وهدية', egyptianSpoken: 'هَـ... هاء فتحة: هَـ!' },
      damma: { text: 'هُـ', label: 'هُـ (ضمة)', sound: 'هُـ زي هدوء وهدهد', egyptianSpoken: 'هُـ... هاء ضمة: هُـ!' },
      kasra: { text: 'هِـ', label: 'هِـ (كسرة)', sound: 'هِـ زي هلال وهندسة', egyptianSpoken: 'هِـ... هاء كسرة: هِـ!' },
      sukoon: { text: 'هْـ', label: 'هْـ (سكون)', sound: 'هْـ زي مهد وفهد', egyptianSpoken: 'هْـ... هاء سكون: هْـ!' },
    },
    forms: { isolated: 'ه', initial: 'هـ', medial: 'ـهـ', final: 'ـه' },
    examples: [
      { word: 'هَرَم', meaning: 'أهرامات الجيزة الخالدة فخر مصر', emoji: '🔺', highlightLetter: 'هـ', syllables: ['هَـ', 'رَ', 'مْ'], egyptianAudio: 'هَرَم... أهرامات مصر العظيمة' },
      { word: 'هِلَال', meaning: 'هلال شهر رمضان المبارك', emoji: '🌙', highlightLetter: 'هـ', syllables: ['هِـ', 'لَا', 'لْ'], egyptianAudio: 'هِلَال... هلال رمضان والبركة' },
      { word: 'هَدِيَّة', meaning: 'هدية الأحباب والأولاد الغاليين', emoji: '🎁', highlightLetter: 'هـ', syllables: ['هَـ', 'دِيْـ', 'ـيَة'], egyptianAudio: 'هَدِيَّة... هدية المحبة بين الناس' },
    ],
  },
  {
    letter: 'و',
    name: 'Waaw',
    nameAr: 'وَاو',
    egyptianPhonic: 'الواو راس مدورة قاعدة على السطر وجسم بيتزحلق تحت السطر زي الراء',
    strokeGuide: {
      steps: ['١. دايرة صغيرة قاعدة على السطر', '٢. زحليقة منحنية بتنزل تحت السطر'],
      audioTip: 'الواو تضم شفايفك الاتنين في دايرة: وَ.. وَ.. زي وطن وورد وورقة!',
    },
    soundWithVowels: {
      fatha: { text: 'وَ', label: 'وَ (فتحة)', sound: 'وَ زي وطن وورد', egyptianSpoken: 'وَ... واو فتحة: وَـ!' },
      damma: { text: 'وُ', label: 'وُ (ضمة)', sound: 'وُ زي ورود ووجوه', egyptianSpoken: 'وُ... واو ضمة: وُـ!' },
      kasra: { text: 'وِ', label: 'وِ (كسرة)', sound: 'وِ زي وسام ووفاء', egyptianSpoken: 'وِ... واو كسرة: وِـ!' },
      sukoon: { text: 'وْ', label: 'وْ (سكون)', sound: 'وْ زي يوم ونوم', egyptianSpoken: 'وْ... واو سكون: وْ!' },
    },
    forms: { isolated: 'و', initial: 'و', medial: 'ـو', final: 'ـو' },
    examples: [
      { word: 'وَطَن', meaning: 'وطننا وعزوتنا وأهلنا الكرام', emoji: '🏡', highlightLetter: 'و', syllables: ['وَ', 'طَـ', 'ـنْ'], egyptianAudio: 'وَطَن... وطننا مصر الغالي' },
      { word: 'وَرْد', meaning: 'الورد البلدي الجميل والفل', emoji: '🌹', highlightLetter: 'و', syllables: ['وَرْ', 'دْ'], egyptianAudio: 'وَرْد... ورد وفل وياسمين' },
      { word: 'وَرْقَة', meaning: 'ورقة العقد والشهادة الرسمية', emoji: '📄', highlightLetter: 'و', syllables: ['وَرْ', 'قَة'], egyptianAudio: 'وَرْقَة... ورقة العقد والشهادة' },
    ],
  },
  {
    letter: 'ي',
    name: 'Yaa',
    nameAr: 'يَاء',
    egyptianPhonic: 'الياء بطة بتعوم في المية وتحتها نقطتين (نقطتين تحت)',
    strokeGuide: {
      steps: ['١. راس بطة منحنية فوق السطر', '٢. بطن بتنزل تلف تحت السطر وتطلع', '٣. حط نقطتين اتنين تحتها'],
      audioTip: 'الياء زي البطة بتعوم في المية وتحتها نقطتين.. يـ.. يـ.. زي يد ويوم!',
    },
    soundWithVowels: {
      fatha: { text: 'يَ', label: 'يَ (فتحة)', sound: 'يَ زي يد ويوم', egyptianSpoken: 'يَ... ياء فتحة: يَـ!' },
      damma: { text: 'يُ', label: 'يُ (ضمة)', sound: 'يُ زي يسرى ويوسف', egyptianSpoken: 'يُ... ياء ضمة: يُـ!' },
      kasra: { text: 'يِ', label: 'يِ (كسرة)', sound: 'يِ زي يناير', egyptianSpoken: 'يِ... ياء كسرة: يِـ!' },
      sukoon: { text: 'يْ', label: 'يْ (سكون)', sound: 'يْ زي بيت وزيت', egyptianSpoken: 'يْ... ياء سكون: يْ!' },
    },
    forms: { isolated: 'ي', initial: 'يـ', medial: 'ـيـ', final: 'ـي' },
    examples: [
      { word: 'يَد', meaning: 'يد الشغل الشريف والإنتاج والبركة', emoji: '✋', highlightLetter: 'ي', syllables: ['يَـ', 'ـدْ'], egyptianAudio: 'يَد... إيدك الشريفة اللي بتاكل بيها حلال' },
      { word: 'يَوْم', meaning: 'يوم جديد مليان رزق وأمل', emoji: '☀️', highlightLetter: 'ي', syllables: ['يَوْ', 'مْ'], egyptianAudio: 'يَوْم... يوم جديد مليان خير ورزق' },
      { word: 'يَمَامَة', meaning: 'يمام الصباح على الشباك والنيل', emoji: '🕊️', highlightLetter: 'ي', syllables: ['يَـ', 'مَا', 'مَة'], egyptianAudio: 'يَمَامَة... يمام الصباح المغرد' },
    ],
  },
];

export interface WordBuildingCard {
  word: string;
  letters: string[];
  syllables: string[];
  meaning: string;
  emoji: string;
  sentence: string;
  egyptianAudio: string;
}

export const WORD_BUILDING_LIST: WordBuildingCard[] = [
  {
    word: 'مِصْر',
    letters: ['م', 'ص', 'ر'],
    syllables: ['مِصْـ', 'ـرْ'],
    meaning: 'بلدنا العظيم وأم الدنيا',
    emoji: '🇪🇬',
    sentence: 'عاشَتْ مِصْرُ حُرَّةً كَرِيمَةً وَرَايَتُهَا مَرْفُوعَةً',
    egyptianAudio: 'مِصْر... ميم وصاد وراء.. مصر أم الدنيا وعزوتنا!',
  },
  {
    word: 'عَيْش',
    letters: ['ع', 'ي', 'ش'],
    syllables: ['عَيْـ', 'ـشْ'],
    meaning: 'الخبز والبركة في كل بيت',
    emoji: '🫓',
    sentence: 'اشْتَرَيْتُ عَيْشاً طَازَجاً مِنَ الْمَخْبَزِ الصَّبَاحَ',
    egyptianAudio: 'عَيْش... عين وياء وشين.. رغيف العيش البلدي وبركة البيت!',
  },
  {
    word: 'بَيْت',
    letters: ['ب', 'ي', 'ت'],
    syllables: ['بَيْـ', 'ـتْ'],
    meaning: 'الدار والأسرة والستر',
    emoji: '🏠',
    sentence: 'بَيْتُنَا مَلِيءٌ بِالْحُبِّ وَالْبَرَكَةِ وَالْخَيْرِ',
    egyptianAudio: 'بَيْت... باء وياء وتاء.. بيتنا العامر بالحب والستر!',
  },
  {
    word: 'نِيل',
    letters: ['ن', 'ي', 'ل'],
    syllables: ['نِيـ', 'ـلْ'],
    meaning: 'نيل مصر العذب وشريان الحياة',
    emoji: '⛵',
    sentence: 'مِيَاهُ النِّيلِ الْعَذْبَةِ سِرُّ الْحَيَاةِ فِي أَرْضِنَا',
    egyptianAudio: 'نِيل... نون وياء ولام.. نيل مصر الجميل شريان الخير!',
  },
  {
    word: 'شَمْس',
    letters: ['ش', 'م', 'س'],
    syllables: ['شَمْـ', 'ـسْ'],
    meaning: 'شمس النهار المنورة',
    emoji: '☀️',
    sentence: 'أَشْرَقَتِ الشَّمْسُ بِنُورِهَا السَّاطِعِ عَلَى الْحُقُولِ',
    egyptianAudio: 'شَمْس... شين وميم وسين.. شمس مصر الدافية المنورة!',
  },
  {
    word: 'سُوق',
    letters: ['س', 'و', 'ق'],
    syllables: ['سُو', 'قْ'],
    meaning: 'سوق الخضار والطلبات',
    emoji: '🛍️',
    sentence: 'ذَهَبْنَا إِلَى السُّوقِ لِشِرَاءِ الْخُضَارِ وَالْفَاكِهَةِ',
    egyptianAudio: 'سُوق... سين وواو وقاف.. سوق الخضار والطلبات!',
  },
  {
    word: 'دَوَاء',
    letters: ['د', 'و', 'ا', 'ء'],
    syllables: ['دَ', 'وَا', 'ءْ'],
    meaning: 'علاج الشفاء والصحة',
    emoji: '💊',
    sentence: 'تَنَاوَلْتُ الدَّوَاءَ فِي مَوْعِدِهِ لِلشِّفَاءِ بِإِذْنِ اللهِ',
    egyptianAudio: 'دَوَاء... دال وواو وألف وهمزة.. دواء الشفاء والعافية!',
  },
  {
    word: 'كِتَاب',
    letters: ['ك', 'ت', 'ا', 'ب'],
    syllables: ['كِـ', 'تَا', 'بْ'],
    meaning: 'كتاب المعرفة والنور',
    emoji: '📚',
    sentence: 'الْقِرَاءَةُ تُنِيرُ دَرْبَ الإِنْسَانِ وَتَفْتَحُ الْعُقُولَ',
    egyptianAudio: 'كِتَاب... كاف وتاء وألف وباء.. الكتاب نور المعرفة!',
  },
];

// Special pedagogical section: Similar Letters Comparison (المتشابهات الصوتية والبصرية)
export interface SimilarLetterGroup {
  id: string;
  title: string;
  subtitle: string;
  whyConfusing: string;
  goldenRule: string;
  letters: Array<{
    char: string;
    dotsDesc: string;
    soundTrait: string;
    sampleWord: string;
    contrastWord?: string;
    audioHint: string;
  }>;
}

export const SIMILAR_LETTERS_GROUPS: SimilarLetterGroup[] = [
  {
    id: 'dots-family',
    title: 'عائلة الأطباق والنقط (ب - ت - ث - ن - ي)',
    subtitle: 'شكلهم شبه بعض، بس مكان وعدد النقط هو السر!',
    whyConfusing: 'في أول ووسط الكلمة بيتكتبوا سنة واحدة، والفرق الوحيد هو النقط.',
    goldenRule: 'احفظ: الباء نقطة تحت 🔻، التاء تفاحتين فوق 🍎🍎، الثاء تلات نقط 🔺، النون نقطة في قلبها ⚪، الياء نقطتين تحت 💧💧.',
    letters: [
      { char: 'بـ', dotsDesc: 'نقطة واحدة تحت السطر', soundTrait: 'بـ.. زي بيت وباب', sampleWord: 'بَيْت', audioHint: 'الباء نقطتها تحت: بـَ' },
      { char: 'تـ', dotsDesc: 'نقطتين اتنين فوق السطر', soundTrait: 'تـ.. زي تمر وتليفون', sampleWord: 'تَمْر', audioHint: 'التاء نقطتين فوق: تـَ' },
      { char: 'ثـ', dotsDesc: 'تلات نقط فوق مع لسان', soundTrait: 'ثـ.. زي ثوم وثوب', sampleWord: 'ثَوْم', audioHint: 'الثاء تلات نقط وطلع لسانك: ثـَ' },
      { char: 'نـ', dotsDesc: 'نقطة واحدة فوق في النص', soundTrait: 'نـ.. زي نور ونيل', sampleWord: 'نُور', audioHint: 'النون نقطة واحدة فوق في النص: نـَ' },
      { char: 'يـ', dotsDesc: 'نقطتين اتنين تحت السطر', soundTrait: 'يـ.. زي يد ويوم', sampleWord: 'يَد', audioHint: 'الياء نقطتين تحت: يـَ' },
    ],
  },
  {
    id: 'sin-vs-saad',
    title: 'السين الرقيقة vs الصاد المفخمة (س / ص)',
    subtitle: 'فرق بسيط في نبرة الصوت بيغير معنى الكلمة تماماً!',
    whyConfusing: 'الاتنين فيهم صفير، بس السين رقيقة هادية والصاد تخينة ممتلئة.',
    goldenRule: 'السين بترققها وتبتسم (سيف)، والصاد بتفخمها وتملا بقك هوا (صيف).',
    letters: [
      { char: 'س', dotsDesc: 'تلات سنان رقيقة', soundTrait: 'رقيقة زي: سَيْف وسُوق', sampleWord: 'سَيْف (سلاح حاد)', audioHint: 'سين رقيقة: سـ.. سـيف' },
      { char: 'ص', dotsDesc: 'كوبري مفخم مع سنة', soundTrait: 'مفخمة قوية زي: صَيْف وصَيْدَلِيَّة', sampleWord: 'صَيْف (فصل الحر والحرارة)', audioHint: 'صاد تخينة ومفخمة: صـ.. صـيف' },
    ],
  },
  {
    id: 'dal-vs-daad',
    title: 'الدال الرقيقة vs الضاد المفخمة (د / ض)',
    subtitle: 'الدال نايمة على السطر، والضاد كوبري قوي بنقطة!',
    whyConfusing: 'حرف الدال والضاد بيتشابهوا في السمع لو المدرس مفرقش في النطق.',
    goldenRule: 'الدال رقيقة وبسيطة (دَم، دَوَاء)، والضاد حرف العرب القوي المفخم (ضَمِير، ضَابِط).',
    letters: [
      { char: 'د', dotsDesc: 'زاوية مفتوحة رقيقة', soundTrait: 'رقيقة: دَار ودَم', sampleWord: 'دَار (بيت)', audioHint: 'دال رقيقة: دَار' },
      { char: 'ض', dotsDesc: 'كوبري بنقطة مفخمة', soundTrait: 'مفخمة: ضَار وضَابِط', sampleWord: 'ضَار (يؤذي)', audioHint: 'ضاد مفخمة قوية: ضَار' },
    ],
  },
  {
    id: 'taa-vs-toaa',
    title: 'التاء الرقيقة vs الطاء المفخمة (ت / ط)',
    subtitle: 'التاء طبق نقطتين، والطاء كوبري بعصاية مستقيمة!',
    whyConfusing: 'كلمة (تِين) فاكهة لذيذة، بينما (طِين) طمي الأرض والزراعة!',
    goldenRule: 'التاء خفيفة على اللسان (تِين)، والطاء قوية تملأ الفم (طِين).',
    letters: [
      { char: 'ت', dotsDesc: 'طبق بنقطتين فوق', soundTrait: 'رقيقة: تِين وتَمْر', sampleWord: 'تِين (فاكهة التين المسكرة)', audioHint: 'تاء رقيقة: تِين' },
      { char: 'ط', dotsDesc: 'كوبري بعصاية طويلة', soundTrait: 'مفخمة: طِين وطَرِيق', sampleWord: 'طِين (طمي الأرض الزراعية)', audioHint: 'طاء مفخمة: طِين' },
    ],
  },
];

// Special pedagogical section: Sun and Moon Lam (اللام الشمسية واللام القمرية)
export interface LamRuleItem {
  type: 'shamsiya' | 'qamariya';
  title: string;
  nameAr: string;
  ruleExplanation: string;
  readingSecret: string;
  soundExample: string;
  signsInEgypt: Array<{
    text: string;
    phoneticSpelling: string; // How to pronounce it naturally
    meaning: string;
    emoji: string;
  }>;
}

export const LAM_RULES: LamRuleItem[] = [
  {
    type: 'qamariya',
    title: 'اللام القمرية (اللام المُنورة اللي بتتنطق واضحة)',
    nameAr: 'الْـقَمَرِيَّة',
    ruleExplanation: 'اللام هنا عليها سكون ناعمة وبتتنطق بوضوح من غير ما تخبيها!',
    readingSecret: 'حط لسانك فوق وانطق اللام كاملة: اَلْـ...',
    soundExample: 'اَلْـمِتْرُو، اَلْـمُسْتَشْفَى، اَلْـقَاهِرَة، اَلْـبَنْك',
    signsInEgypt: [
      { text: 'الْمِتْرُو', phoneticSpelling: 'اَلْـمِتْرُو (اللام واضحة)', meaning: 'محطة المترو السريع', emoji: '🚇' },
      { text: 'الْمُسْتَشْفَى', phoneticSpelling: 'اَلْـمُسْتَشْفَى (اللام واضحة)', meaning: 'مستشفى العلاج', emoji: '🏥' },
      { text: 'الْمَخْبَز', phoneticSpelling: 'اَلْـمَخْبَز (اللام واضحة)', meaning: 'فرن العيش البلدي', emoji: '🥖' },
      { text: 'الْبَنْك', phoneticSpelling: 'اَلْـبَنْك (اللام واضحة)', meaning: 'بنك المعاملات والفلوس', emoji: '🏦' },
    ],
  },
  {
    type: 'shamsiya',
    title: 'اللام الشمسية (اللام اللي بتستخبى في نور الشمس)',
    nameAr: 'الشَّمْسِيَّة',
    ruleExplanation: 'اللام هنا مكتوبة بس لسانك مش بينطقها، بتنط من الألف للحرف اللي بعدها على طول وهو مشدد!',
    readingSecret: 'اوعى تنطق اللام! انطق: إشْـ... إتْـ... إسْـ...',
    soundExample: 'الشَّارع تنطق (إشْـشارع)، التَّحرير تنطق (إتْـتحرير)',
    signsInEgypt: [
      { text: 'التَّحْرِير', phoneticSpelling: 'إتْـتَحْرِير (بدون نطق اللام)', meaning: 'ميدان التحرير ومحطة السادات', emoji: '🏛️' },
      { text: 'الشَّارِع', phoneticSpelling: 'إشْـشَارِع (بدون نطق اللام)', meaning: 'شارع الحي والموقف', emoji: '🛣️' },
      { text: 'السُّوق', phoneticSpelling: 'إسْـسُوق (بدون نطق اللام)', meaning: 'سوق الخضار والطلبات', emoji: '🛍️' },
      { text: 'الصَّيْدَلِيَّة', phoneticSpelling: 'إصْـصَيْدَلِيَّة (بدون نطق اللام)', meaning: 'أجزخانة وصيدلية الدواء', emoji: '⚕️' },
    ],
  },
];

export interface EgyptianBanknote {
  value: number;
  arabicName: string;
  easternDigits: string;
  westernDigits: string;
  colorName: string;
  frontLandmark: string;
  backLandmark: string;
  frontBg: string;
  commonUses: string;
}

export const EGYPTIAN_BANKNOTES: EgyptianBanknote[] = [
  {
    value: 5,
    arabicName: 'خَمْسَةُ جُنَيْهَات',
    easternDigits: '٥ جنيه',
    westernDigits: '5 EGP',
    colorName: 'أخضر مائل للزرقة',
    frontLandmark: 'جامع أحمد بن طولون بالقاهرة',
    backLandmark: 'مركب الشمس ونهر النيل الفرعوني',
    frontBg: 'from-emerald-700 to-teal-800',
    commonUses: 'أجرة ميكروباص مسافة قصيرة، رغيفين حواوشي صغيرين، باكو بسكويت',
  },
  {
    value: 10,
    arabicName: 'عَشَرَةُ جُنَيْهَات (البوليمر الجديدة)',
    easternDigits: '١٠ جنيه',
    westernDigits: '10 EGP',
    colorName: 'برتقالي مائل للبني مع نافذة شفافة',
    frontLandmark: 'مسجد الفتاح العليم بالعاصمة الإدارية',
    backLandmark: 'تمثال حتشبسوت ومكتبة الإسكندرية',
    frontBg: 'from-amber-700 to-orange-900',
    commonUses: 'تذكرة مترو الأنفاق حتى 9 محطات، شاي في المقهى، علبة عصير',
  },
  {
    value: 20,
    arabicName: 'عِشْرُونَ جُنَيْهاً (البوليمر الجديدة)',
    easternDigits: '٢٠ جنيه',
    westernDigits: '20 EGP',
    colorName: 'سماوي وأخضر فاتح مع علامات لمسية',
    frontLandmark: 'مسجد محمد علي بقلعة صلاح الدين',
    backLandmark: 'العجلة الحربية والجيش المصري القديم',
    frontBg: 'from-cyan-700 to-blue-900',
    commonUses: 'ساندوتشين فول وطعمية مع المخلل، أجرة ميكروباص خط متوسط',
  },
  {
    value: 50,
    arabicName: 'خَمْسُونَ جُنَيْهاً',
    easternDigits: '٥٠ جنيه',
    westernDigits: '50 EGP',
    colorName: 'بنفسجي وأرجواني مميز',
    frontLandmark: 'مسجد قجماس الإسحاقي (أبو حريبة) بالدرب الأحمر',
    backLandmark: 'معبد إدفو وحورس الصقر',
    frontBg: 'from-purple-800 to-indigo-950',
    commonUses: 'شراء كيلو طماطم وخيار وبصل من السوق، كارت شحن مسبق الدفع',
  },
  {
    value: 100,
    arabicName: 'مِائَةُ جُنَيْه',
    easternDigits: '١٠٠ جنيه',
    westernDigits: '100 EGP',
    colorName: 'أخضر زيتوني غامق',
    frontLandmark: 'جامع ومدرسة السلطان حسن بالقلعة',
    backLandmark: 'تمثال أبو الهول بالجيزة',
    frontBg: 'from-emerald-900 to-green-950',
    commonUses: 'شراء فرخة بلدي أو لحم مفروم، دفع فاتورة الكهرباء الشهرية العادية',
  },
  {
    value: 200,
    arabicName: 'مِائَتَا جُنَيْه',
    easternDigits: '٢٠٠ جنيه',
    westernDigits: '200 EGP',
    colorName: 'بني برونزي رصين',
    frontLandmark: 'مسجد قايتباي بالصحراء الشرقية',
    backLandmark: 'تمثال الكاتب المصري القديم برمز المعرفة والقراءة',
    frontBg: 'from-yellow-900 to-stone-900',
    commonUses: 'شراء كرتونة بيض وزيت وسكر ورز للبيت، تسوق أسبوعي',
  },
];

export interface LifeScenario {
  id: string;
  category: 'transport' | 'pharmacy' | 'official' | 'market' | 'digital';
  title: string;
  titleAr: string;
  icon: string;
  signText: string;
  signSubtext?: string;
  keyWords: Array<{ word: string; meaning: string }>;
  explanation: string;
  safetyTip: string;
  voiceGuide: string;
}

export const EGYPTIAN_LIFE_SCENARIOS: LifeScenario[] = [
  {
    id: 'metro-tahrir',
    category: 'transport',
    title: 'مترو الأنفاق - محطة التحرير (أنور السادات)',
    titleAr: 'محطة التحرير (السادات)',
    icon: '🚇',
    signText: 'مَحَطَّةُ أَنْوَرِ السَّادَات - مَيْدَانُ التَّحْرِيرِ',
    signSubtext: 'الخط الأول (المرج - حلوان) ↔ الخط الثاني (شبرا - الجيزة)',
    keyWords: [
      { word: 'مَحَطَّة', meaning: 'المكان الذي يقف فيه القطار للركاب' },
      { word: 'التَّحْرِير', meaning: 'أشهر ميدان في وسط البلد بالقاهرة' },
      { word: 'تَبَادُل', meaning: 'مكان الانتقال من قطار لقطار آخر بدون تذكرة جديدة' },
    ],
    explanation: 'تعتبر محطة السادات بميدان التحرير أهم محطة تبادلية بين الخط الأول والخط الثاني للمترو. لو رايح حلوان أو المرج أو الجيزة أو شبرا، هتنزل هنا تغير الخط.',
    safetyTip: 'احرص على الوقوف خلف الخط الأصفر على الرصيف حتى يتوقف القطار تماماً.',
    voiceGuide: 'محطة السادات بميدان التحرير، هنا محطة التبادل بين الخط الأول والخط الثاني لمترو القاهرة. ركز في اليافطة الزرقا.',
  },
  {
    id: 'microbus-ramses',
    category: 'transport',
    title: 'يافطة الميكروباص - رمسيس والعتبة',
    titleAr: 'موقف رمسيس - العتبة',
    icon: '🚐',
    signText: 'رَمْسِيس - عَتَبَة - أَزْهَر',
    signSubtext: 'أجرة الركوب: ٧ جنيهات',
    keyWords: [
      { word: 'رَمْسِيس', meaning: 'محطة القطارات المركزية لمصر' },
      { word: 'عَتَبَة', meaning: 'مركز التجارة والأسواق الشعبية' },
      { word: 'أُجْرَة', meaning: 'الفلوس التي تدفعها للسائق مقابل التوصيلة' },
    ],
    explanation: 'سائقو الميكروباص يضعون لافتة ورقية أو كرتونية على الزجاج الأمامي مكتوب عليها المحطات بالترتيب. ابحث دائماً عن الحرف الأول مثل حرف الراء في رمسيس أو العين في عتبة.',
    safetyTip: 'حضر الفكة أو الأجرة المضبوطة قبل الركوب حتى يسهل عليك الحساب دون ارتباك.',
    voiceGuide: 'ميكروباص رايح رمسيس والعتبة والأزهر. احفظ شكل كلمة رمسيس التي تبدأ بحرف الراء والميم.',
  },
  {
    id: 'pharmacy-prescription',
    category: 'pharmacy',
    title: 'روشتة الدواء ومواعيد الجرعات',
    titleAr: 'تعليمات جرعة الدواء',
    icon: '💊',
    signText: 'قُرْصٌ وَاحِدٌ بَعْدَ الأَكْلِ مَرَّتَيْنِ يَوْمِيّاً (صَبَاحاً وَمَسَاءً)',
    signSubtext: 'تاريخ انتهاء الصلاحية: EXP 12/2028',
    keyWords: [
      { word: 'قُرْص', meaning: 'حبة دواء واحدة (برشامة)' },
      { word: 'بَعْدَ الأَكْل', meaning: 'يؤخذ بعد الانتهاء من وجبة الطعام لحماية المعدة' },
      { word: 'صَلَاحِيَّة', meaning: 'الفترة التي يكون فيها الدواء فعالاً وآمناً' },
    ],
    explanation: 'الصيدلي يكتب علامات سريعة على علبة الدواء: شمس ☀️ تعني الصباح، وقمر 🌙 تعني المساء، ورسمة ملعقة تعني دواء شرب، ورسمة قرص تعني برشام.',
    safetyTip: 'إذا وجدت كلمة EXP متبوعة بتاريخ، فهذا تاريخ الانتهاء. لا تتناول دواء انتهت صلاحيته أبداً.',
    voiceGuide: 'قرص واحد بعد الأكل مرتين في اليوم، صباحاً ومساءً. راقب تاريخ انتهاء الصلاحية المكتوب على العلبة لحماية صحتك.',
  },
  {
    id: 'national-id',
    category: 'official',
    title: 'بطاقة الرقم القومي المصرية (١٤ رقماً)',
    titleAr: 'قراءة الرقم القومي',
    icon: '🆔',
    signText: 'بِطَاقَةُ تَحْقِيقِ الشَّخْصِيَّة - جُمْهُورِيَّةُ مِصْرَ الْعَرَبِيَّة',
    signSubtext: 'الرقم القومي: ٢ ٨٥ ٠٦ ١٥ ٠١ ٠١٢٣ ٤',
    keyWords: [
      { word: 'الرَّقَمُ الْقَوْمِي', meaning: 'الرقم الفريد لكل مواطن مصري ولا يتكرر' },
      { word: 'تَارِيخُ الْمِيلَاد', meaning: 'اليوم والشهر والسنة التي وُلدت فيها' },
      { word: 'الْمُحَافَظَة', meaning: 'المحافظة التي ولدت بها (مثلاً 01 القاهرة، 02 الإسكندرية، 21 الجيزة)' },
    ],
    explanation: 'الرقم القومي سر سهل الفهم: أول رقم من الشمال (2 لمواليد 1900-1999، و 3 لمواليد 2000 فما فوق). يليه سنتين للميلاد، ثم شهر الميلاد، ثم يوم الميلاد!',
    safetyTip: 'لا تعطِ صورة بطاقتك الشخصية لأي شخص غريب، واحتفظ برقمك القومي مسجلاً في مكان آمن.',
    voiceGuide: 'بطاقة تحقيق الشخصية، الرقم القومي مكون من أربعة عشر رقماً يحتوي على تاريخ ميلادك ومحافظتك.',
  },
  {
    id: 'fawry-vodafone',
    category: 'digital',
    title: 'رسائل المحفظة الإلكترونية (فودافون كاش وإنستاباي)',
    titleAr: 'رسالة تحويل رصيد أو فلوس',
    icon: '📱',
    signText: 'تَمَّ اسْتِلَامُ مَبْلَغِ ٥٠٠ جُنَيْهٍ مِنْ رَقَمِ ٠١٠XXXXX. رَصِيدُكَ الْحَالِيُّ هُوَ ٧٥٠ جُنَيْهاً',
    signSubtext: 'كود العملية: 89412 - لا تشارك الرقم السري OTP مع أحد',
    keyWords: [
      { word: 'تَمَّ اسْتِلَام', meaning: 'الفلوس وصلت محفظتك بنجاح' },
      { word: 'رَصِيدُك', meaning: 'المبلغ الإجمالي الموجود في حسابك الآن' },
      { word: 'السِّرِّي', meaning: 'الباسورد الخاص بك ويجب ألا يعرفه مخلوق' },
    ],
    explanation: 'تصلك رسالة SMS واضحة عند استلام أموال أو شحن رصيد. كلمة "استلام" تعني فلوس دخلت، وكلمة "تحويل" أو "خصم" تعني فلوس خرجت من محفظتك.',
    safetyTip: 'لا تعطي الرقم السري (PIN) أو كود التأكيد (OTP) لأي شخص اتصل بيك وادعى أنه موظف خدمة عملاء.',
    voiceGuide: 'رسالة إلكترونية: تم استلام مبلغ خمسمائة جنيه بنجاح. تذكر دائماً ألا تعطي رقمك السري لأي شخص مهما كان.',
  },
  {
    id: 'tamween-card',
    category: 'official',
    title: 'بطاقة التموين الذكية وبون صرف الخبز',
    titleAr: 'قراءة بيانات بطاقة التموين والخبز',
    icon: '🥖',
    signText: 'بِطَاقَةُ التَّمْوِينِ الذَّكِيَّة - عَدَدُ الأَفْرَاد: ٤ - رَصِيدُ نِقَاطِ الْخُبْزِ: ٤٥ جُنَيْهاً',
    signSubtext: 'يُصرف الخبز المدعم يومياً بواقع ٥ أرغفة لكل فرد مسجل بالبطاقة',
    keyWords: [
      { word: 'عَدَدُ الأَفْرَاد', meaning: 'عدد أفراد أسرتك المستفيدين من التموين والعيش' },
      { word: 'نِقَاطُ الْخُبْز', meaning: 'رصيد الفلوس اللي بتاخده سلع مجانية لو وفرت في العيش' },
      { word: 'بَدَّال تَمْوِينِي', meaning: 'المنفذ أو البقال المعتمد لصرف السكر والزيت' },
    ],
    explanation: 'بون التموين يوضح عدد الأرغفة المتبقية لك وفارق نقاط الخبز التي يمكنك استبدالها بسلع غذائية مجانية. انظر دائماً لرقم عدد الأفراد ورصيد النقاط.',
    safetyTip: 'لا تترك بطاقتك التموينية أو رقمك السري عند المخبز أو البقال أبداً، واطلب دائماً البون الورقي بعد الصرف.',
    voiceGuide: 'بطاقة التموين الذكية: اعرف عدد أفراد أسرتك ورصيد نقاط الخبز لتصرف سلعك التموينية بأمان ودقة.',
  },
  {
    id: 'electricity-meter',
    category: 'official',
    title: 'شاشة كارت عداد الكهرباء الذكي مسبق الدفع',
    titleAr: 'قراءة رصيد وشريحة عداد الكهرباء',
    icon: '⚡',
    signText: 'عَدَّادُ كَهْرَبَاءٍ مُسْبَقُ الدَّفْع - الرَّصِيدُ: ٨٥٫٥٠ جُنَيْهاً - الشَّرِيحَةُ: ٢',
    signSubtext: 'تنبيه: اللمبة الحمراء تنبض عند انخفاض الرصيد لأقل من ٢٠ جنيهاً',
    keyWords: [
      { word: 'الرَّصِيد', meaning: 'المبلغ المتبقي بالجنيه لتشغيل النور والأجهزة' },
      { word: 'الشَّرِيحَة', meaning: 'مستوى استهلاكك، وكلما زاد استهلاكك ارتفعت الشريحة' },
      { word: 'كَوْدِي', meaning: 'عداد إلكتروني يعمل بالكارت الذكي وشحن الرصيد' },
    ],
    explanation: 'شاشة العداد الكودي تظهر الرصيد المتبقي بالجنيه ورقم الشريحة الحالية. إذا ومضت اللمبة الحمراء أو أصدر صفارة إنذار، فاشحن الكارت فوراً من أي ماكينة فوري أو مركز شحن.',
    safetyTip: 'قبل أن تذهب لشحن الكارت، ضعه في العداد أولاً حتى يسجل قراءة الاستهلاك ويتم شحنه بصورة صحيحة.',
    voiceGuide: 'عداد الكهرباء مسبق الدفع: راقب الرصيد المتبقي ورقم الشريحة وتجنب انقطاع التيار بشحن الكارت في موعده.',
  },
  {
    id: 'government-hotlines',
    category: 'official',
    title: 'منظومة الشكاوى والخدمات الحكومية الموحدة',
    titleAr: 'أرقام الخدمات والمعاشات والتضامن',
    icon: '🏛️',
    signText: 'مَجْلِسُ الْوُزَرَاءِ - مَنْظُومَةُ الشَّكَاوَى الْحُكُومِيَّةِ الْمُوَحَّدَةِ: ١٦٥٢٨',
    signSubtext: 'تكافل وكرامة: 15044 - نجدة الطفل: 16000 - شكاوى المرأة: 15115',
    keyWords: [
      { word: 'شَكَاوَى حُكُومِيَّة', meaning: 'خدمة مجانية لحل أي مشكلة للمواطن مع المصالح والوزارات' },
      { word: 'تَكَافُل وَكَرَامَة', meaning: 'الدعم النقدي الشهري للأسر الأولى بالرعاية وكبار السن' },
      { word: 'خَطٌّ سَاخِن', meaning: 'رقم هاتف مباشر ومجاني تستطيع الاتصال به في أي وقت' },
    ],
    explanation: 'الدولة المصرية توفر أرقاماً ساخنة سريعة لحل مشكلات المعاشات، العلاج على نفقة الدولة، الشكاوى ضد أي جهة، أو التقديم على بطاقة الخدمات المتكاملة.',
    safetyTip: 'كل هذه الخطوط مجانية ومخصصة لخدمتك، ولا تدفع أي رسوم أو مبالغ لأي وسيط.',
    voiceGuide: 'أرقام الخدمات الحكومية: منظومة الشكاوى 16528، وتكافل وكرامة 15044، لخدمة كل مواطن ومواطنة في مصر.',
  },
];

export interface QuizQuestion {
  id: string;
  type: 'phonics' | 'word' | 'money' | 'scenario' | 'similar' | 'lam';
  question: string;
  audioPrompt: string;
  options: string[];
  correctIndex: number;
  explanation: string;
  badge: string;
}

export const QUIZ_BANK: QuizQuestion[] = [
  {
    id: 'q1',
    type: 'similar',
    question: 'أي من الحروف التالية تحته نقطة واحدة: بـ أم تـ أم نـ؟',
    audioPrompt: 'انهي حرف من دول تحته نقطة واحدة تحت السطر؟',
    options: ['بـ (باء)', 'تـ (تاء)', 'نـ (نون)', 'يـ (ياء)'],
    correctIndex: 0,
    explanation: 'حرف الباء تحته نقطة واحدة زي البرتقالة تحت الطبق.',
    badge: 'تمييز النقط',
  },
  {
    id: 'q2',
    type: 'lam',
    question: 'عند قراءة لافتة (التَّحْرِير)، كيف ننطقها بالصوت الصحيح؟',
    audioPrompt: 'يافطة التحرير، هل ننطق اللام ولا ننط من الألف للتاء؟',
    options: ['إتْـتَحْرِير (لام شمسية لا تُنطق)', 'اَلْـتَحْرِير (ننطق اللام واضحة)', 'تَحْرِير بدون ألف', 'رَمْسِيس'],
    correctIndex: 0,
    explanation: 'كلمة التحرير بها لام شمسية، فننطقها مباشرة (إتْـتَحْرِير).',
    badge: 'سر اليافطة',
  },
  {
    id: 'q3',
    type: 'word',
    question: 'ما هي الكلمة التي تتكون من المقاطع: [ مَكْـ ] + [ ـتَبْ ]؟',
    audioPrompt: 'ما هي الكلمة التي تتكون من مقطع مك ومقطع تب؟',
    options: ['مَكْتَب 🏢', 'مَسْجِد 🕌', 'مَصْنَع 🏭', 'مَطْبَخ 🍳'],
    correctIndex: 0,
    explanation: 'مَكْ + تَب = مَكْتَب، المكان الذي نعمل ونكتب فيه.',
    badge: 'تكوين المقاطع',
  },
  {
    id: 'q4',
    type: 'money',
    question: 'اشتريت طلبات من البقالة بـ ٣٥ جنيهاً، وأعطيت البائع ورقة ٥٠ جنيهاً. كم يرجع لك الباقي؟',
    audioPrompt: 'معاك خمسين جنيه واشتريت طلبات بخمسة وثلاثين جنيه، كم يكون الباقي؟',
    options: ['١٥ جنيهاً', '١٠ جنيهات', '٢٠ جنيهاً', '٥ جنيهات'],
    correctIndex: 0,
    explanation: '٥٠ ناقص ٣٥ يساوي ١٥ جنيهاً (ورقة ١٠ جنيهات وورقة ٥ جنيهات).',
    badge: 'حساب الفلوس',
  },
  {
    id: 'q5',
    type: 'scenario',
    question: 'رأيت لافتة على واجهة محل مكتوب عليها (صَيْدَلِيَّة). ماذا يقدم هذا المكان؟',
    audioPrompt: 'مكان عليه يافطة صيدلية، ماذا يقدم هذا المكان؟',
    options: ['الأدوية والعلاج الطبي 💊', 'العيش والمخبوزات 🥖', 'إصلاح السيارات 🚗', 'شراء الخضار 🥕'],
    correctIndex: 0,
    explanation: 'الصيدلية (الأجزخانة) هي المكان المتخصص في صرف وتوفير الأدوية والعلاج.',
    badge: 'مواقف الشارع',
  },
  {
    id: 'q6',
    type: 'scenario',
    question: 'ما هو رقم طوارئ الإسعاف المعتمد في جمهورية مصر العربية؟',
    audioPrompt: 'ما هو رقم هاتف طوارئ الإسعاف في مصر؟',
    options: ['١٢٣ (123) 🚑', '١٢٢ (122) 🚓', '١٨٠ (180) 🚒', '١٢٩ (129) 🔥'],
    correctIndex: 0,
    explanation: 'رقم الإسعاف في مصر هو ١٢٣، والشرطة ١٢٢، والمطافئ ١٨٠.',
    badge: 'أرقام الطوارئ',
  },
];
