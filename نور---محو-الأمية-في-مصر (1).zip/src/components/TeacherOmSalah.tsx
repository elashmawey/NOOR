import React, { useState } from 'react';
import { Volume2, Send, Sparkles, MessageCircle, RefreshCw, UserCheck, Heart, Mic, MicOff } from 'lucide-react';
import { audioService } from '../utils/audio';

export const TeacherOmSalah: React.FC = () => {
  const [messages, setMessages] = useState<Array<{ sender: 'user' | 'teacher'; text: string; practice?: string }>>([
    {
      sender: 'teacher',
      text: 'أهلاً بيك يا غالي وسلام الله عليك! أنا أخوك ومعلمك "عم صلاح". أنا هنا في ضهرك خطوة بخطوة عشان تتعلم القراءة والكتابة والحساب براحتك وبأعلى كرامة. اسألني أي سؤال يخطر في بالك ومتقلقش من أي حاجة!',
      practice: 'اضغط على زرار المايك واتكلم بصوتك لو مش عايز تكتب، أو اضغط على السماعة لسماعي.',
    },
  ]);
  const [inputText, setInputText] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isListening, setIsListening] = useState<boolean>(false);

  const startVoiceInput = () => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      audioService.speak('متصفحك لا يدعم المايك، تقدر تختار من الأسئلة السريعة تحت.');
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.lang = 'ar-EG';
      recognition.interimResults = false;
      recognition.maxAlternatives = 1;

      setIsListening(true);
      audioService.playSound('pop');
      audioService.speak('اتكلم يا غالي، أنا سامعك...');

      recognition.onresult = (event: any) => {
        const spoken = event.results[0][0].transcript;
        setIsListening(false);
        if (spoken) {
          setInputText(spoken);
          handleSendMessage(spoken);
        }
      };

      recognition.onerror = () => {
        setIsListening(false);
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognition.start();
    } catch (e) {
      setIsListening(false);
    }
  };

  const quickQuestions = [
    'إزاي أفرق بين حرف الباء والتاء والثاء والنون؟',
    'يعني إيه تاريخ انتهاء الصلاحية المكتوب على الدواء؟',
    'إزاي أعرف ميكروباص رمسيس من يافطته في الموقف؟',
    'عايز جملة سهلة أتدرب على قراءتها النهاردة',
  ];

  const handleSendMessage = async (textToSend?: string) => {
    const q = (textToSend || inputText).trim();
    if (!q || isLoading) return;

    audioService.playSound('pop');
    setMessages((prev) => [...prev, { sender: 'user', text: q }]);
    setInputText('');
    setIsLoading(true);

    try {
      const res = await fetch('/api/gemini/ask-teacher', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ question: q }),
      });
      const data = await res.json();
      const replyText = data.reply || 'الله ينور عليك يا بطل. خطوة بخطوة القراءة هتنور طريقك!';
      const practice = data.suggestedPractice;

      setMessages((prev) => [
        ...prev,
        {
          sender: 'teacher',
          text: replyText,
          practice: practice,
        },
      ]);

      audioService.playSound('correct');
      audioService.speak(replyText);
    } catch (e) {
      console.error(e);
      setMessages((prev) => [
        ...prev,
        {
          sender: 'teacher',
          text: 'يا غالي، خليك واثق في نفسك دايماً. العلم نور، وكل يوم بتتعلم فيه حرف بتبني بيه مستقبلك وعزوتك.',
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className="bg-gradient-to-r from-amber-800 via-yellow-800 to-amber-950 rounded-3xl p-6 sm:p-8 text-white shadow-lg relative overflow-hidden">
        <div className="relative z-10 max-w-2xl">
          <div className="inline-flex items-center gap-2 bg-amber-500/40 text-amber-100 font-bold px-3 py-1 rounded-full text-xs sm:text-sm border border-amber-400/40 mb-3">
            <Heart className="w-4 h-4 text-rose-300" />
            المعلم الذكي: عم صلاح الصبور
          </div>
          <h1 className="text-2xl sm:text-4xl font-black font-['Alexandria',sans-serif] leading-tight mb-2">
            معلمك الشخصي في القراءة والكتابة
          </h1>
          <p className="text-amber-100 text-sm sm:text-base leading-relaxed">
            صديقك الصبور اللي بيشرح لك أي كلمة أو استفسار بالعامية المصرية البسيطة وبالصوت الواضح بدون أي إحراج.
          </p>
        </div>
      </div>

      {/* Main Chat Interface */}
      <div className="bg-white rounded-3xl border-2 border-amber-300 shadow-md flex flex-col h-[650px] overflow-hidden">
        {/* Chat Header */}
        <div className="p-4 sm:p-5 bg-amber-50/80 border-b border-amber-200 flex items-center justify-between">
          <div className="flex items-center gap-3.5">
            <div className="w-13 h-13 rounded-2xl bg-amber-600 text-white flex items-center justify-center text-3xl shadow-sm">
              👨‍🏫
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-black text-slate-900">عم صلاح</h3>
                <span className="text-[11px] bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded-full border border-emerald-300 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-ping" />
                  متاح لخدمتك بالصوت
                </span>
              </div>
              <p className="text-xs text-slate-600 font-medium">معلم محو أمية مصري خبير</p>
            </div>
          </div>

          <button
            onClick={() => {
              audioService.speak(
                'أنا عم صلاح، اسألني في أي حاجة واقفة قدامك، إزاي تنطق كلمة، إزاي تفهم يافطة، أو إزاي تكتب اسمك.'
              );
            }}
            className="flex items-center gap-1.5 px-3 py-2 bg-amber-200/70 hover:bg-amber-300/70 text-amber-950 font-bold rounded-xl text-xs sm:text-sm border border-amber-300 transition-colors"
          >
            <Volume2 className="w-4 h-4 text-amber-800" />
            <span className="hidden sm:inline">صوت عم صلاح</span>
          </button>
        </div>

        {/* Message History */}
        <div className="flex-1 p-4 sm:p-6 overflow-y-auto space-y-4 bg-slate-50/50">
          {messages.map((m, idx) => (
            <div
              key={idx}
              className={`flex items-start gap-3 ${m.sender === 'user' ? 'flex-row-reverse' : ''}`}
            >
              <div
                className={`w-10 h-10 rounded-xl flex items-center justify-center text-lg shrink-0 ${
                  m.sender === 'user' ? 'bg-slate-800 text-white' : 'bg-amber-500 text-white shadow-xs'
                }`}
              >
                {m.sender === 'user' ? '👤' : '👨‍🏫'}
              </div>

              <div
                className={`max-w-[85%] sm:max-w-[75%] rounded-3xl p-4 sm:p-5 space-y-2.5 ${
                  m.sender === 'user'
                    ? 'bg-slate-900 text-white rounded-tr-xs'
                    : 'bg-white border-2 border-amber-200/80 text-slate-800 rounded-tl-xs shadow-xs'
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <p className="text-sm sm:text-base font-semibold leading-relaxed whitespace-pre-wrap">
                    {m.text}
                  </p>
                  {m.sender === 'teacher' && (
                    <button
                      onClick={() => audioService.speak(m.text)}
                      className="p-1.5 hover:bg-amber-100 text-amber-700 rounded-xl transition-colors shrink-0"
                      title="استمع للرد"
                    >
                      <Volume2 className="w-4 h-4" />
                    </button>
                  )}
                </div>

                {m.practice && (
                  <div className="p-3 bg-amber-50/80 border border-amber-300/80 rounded-2xl text-xs sm:text-sm text-amber-950 flex items-start gap-2">
                    <span className="text-base">📌</span>
                    <span className="font-medium">{m.practice}</span>
                  </div>
                )}
              </div>
            </div>
          ))}

          {isLoading && (
            <div className="flex items-center gap-3 text-slate-500 text-xs font-bold animate-pulse">
              <div className="w-10 h-10 rounded-xl bg-amber-500 text-white flex items-center justify-center">
                👨‍🏫
              </div>
              <div className="bg-white border border-amber-200 px-4 py-2.5 rounded-2xl flex items-center gap-2">
                <RefreshCw className="w-4 h-4 animate-spin text-amber-600" />
                <span>عم صلاح بيفكر وبيجهز الرد عشانك...</span>
              </div>
            </div>
          )}
        </div>

        {/* Quick Suggestion Chips */}
        <div className="px-4 py-2 bg-white border-t border-slate-100 flex items-center gap-2 overflow-x-auto no-scrollbar">
          <span className="text-[11px] font-bold text-slate-400 shrink-0">أسئلة شائعة:</span>
          {quickQuestions.map((q, i) => (
            <button
              key={i}
              onClick={() => handleSendMessage(q)}
              className="text-xs bg-amber-50 hover:bg-amber-100 text-amber-900 font-bold px-3 py-1.5 rounded-xl border border-amber-200 shrink-0 transition-colors"
            >
              {q}
            </button>
          ))}
        </div>

        {/* Chat Input Bar */}
        <div className="p-4 bg-white border-t border-amber-200">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage();
            }}
            className="flex items-center gap-2"
          >
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="اكتب أو اضغط على المايك واتكلم بصوتك..."
              className="flex-1 bg-slate-50 border-2 border-slate-300 focus:border-amber-500 rounded-2xl px-4 py-3 text-sm sm:text-base font-bold text-slate-900 outline-none transition-all placeholder-slate-400"
            />
            {/* Voice Input Microphone Button */}
            <button
              type="button"
              onClick={startVoiceInput}
              disabled={isLoading}
              className={`p-3 rounded-2xl border-2 transition-all flex items-center justify-center ${
                isListening
                  ? 'bg-rose-500 text-white border-rose-600 animate-pulse shadow-md'
                  : 'bg-amber-100 hover:bg-amber-200 text-amber-900 border-amber-300'
              }`}
              title="اتكلم بالصوت بدل الكتابة"
            >
              {isListening ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5 text-amber-800" />}
            </button>
            <button
              type="submit"
              disabled={isLoading || !inputText.trim()}
              className="px-5 py-3 bg-amber-600 hover:bg-amber-700 disabled:opacity-50 text-white font-extrabold rounded-2xl text-sm sm:text-base flex items-center gap-2 shadow-sm transition-all"
            >
              <span className="hidden sm:inline">إرسال</span>
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
