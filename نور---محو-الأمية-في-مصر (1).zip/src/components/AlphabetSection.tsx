import React, { useState } from 'react';
import { Volume2, PenTool, CheckCircle, ArrowRight, Sparkles, HelpCircle } from 'lucide-react';
import { ARABIC_ALPHABET, LetterInfo } from '../data/literacyData';
import { audioService } from '../utils/audio';

interface AlphabetSectionProps {
  onSelectLetterForCanvas: (letter: string) => void;
}

export const AlphabetSection: React.FC<AlphabetSectionProps> = ({ onSelectLetterForCanvas }) => {
  const [selectedLetter, setSelectedLetter] = useState<LetterInfo>(ARABIC_ALPHABET[0]);
  const [activeVowel, setActiveVowel] = useState<'fatha' | 'damma' | 'kasra' | 'sukoon'>('fatha');
  const [learnedLetters, setLearnedLetters] = useState<string[]>(['أ', 'ب']);

  const playLetterAudio = (letterInfo: LetterInfo) => {
    audioService.playSound('pop');
    audioService.speak(
      `حرف ${letterInfo.nameAr}. ${letterInfo.egyptianPhonic}. ${letterInfo.soundWithVowels.fatha.egyptianSpoken}`
    );
  };

  const toggleLearned = (letter: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (learnedLetters.includes(letter)) {
      setLearnedLetters(learnedLetters.filter((l) => l !== letter));
    } else {
      setLearnedLetters([...learnedLetters, letter]);
      audioService.cheerSuccess(`حرف ${letter}`);
    }
  };

  return (
    <div className="space-y-8">
      {/* Top Banner & Encouragement */}
      <div className="bg-gradient-to-r from-amber-600 via-amber-700 to-yellow-700 rounded-3xl p-6 sm:p-8 text-white shadow-lg relative overflow-hidden">
        <div className="relative z-10 max-w-2xl">
          <div className="inline-flex items-center gap-2 bg-amber-500/40 text-amber-100 font-bold px-3 py-1 rounded-full text-xs sm:text-sm border border-amber-400/40 mb-3">
            <Sparkles className="w-4 h-4 text-amber-200" />
            المستوى الأول: الحروف الهجائية الثمانية والعشرون
          </div>
          <h1 className="text-2xl sm:text-4xl font-black font-['Alexandria',sans-serif] leading-tight mb-2">
            الحروف مفتاح القراءة والنور
          </h1>
          <p className="text-amber-100 text-sm sm:text-base leading-relaxed mb-4">
            اضغط على أي حرف لسماع نطق عم صلاح بالعامية المصرية الدافئة، واعرف شكله وطريقة رسمه خطوة بخطوة.
          </p>

          <div className="flex flex-wrap items-center gap-4 text-xs sm:text-sm font-semibold text-amber-100 bg-black/15 p-3 rounded-2xl border border-white/10 w-fit">
            <span>
              الحروف التي أتقنتها: <b className="text-white text-base">{learnedLetters.length}</b> من ٢٨
            </span>
            <div className="w-24 sm:w-36 h-2.5 bg-black/30 rounded-full overflow-hidden">
              <div
                className="h-full bg-emerald-400 rounded-full transition-all duration-500"
                style={{ width: `${(learnedLetters.length / 28) * 100}%` }}
              />
            </div>
          </div>
        </div>

        {/* Decorative soft Arabic calligraphic mark */}
        <div className="absolute left-4 -bottom-6 text-9xl font-black text-white/10 select-none pointer-events-none font-['Alexandria',sans-serif]">
          أ ب ت
        </div>
      </div>

      {/* Main Interactive Grid and Focused Letter Viewer */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Letters Grid (Cols 1-7) */}
        <div className="lg:col-span-7 bg-white rounded-3xl p-5 sm:p-7 border border-amber-200/80 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <h2 className="text-lg sm:text-xl font-extrabold text-slate-900 flex items-center gap-2">
              <span>اختر حرفاً للبدء:</span>
            </h2>
            <button
              onClick={() => {
                audioService.speak(
                  'الحروف الهجائية ثمانية وعشرون حرفاً. كل حرف له اسم وصوت وشكل على السطر. اضغط على أي حرف لفتحه وسماع نصيحة عم صلاح.'
                );
              }}
              className="flex items-center gap-1.5 text-xs sm:text-sm font-bold text-amber-800 hover:text-amber-900 bg-amber-50 px-2.5 py-1 rounded-lg border border-amber-200"
            >
              <Volume2 className="w-4 h-4 text-amber-600" />
              <span>استمع للإرشادات</span>
            </button>
          </div>

          <div className="grid grid-cols-4 sm:grid-cols-7 gap-2.5 sm:gap-3">
            {ARABIC_ALPHABET.map((item) => {
              const isSelected = selectedLetter.letter === item.letter;
              const isLearned = learnedLetters.includes(item.letter);

              return (
                <div
                  key={item.letter}
                  onClick={() => {
                    setSelectedLetter(item);
                    playLetterAudio(item);
                  }}
                  className={`group relative flex flex-col items-center justify-center p-3 rounded-2xl cursor-pointer transition-all border-2 select-none ${
                    isSelected
                      ? 'bg-amber-500 text-white border-amber-600 shadow-md scale-105 z-10'
                      : isLearned
                      ? 'bg-emerald-50 text-emerald-950 border-emerald-300 hover:border-emerald-400'
                      : 'bg-slate-50 hover:bg-amber-50/80 text-slate-800 border-slate-200 hover:border-amber-300'
                  }`}
                >
                  {/* Learned Badge Indicator */}
                  {isLearned && (
                    <div
                      onClick={(e) => toggleLearned(item.letter, e)}
                      title="تم إتقانه"
                      className="absolute top-1 right-1 text-emerald-600 bg-white rounded-full p-0.5 shadow-xs"
                    >
                      <CheckCircle className="w-3.5 h-3.5" />
                    </div>
                  )}

                  <span className="text-2xl sm:text-3xl font-extrabold font-['Alexandria',sans-serif] mb-0.5">
                    {item.letter}
                  </span>
                  <span
                    className={`text-[11px] font-bold ${
                      isSelected ? 'text-amber-100' : 'text-slate-500'
                    }`}
                  >
                    {item.nameAr}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Focused Detailed Letter Studio (Cols 8-12) */}
        <div className="lg:col-span-5 bg-white rounded-3xl p-6 sm:p-7 border-2 border-amber-300 shadow-md space-y-6">
          {/* Letter Title Banner */}
          <div className="flex items-center justify-between pb-4 border-b border-amber-100">
            <div className="flex items-center gap-4">
              <div className="w-18 h-18 rounded-2xl bg-amber-500 text-white flex items-center justify-center text-4xl sm:text-5xl font-black font-['Alexandria',sans-serif] shadow-md shadow-amber-500/30">
                {selectedLetter.letter}
              </div>
              <div>
                <h3 className="text-2xl sm:text-3xl font-black text-slate-900">
                  حرف {selectedLetter.nameAr}
                </h3>
                <p className="text-slate-600 text-xs sm:text-sm font-semibold">
                  {selectedLetter.egyptianPhonic}
                </p>
              </div>
            </div>

            <button
              onClick={() => playLetterAudio(selectedLetter)}
              className="p-3 bg-amber-100 hover:bg-amber-200 text-amber-900 rounded-2xl transition-colors border border-amber-300 shadow-xs"
              title="نطق الحرف بالصوت المصري"
            >
              <Volume2 className="w-6 h-6" />
            </button>
          </div>

          {/* Phonics & Vowels Section */}
          <div className="space-y-3">
            <h4 className="text-sm font-bold text-slate-700 flex items-center gap-1.5">
              <span>نطق الحرف بالحركات الأربعة بالصوت المصري:</span>
            </h4>
            <div className="grid grid-cols-2 gap-2 sm:gap-2.5">
              {(['fatha', 'damma', 'kasra', 'sukoon'] as const).map((vowelKey) => {
                const vowelData = selectedLetter.soundWithVowels[vowelKey];
                const isActive = activeVowel === vowelKey;
                return (
                  <button
                    key={vowelKey}
                    onClick={() => {
                      setActiveVowel(vowelKey);
                      audioService.playSound('pop');
                      audioService.speak(vowelData.egyptianSpoken || vowelData.sound);
                    }}
                    className={`flex items-center justify-between p-3 rounded-2xl border-2 transition-all ${
                      isActive
                        ? 'bg-amber-50 border-amber-500 text-slate-900 font-bold shadow-xs'
                        : 'bg-slate-50/70 border-slate-200 text-slate-700 hover:bg-amber-50/40 hover:border-amber-300'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <span className="text-xl sm:text-2xl font-black text-amber-700 font-['Alexandria',sans-serif]">
                        {vowelData.text}
                      </span>
                      <span className="text-xs sm:text-sm font-bold">{vowelData.label}</span>
                    </div>
                    <Volume2 className="w-4 h-4 text-amber-600" />
                  </button>
                );
              })}
            </div>
          </div>

          {/* Stroke Drawing Guide (كيف تكتب الحرف بيدك) */}
          <div className="p-4 bg-amber-50/80 border border-amber-200 rounded-2xl space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-black text-amber-950 flex items-center gap-1.5">
                <PenTool className="w-3.5 h-3.5 text-amber-700" />
                طريقة كتابة الحرف على السطر:
              </span>
              <button
                onClick={() => audioService.speak(selectedLetter.strokeGuide.audioTip)}
                className="text-xs font-bold text-amber-800 hover:text-amber-950 flex items-center gap-1"
              >
                <Volume2 className="w-3.5 h-3.5" />
                <span>نصيحة الكتابة</span>
              </button>
            </div>
            <ul className="text-xs font-semibold text-slate-700 space-y-1">
              {selectedLetter.strokeGuide.steps.map((st, idx) => (
                <li key={idx} className="flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-600" />
                  <span>{st}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Letter Forms in Words */}
          <div className="space-y-2 bg-slate-50 p-4 rounded-2xl border border-slate-200">
            <h4 className="text-xs sm:text-sm font-bold text-slate-700">
              أشكال الحرف في الكلمة:
            </h4>
            <div className="grid grid-cols-4 gap-2 text-center">
              <div className="bg-white p-2 rounded-xl border border-slate-200">
                <span className="block text-xs text-slate-400 font-bold">منفصل</span>
                <span className="text-lg font-bold text-slate-800">{selectedLetter.forms.isolated}</span>
              </div>
              <div className="bg-white p-2 rounded-xl border border-slate-200">
                <span className="block text-xs text-slate-400 font-bold">أول الكلمة</span>
                <span className="text-lg font-bold text-slate-800">{selectedLetter.forms.initial}</span>
              </div>
              <div className="bg-white p-2 rounded-xl border border-slate-200">
                <span className="block text-xs text-slate-400 font-bold">وسط الكلمة</span>
                <span className="text-lg font-bold text-slate-800">{selectedLetter.forms.medial}</span>
              </div>
              <div className="bg-white p-2 rounded-xl border border-slate-200">
                <span className="block text-xs text-slate-400 font-bold">آخر الكلمة</span>
                <span className="text-lg font-bold text-slate-800">{selectedLetter.forms.final}</span>
              </div>
            </div>
          </div>

          {/* Egyptian Examples with Syllables and Audio */}
          <div className="space-y-2.5">
            <h4 className="text-sm font-bold text-slate-700">
              أمثلة لكلمات مصرية مع تقسيم المقاطع الصوتية:
            </h4>
            <div className="space-y-2">
              {selectedLetter.examples.map((ex, i) => (
                <div
                  key={i}
                  onClick={() => {
                    audioService.playSound('pop');
                    audioService.speak(ex.egyptianAudio || `${ex.word}. ${ex.meaning}`);
                  }}
                  className="flex items-center justify-between p-3 bg-amber-50/50 hover:bg-amber-100/70 border border-amber-200 rounded-2xl cursor-pointer transition-colors group"
                >
                  <div className="flex items-center gap-3">
                    <span className="text-2xl">{ex.emoji}</span>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-lg font-extrabold text-slate-900 group-hover:text-amber-800">
                          {ex.word}
                        </span>
                        {/* Syllables breakdown pills */}
                        <div className="flex items-center gap-1 text-[11px] font-bold text-purple-700 bg-purple-50 px-2 py-0.5 rounded-lg border border-purple-200">
                          {ex.syllables.map((syl, sIdx) => (
                            <span key={sIdx}>
                              {syl}
                              {sIdx < ex.syllables.length - 1 ? ' + ' : ''}
                            </span>
                          ))}
                        </div>
                      </div>
                      <p className="text-xs text-slate-500 font-medium">{ex.meaning}</p>
                    </div>
                  </div>
                  <Volume2 className="w-5 h-5 text-amber-600 group-hover:scale-110 transition-transform" />
                </div>
              ))}
            </div>
          </div>

          {/* Action CTAs: Tracing Blackboard & Mark Learned */}
          <div className="pt-2 flex flex-col sm:flex-row gap-3">
            <button
              onClick={() => {
                audioService.speak(`يلا نرسم حرف ${selectedLetter.nameAr} على السبورة!`);
                onSelectLetterForCanvas(selectedLetter.letter);
              }}
              className="flex-1 flex items-center justify-center gap-2 py-3 px-4 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded-2xl shadow-sm hover:shadow-md transition-all text-sm"
            >
              <PenTool className="w-4 h-4" />
              <span>ارسم الحرف على السبورة</span>
            </button>

            <button
              onClick={(e) => toggleLearned(selectedLetter.letter, e)}
              className={`py-3 px-4 font-bold rounded-2xl border text-sm flex items-center justify-center gap-2 transition-all ${
                learnedLetters.includes(selectedLetter.letter)
                  ? 'bg-emerald-600 text-white border-emerald-700'
                  : 'bg-slate-100 hover:bg-emerald-50 text-slate-700 hover:text-emerald-800 border-slate-300 hover:border-emerald-300'
              }`}
            >
              <CheckCircle className="w-4 h-4" />
              <span>
                {learnedLetters.includes(selectedLetter.letter)
                  ? 'أتقنت الحرف ✓'
                  : 'أتقنت الحرف؟'}
              </span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
