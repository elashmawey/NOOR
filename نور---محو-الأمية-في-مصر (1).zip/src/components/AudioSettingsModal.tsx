import React, { useState } from 'react';
import {
  X,
  Volume2,
  Sparkles,
  ShieldCheck,
  Check,
  Play,
  Zap,
  Globe2,
  WifiOff,
  User,
  Sliders,
} from 'lucide-react';
import { audioService, AudioMode } from '../utils/audio';

interface AudioSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AudioSettingsModal: React.FC<AudioSettingsModalProps> = ({ isOpen, onClose }) => {
  const [audioMode, setAudioModeState] = useState<AudioMode>(audioService.audioMode);
  const [voicePreference, setVoicePreference] = useState<'salah' | 'eman'>(
    audioService.voicePreference
  );
  const [speechRate, setSpeechRateState] = useState<number>(audioService.speechRate);
  const [isPlayingTest, setIsPlayingTest] = useState<boolean>(false);

  if (!isOpen) return null;

  const handleModeChange = (mode: AudioMode) => {
    setAudioModeState(mode);
    audioService.setAudioMode(mode);
  };

  const handleVoiceChange = (voice: 'salah' | 'eman') => {
    setVoicePreference(voice);
    audioService.voicePreference = voice;
    audioService.playSound('pop');
    if (voice === 'salah') {
      audioService.speak('معاك عم صلاح، مرحب بيك يا بطل!');
    } else {
      audioService.speak('معاك مس إيمان، خطوة بخطوة هنتعلم مع بعض!');
    }
  };

  const handleRateChange = (rate: number) => {
    setSpeechRateState(rate);
    audioService.setSpeechRate(rate);
    audioService.speak(
      rate < 0.8
        ? 'تم ضبط سرعة الصوت لتكون هادئة جداً ومناسبة للتعلم.'
        : 'تم ضبط سرعة الصوت على النمط الطبيعي.'
    );
  };

  const handleTestVoice = () => {
    setIsPlayingTest(true);
    audioService.testVoice();
    setTimeout(() => setIsPlayingTest(false), 3000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in">
      <div className="bg-white rounded-3xl max-w-lg w-full border border-amber-200 shadow-2xl overflow-hidden relative text-right">
        {/* Header */}
        <div className="bg-gradient-to-r from-amber-600 via-amber-700 to-yellow-700 p-6 text-white relative">
          <button
            onClick={onClose}
            className="absolute top-5 left-5 w-8 h-8 rounded-full bg-white/20 hover:bg-white/30 flex items-center justify-center text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-2.5 mb-2">
            <span className="p-2 rounded-xl bg-white/20 text-xl">🎙️</span>
            <div>
              <h2 className="text-xl font-black font-['Alexandria',sans-serif]">
                إعدادات الصوت والنطق المصري
              </h2>
              <span className="text-xs text-amber-200 font-bold">
                تحكم كامل في الصوت المجاني وسرعة النطق والشخصية
              </span>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6 max-h-[75vh] overflow-y-auto">
          {/* Section 1: Audio Engine & Egyptian Voice Status */}
          <div className="space-y-3">
            <label className="text-sm font-black text-slate-900 block">
              محرك الصوت المصري المفعّل:
            </label>

            <div className="p-4 rounded-2xl border-2 border-emerald-500 bg-emerald-50/80 shadow-xs space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-emerald-900 font-black text-xs sm:text-sm">
                  <Sparkles className="w-4 h-4 text-emerald-600" />
                  <span>الصوت المصري الواقعي الأصيل (مع التخزين الدائم)</span>
                </div>
                <span className="w-5 h-5 rounded-full bg-emerald-600 text-white flex items-center justify-center">
                  <Check className="w-3.5 h-3.5 stroke-[3]" />
                </span>
              </div>
              <p className="text-xs text-slate-700 leading-relaxed font-semibold">
                صوت مصري بشري واقعي ١٠٠٪ بنبرة دافئة ومشجعة، مع نظام تخزين ذكي في جهازك يشغّل الحروف والكلمات فورياً وبدون استهلاك للرصيد، متطابق مع أعلى معايير منصات تعليم الكبار.
              </p>
            </div>
          </div>

          {/* Section 2: Egyptian Voice Persona */}
          <div className="space-y-3">
            <label className="text-sm font-black text-slate-900 block">
              اختيار المعلم الصوتي:
            </label>
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => handleVoiceChange('salah')}
                className={`p-3.5 rounded-2xl border-2 flex items-center gap-2.5 transition-all text-right ${
                  voicePreference === 'salah'
                    ? 'bg-amber-100/70 border-amber-600 text-amber-950 font-black'
                    : 'bg-white hover:bg-slate-50 border-slate-200 text-slate-700 font-bold'
                }`}
              >
                <span className="text-2xl">👨‍🏫</span>
                <div>
                  <span className="text-sm block">عم صلاح</span>
                  <span className="text-[11px] text-slate-500 font-normal">صوت وقور وهادئ</span>
                </div>
              </button>

              <button
                onClick={() => handleVoiceChange('eman')}
                className={`p-3.5 rounded-2xl border-2 flex items-center gap-2.5 transition-all text-right ${
                  voicePreference === 'eman'
                    ? 'bg-amber-100/70 border-amber-600 text-amber-950 font-black'
                    : 'bg-white hover:bg-slate-50 border-slate-200 text-slate-700 font-bold'
                }`}
              >
                <span className="text-2xl">👩‍🏫</span>
                <div>
                  <span className="text-sm block">مس إيمان</span>
                  <span className="text-[11px] text-slate-500 font-normal">صوت مشجع ومبهج</span>
                </div>
              </button>
            </div>
          </div>

          {/* Section 3: Speech Pace / Speed */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-sm font-black text-slate-900">
                سرعة النطق والقراءة:
              </label>
              <span className="text-xs font-mono font-bold text-amber-700 bg-amber-50 px-2 py-0.5 rounded-md border border-amber-200">
                {speechRate <= 0.75 ? 'هادئ وبطيء للكبار' : speechRate <= 0.9 ? 'معتدل وطبيعي' : 'سريع'}
              </span>
            </div>

            <div className="grid grid-cols-3 gap-2">
              {[
                { label: 'بطيء جداً (0.7x)', rate: 0.72 },
                { label: 'معتدل (0.85x)', rate: 0.85 },
                { label: 'عادي (1.0x)', rate: 1.0 },
              ].map((opt) => (
                <button
                  key={opt.rate}
                  onClick={() => handleRateChange(opt.rate)}
                  className={`py-2 px-3 rounded-xl text-xs font-bold border transition-all ${
                    Math.abs(speechRate - opt.rate) < 0.05
                      ? 'bg-slate-900 text-white border-slate-900'
                      : 'bg-white hover:bg-slate-100 text-slate-700 border-slate-200'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          {/* Test Voice Button */}
          <div className="pt-2">
            <button
              onClick={handleTestVoice}
              disabled={isPlayingTest}
              className="w-full py-3 bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-700 hover:to-teal-800 text-white rounded-2xl text-xs sm:text-sm font-black shadow-md flex items-center justify-center gap-2 transition-all active:scale-98"
            >
              <Play className="w-4 h-4 fill-current" />
              <span>جرب واستمع لنطق الصوت المصري المجاني الآن</span>
            </button>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500">
          <div className="flex items-center gap-1.5 text-emerald-700 font-bold">
            <ShieldCheck className="w-4 h-4" />
            <span>الصوت مجاني بالكامل وبلا أي تكلفة</span>
          </div>
          <button
            onClick={onClose}
            className="px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-xl"
          >
            تم الحفظ
          </button>
        </div>
      </div>
    </div>
  );
};
