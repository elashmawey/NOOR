import React, { useRef, useState, useEffect } from 'react';
import { PenTool, Eraser, RotateCcw, Download, Sparkles, Volume2, Check } from 'lucide-react';
import { audioService } from '../utils/audio';
import { ARABIC_ALPHABET } from '../data/literacyData';

interface TracingCanvasProps {
  initialLetter?: string;
}

export const TracingCanvas: React.FC<TracingCanvasProps> = ({ initialLetter = 'أ' }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [isDrawing, setIsDrawing] = useState<boolean>(false);
  const [penColor, setPenColor] = useState<string>('#1e3a8a'); // Navy
  const [penWidth, setPenWidth] = useState<number>(8);
  const [isEraser, setIsEraser] = useState<boolean>(false);
  const [currentMode, setCurrentMode] = useState<'letter' | 'signature' | 'free'>('letter');
  const [activeLetter, setActiveLetter] = useState<string>(initialLetter);
  const [userName, setUserName] = useState<string>('محمد أحمد');
  const [savedSuccess, setSavedSuccess] = useState<boolean>(false);

  const matchedLetterInfo = ARABIC_ALPHABET.find((l) => l.letter === activeLetter);

  useEffect(() => {
    if (initialLetter) {
      setActiveLetter(initialLetter);
    }
  }, [initialLetter]);

  // Redraw canvas with background and guide
  const redrawCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Reset background: School blackboard feel (soft off-white with subtle notebook ruled lines)
    ctx.fillStyle = '#f8fafc';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Ruled lines for writing practice
    ctx.strokeStyle = '#e2e8f0';
    ctx.lineWidth = 2;
    const lineHeight = 60;
    for (let y = lineHeight; y < canvas.height; y += lineHeight) {
      ctx.beginPath();
      ctx.moveTo(20, y);
      ctx.lineTo(canvas.width - 20, y);
      ctx.stroke();
    }

    // Baseline accent guide (reddish dotted line like Arabic school notebook)
    ctx.strokeStyle = '#fca5a5';
    ctx.setLineDash([6, 6]);
    ctx.beginPath();
    ctx.moveTo(20, canvas.height / 2 + 30);
    ctx.lineTo(canvas.width - 20, canvas.height / 2 + 30);
    ctx.stroke();
    ctx.setLineDash([]); // Reset line dash

    // Dotted Guide overlay
    if (currentMode === 'letter') {
      ctx.font = 'bold 220px "Alexandria", "Cairo", sans-serif';
      ctx.fillStyle = '#cbd5e1';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(activeLetter, canvas.width / 2, canvas.height / 2);
    } else if (currentMode === 'signature') {
      ctx.font = 'bold 80px "Alexandria", "Cairo", sans-serif';
      ctx.fillStyle = '#cbd5e1';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(userName, canvas.width / 2, canvas.height / 2);
    }
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    canvas.width = canvas.parentElement?.clientWidth || 700;
    canvas.height = 420;
    redrawCanvas();
  }, [currentMode, activeLetter, userName]);

  // Drawing event handlers with touch support
  const getCoordinates = (e: React.MouseEvent | React.TouchEvent) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();

    if ('touches' in e && e.touches.length > 0) {
      return {
        x: e.touches[0].clientX - rect.left,
        y: e.touches[0].clientY - rect.top,
      };
    } else if ('clientX' in e) {
      return {
        x: (e as React.MouseEvent).clientX - rect.left,
        y: (e as React.MouseEvent).clientY - rect.top,
      };
    }
    return { x: 0, y: 0 };
  };

  const startDrawing = (e: React.MouseEvent | React.TouchEvent) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    setIsDrawing(true);
    const { x, y } = getCoordinates(e);
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.strokeStyle = isEraser ? '#f8fafc' : penColor;
    ctx.lineWidth = isEraser ? penWidth * 2.5 : penWidth;
  };

  const draw = (e: React.MouseEvent | React.TouchEvent) => {
    if (!isDrawing) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const { x, y } = getCoordinates(e);
    ctx.lineTo(x, y);
    ctx.stroke();
  };

  const stopDrawing = () => {
    setIsDrawing(false);
  };

  const clearCanvas = () => {
    audioService.playSound('pop');
    redrawCanvas();
  };

  const downloadDrawing = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    audioService.playSound('celebrate');
    audioService.speak('تم حفظ رسمتك وتوقيعك الجميل بنجاح. فخورين بيك وبخطك!');

    const link = document.createElement('a');
    link.download = currentMode === 'signature' ? `توقيع-${userName}.png` : `كتابة-حرف-${activeLetter}.png`;
    link.href = canvas.toDataURL('image/png');
    link.click();

    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  const lettersSample = ['أ', 'ب', 'ت', 'ج', 'ح', 'د', 'ر', 'س', 'ص', 'ط', 'ع', 'ف', 'م', 'ن', 'ي'];

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className="bg-gradient-to-r from-amber-700 via-orange-800 to-amber-900 rounded-3xl p-6 sm:p-8 text-white shadow-lg relative overflow-hidden">
        <div className="relative z-10 max-w-2xl">
          <div className="inline-flex items-center gap-2 bg-amber-500/40 text-amber-100 font-bold px-3 py-1 rounded-full text-xs sm:text-sm border border-amber-400/40 mb-3">
            <PenTool className="w-4 h-4 text-amber-200" />
            سبورة الكتابة والتوقيع الشخصي
          </div>
          <h1 className="text-2xl sm:text-4xl font-black font-['Alexandria',sans-serif] leading-tight mb-2">
            درب إيدك على مسكة القلم والتوقيع
          </h1>
          <p className="text-amber-100 text-sm sm:text-base leading-relaxed">
            الكتابة مهارة بتيجي بالممارسة. تتبع الحرف بالنقط أو اكتب اسمك وتدرب على توقيعك الخاص للأوراق الرسمية.
          </p>
        </div>
      </div>

      {/* Mode Selector Tabs */}
      <div className="flex flex-wrap items-center gap-2 border-b border-slate-200 pb-3">
        <button
          onClick={() => {
            setCurrentMode('letter');
            audioService.speak('وضع تتبع الحروف على السبورة');
          }}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl font-bold text-sm transition-all ${
            currentMode === 'letter'
              ? 'bg-amber-600 text-white shadow-md'
              : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200'
          }`}
        >
          <Sparkles className="w-4 h-4" />
          <span>تتبع ورسم الحروف</span>
        </button>

        <button
          onClick={() => {
            setCurrentMode('signature');
            audioService.speak('وضع تدريب التوقيع بالاسم على الأوراق والبطاقة');
          }}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl font-bold text-sm transition-all ${
            currentMode === 'signature'
              ? 'bg-amber-600 text-white shadow-md'
              : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200'
          }`}
        >
          <PenTool className="w-4 h-4" />
          <span>اتعلم تمضي اسمك (التوقيع الرسمي)</span>
        </button>

        <button
          onClick={() => {
            setCurrentMode('free');
            audioService.speak('السبورة الحرة للكتابة والتلوين');
          }}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl font-bold text-sm transition-all ${
            currentMode === 'free'
              ? 'bg-amber-600 text-white shadow-md'
              : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200'
          }`}
        >
          <span>🎨</span>
          <span>سبورة حرة</span>
        </button>
      </div>

      {/* Sub Controls: Choose letter or enter signature name */}
      {currentMode === 'letter' && (
        <div className="bg-white p-4 rounded-2xl border border-slate-200 flex flex-wrap items-center gap-2">
          <span className="text-xs font-bold text-slate-600 shrink-0">اختر حرفاً للتتبع:</span>
          <div className="flex flex-wrap gap-1.5">
            {lettersSample.map((l) => (
              <button
                key={l}
                onClick={() => {
                  setActiveLetter(l);
                  audioService.speak(`حرف ${l}`);
                }}
                className={`w-10 h-10 rounded-xl font-black text-lg border transition-all ${
                  activeLetter === l
                    ? 'bg-amber-500 text-white border-amber-600 scale-105'
                    : 'bg-slate-50 hover:bg-amber-50 text-slate-800 border-slate-200'
                }`}
              >
                {l}
              </button>
            ))}
          </div>

          {matchedLetterInfo && (
            <div className="w-full mt-3 pt-3 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-amber-50/60 p-3 rounded-xl border border-amber-200/80">
              <div className="space-y-1">
                <span className="text-xs font-black text-amber-950 block">
                  خطوات رسم حرف {matchedLetterInfo.nameAr}:
                </span>
                <div className="flex flex-wrap items-center gap-2 text-xs font-bold text-slate-700">
                  {matchedLetterInfo.strokeGuide.steps.map((st, i) => (
                    <span key={i} className="bg-white px-2.5 py-1 rounded-lg border border-amber-200">
                      {st}
                    </span>
                  ))}
                </div>
              </div>
              <button
                onClick={() => audioService.speak(matchedLetterInfo.strokeGuide.audioTip)}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-200 hover:bg-amber-300 text-amber-950 font-bold rounded-lg text-xs shrink-0"
              >
                <Volume2 className="w-4 h-4 text-amber-800" />
                <span>نصيحة عم صلاح في مسكة القلم</span>
              </button>
            </div>
          )}
        </div>
      )}

      {currentMode === 'signature' && (
        <div className="bg-white p-4 rounded-2xl border border-slate-200 flex flex-col sm:flex-row items-center gap-3">
          <label className="text-sm font-bold text-slate-700 shrink-0">اكتب اسمك الثلاثي:</label>
          <input
            type="text"
            value={userName}
            onChange={(e) => setUserName(e.target.value)}
            className="flex-1 bg-slate-50 border-2 border-slate-300 focus:border-amber-500 rounded-xl px-3 py-2 text-base font-bold text-slate-900 outline-none"
            placeholder="مثال: أحمد محمد علي"
          />
          <button
            onClick={() => audioService.speak(`تدريب توقيع الاسم: ${userName}`)}
            className="px-4 py-2 bg-amber-100 hover:bg-amber-200 text-amber-900 font-bold rounded-xl text-xs sm:text-sm border border-amber-300 flex items-center gap-1.5"
          >
            <Volume2 className="w-4 h-4" />
            <span>نطق الاسم</span>
          </button>
        </div>
      )}

      {/* Main Drawing Canvas Container */}
      <div className="bg-white rounded-3xl p-5 sm:p-6 border-2 border-amber-300 shadow-md space-y-4">
        {/* Tool Bar Controls */}
        <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-100">
          {/* Colors & Eraser */}
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-slate-500">لون القلم:</span>
            {[
              { color: '#1e3a8a', label: 'كحلي' },
              { color: '#047857', label: 'أخضر' },
              { color: '#b91c1c', label: 'أحمر' },
              { color: '#0f172a', label: 'أسود' },
            ].map((c) => (
              <button
                key={c.color}
                onClick={() => {
                  setPenColor(c.color);
                  setIsEraser(false);
                }}
                className={`w-8 h-8 rounded-full border-2 transition-transform ${
                  !isEraser && penColor === c.color ? 'scale-125 border-slate-900 shadow-xs' : 'border-white'
                }`}
                style={{ backgroundColor: c.color }}
                title={c.label}
              />
            ))}

            <button
              onClick={() => setIsEraser(!isEraser)}
              className={`p-2 rounded-xl border transition-all text-xs font-bold flex items-center gap-1 ${
                isEraser
                  ? 'bg-amber-500 text-white border-amber-600 shadow-xs'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border-slate-300'
              }`}
            >
              <Eraser className="w-4 h-4" />
              <span>أستيكة (ممحاة)</span>
            </button>
          </div>

          {/* Pen Thickness */}
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-slate-500">سُمك الخط:</span>
            {[
              { size: 4, label: 'رفيع' },
              { size: 8, label: 'متوسط' },
              { size: 14, label: 'عريض' },
            ].map((s) => (
              <button
                key={s.size}
                onClick={() => setPenWidth(s.size)}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold border transition-colors ${
                  penWidth === s.size
                    ? 'bg-slate-800 text-white border-slate-900'
                    : 'bg-slate-100 text-slate-600 border-slate-200 hover:bg-slate-200'
                }`}
              >
                {s.label}
              </button>
            ))}
          </div>

          {/* Action Buttons: Clear & Download */}
          <div className="flex items-center gap-2">
            <button
              onClick={clearCanvas}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs border border-slate-300 transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>امسح السبورة</span>
            </button>

            <button
              onClick={downloadDrawing}
              className="flex items-center gap-1.5 px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs shadow-xs transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              <span>احفظ كتابتك</span>
            </button>
          </div>
        </div>

        {/* Canvas Element with Touch Protection */}
        <div className="relative rounded-2xl overflow-hidden border-2 border-slate-200 touch-none shadow-inner bg-slate-50">
          <canvas
            ref={canvasRef}
            onMouseDown={startDrawing}
            onMouseMove={draw}
            onMouseUp={stopDrawing}
            onMouseLeave={stopDrawing}
            onTouchStart={startDrawing}
            onTouchMove={draw}
            onTouchEnd={stopDrawing}
            className="w-full cursor-crosshair block"
          />

          {/* Subtle Canvas Watermark & Audio Hint */}
          <div className="absolute bottom-3 left-3 bg-white/80 backdrop-blur-xs px-3 py-1.5 rounded-xl border border-slate-200 text-xs font-bold text-slate-600 flex items-center gap-2">
            <span>✍️ ارسم بإصبعك أو الماوس</span>
            <button
              onClick={() => {
                audioService.speak(
                  currentMode === 'signature'
                    ? 'امسك القلم بإيدك وتتبع الحروف المنقطة لاسمك بالراحة، التكرار هيخلي خطك وتوقيعك في منتهى الجمال.'
                    : 'تتبع الحرف المرسوم بالنقط من فوق لتحت ومن اليمين للشمال.'
                );
              }}
              className="text-amber-700 hover:text-amber-800"
            >
              <Volume2 className="w-4 h-4" />
            </button>
          </div>
        </div>

        {savedSuccess && (
          <div className="p-3 bg-emerald-100 border border-emerald-300 text-emerald-900 rounded-xl flex items-center gap-2 text-xs font-bold animate-in fade-in">
            <Check className="w-4 h-4 text-emerald-600" />
            <span>تم حفظ صورتك بنجاح! مبروك عليك بداية إتقان الكتابة.</span>
          </div>
        )}
      </div>
    </div>
  );
};
