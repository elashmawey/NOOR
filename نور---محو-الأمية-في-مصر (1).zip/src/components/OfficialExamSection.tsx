import React, { useState, useRef, useEffect } from 'react';
import {
  FileCheck,
  Award,
  CheckCircle2,
  AlertCircle,
  Volume2,
  Printer,
  RotateCcw,
  Sparkles,
  PenTool,
  Clock,
  ShieldCheck,
  QrCode,
  Share2,
} from 'lucide-react';
import { audioService } from '../utils/audio';

interface ExamAnswers {
  q1: string; // Reading question 1
  q2: string; // Reading question 2
  q3: string; // Reading question 3
  q4: string; // Reading question 4
  dictationWord: string; // Dictation
  math1: string; // Money change
  math2: string; // Electricity reading
  math3: string; // Bread calculation
  signatureDrawn: boolean;
}

export const OfficialExamSection: React.FC = () => {
  // Candidate Info
  const [candidateName, setCandidateName] = useState<string>('محمود حسن عبد الرحيم');
  const [nationalId, setNationalId] = useState<string>('28509142101234');
  const [governorate, setGovernorate] = useState<string>('سوهاج - مركز البلينا');

  // Exam flow states: 'intro' | 'testing' | 'result'
  const [examStep, setExamStep] = useState<'intro' | 'testing' | 'result'>('intro');

  // Active section inside the exam: 1 (Reading), 2 (Dictation/Signature), 3 (Math)
  const [activeExamSection, setActiveExamSection] = useState<number>(1);

  // Student Answers
  const [answers, setAnswers] = useState<ExamAnswers>({
    q1: '',
    q2: '',
    q3: '',
    q4: '',
    dictationWord: '',
    math1: '',
    math2: '',
    math3: '',
    signatureDrawn: false,
  });

  // Signature canvas
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [isDrawing, setIsDrawing] = useState<boolean>(false);
  const [signatureSaved, setSignatureSaved] = useState<boolean>(false);

  // Score calculated
  const [scoreData, setScoreData] = useState<{
    reading: number;
    writing: number;
    math: number;
    total: number;
    grade: string;
    passed: boolean;
    certificateSerial: string;
  }>({
    reading: 0,
    writing: 0,
    math: 0,
    total: 0,
    grade: '',
    passed: false,
    certificateSerial: '',
  });

  // Canvas drawing handlers
  useEffect(() => {
    if (activeExamSection === 2 && canvasRef.current) {
      const canvas = canvasRef.current;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.strokeStyle = '#0f172a';
        ctx.lineWidth = 3;
        ctx.lineCap = 'round';
        ctx.lineJoin = 'round';
      }
    }
  }, [activeExamSection]);

  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    setIsDrawing(true);
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const rect = canvas.getBoundingClientRect();
    const x = 'touches' in e ? e.touches[0].clientX - rect.left : e.clientX - rect.left;
    const y = 'touches' in e ? e.touches[0].clientY - rect.top : e.clientY - rect.top;
    ctx.beginPath();
    ctx.moveTo(x, y);
  };

  const draw = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const rect = canvas.getBoundingClientRect();
    const x = 'touches' in e ? e.touches[0].clientX - rect.left : e.clientX - rect.left;
    const y = 'touches' in e ? e.touches[0].clientY - rect.top : e.clientY - rect.top;
    ctx.lineTo(x, y);
    ctx.stroke();
  };

  const stopDrawing = () => {
    if (isDrawing) {
      setIsDrawing(false);
      setSignatureSaved(true);
      setAnswers((prev) => ({ ...prev, signatureDrawn: true }));
    }
  };

  const clearSignature = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    setSignatureSaved(false);
    setAnswers((prev) => ({ ...prev, signatureDrawn: false }));
    audioService.speak('تم مسح السبورة للتوقيع مرة أخرى.');
  };

  const startExam = () => {
    if (!candidateName.trim()) {
      audioService.speak('برجاء كتابة اسم الدارس أولاً قبل بدء الامتحان.');
      return;
    }
    setExamStep('testing');
    setActiveExamSection(1);
    audioService.cheerSuccess();
    audioService.speak(
      `بالتوفيق يا ${candidateName}! بدأنا الآن الامتحان المعتمد. الجزء الأول: القراءة والفهم. اقرأ النص بعناية أو استمع إليه وأجب عن الأسئلة.`
    );
  };

  const submitExam = () => {
    // 1. Reading Score (4 questions * 10 = 40)
    let reading = 0;
    if (answers.q1 === 'منفذ البريد المصري') reading += 10;
    if (answers.q2 === 'أصل بطاقة الرقم القومي') reading += 10;
    if (answers.q3 === 'الأحد القادم') reading += 10;
    if (answers.q4 === 'وزارة التضامن الاجتماعي') reading += 10;

    // 2. Writing / Dictation Score (30)
    let writing = 0;
    const cleanDict = answers.dictationWord.trim().replace(/[ً-ْ]/g, '');
    if (cleanDict.includes('نور') || cleanDict.includes('نُور')) {
      writing += 15;
    } else if (cleanDict.length > 0) {
      writing += 8; // partial mark for trying
    }

    if (answers.signatureDrawn) {
      writing += 15; // valid signature
    }

    // 3. Math Score (30: 3 questions * 10 = 30)
    let math = 0;
    if (answers.math1 === '35') math += 10;
    if (answers.math2 === '75') math += 10;
    if (answers.math3 === '20') math += 10;

    const total = reading + writing + math;
    const passed = total >= 50;
    let grade = 'راسب يحتاج لإعادة';
    if (total >= 85) grade = 'ممتاز (مؤهل مع مرتبة الشرف)';
    else if (total >= 70) grade = 'جيد جداً';
    else if (total >= 50) grade = 'ناجح ومستوفٍ للمعايير';

    const serial = `EG-GALAE-2026-${Math.floor(100000 + Math.random() * 900000)}`;

    setScoreData({
      reading,
      writing,
      math,
      total,
      grade,
      passed,
      certificateSerial: serial,
    });

    setExamStep('result');

    if (passed) {
      audioService.cheerSuccess();
      audioService.speak(
        `ألف ألف مبروك يا ${candidateName}! نجحت في الامتحان الوطني المعتمد بمجموع ${total} درجة من مائة، وبتقدير ${grade}. استمارتك الرسمية جاهزة للطباعة.`
      );
    } else {
      audioService.encourageRetry();
      audioService.speak(
        `أحسنت المحاولة يا ${candidateName}. حصلت على ${total} درجة. محتاجين نراجع قسم القراءة والحساب وندخل الامتحان تاني بكل ثقة!`
      );
    }
  };

  const handlePrintCertificate = () => {
    audioService.speak('جاري طباعة استمارة النجاح والاجتياز الرسمية.');
    window.print();
  };

  return (
    <div className="space-y-8">
      {/* Step 1: Candidate Entry and Introduction */}
      {examStep === 'intro' && (
        <div className="bg-white rounded-3xl p-6 sm:p-10 border border-slate-200 shadow-md space-y-8 max-w-4xl mx-auto">
          {/* Header */}
          <div className="text-center space-y-3 border-b border-slate-200 pb-6">
            <div className="inline-flex items-center gap-2 bg-amber-100 text-amber-900 font-bold px-3.5 py-1.5 rounded-full text-xs sm:text-sm">
              <span>🏛️</span>
              جمهورية مصر العربية · الهيئة العامة لتعليم الكبار
            </div>
            <h1 className="text-2xl sm:text-4xl font-black font-['Alexandria',sans-serif] text-slate-900 leading-tight">
              النموذج الاسترشادي الموحد لاختبار محو الأمية
            </h1>
            <p className="text-xs sm:text-sm text-slate-600 max-w-2xl mx-auto">
              يحاكي هذا الاختبار مواصفات ورقة الامتحان الوطنية المعتمدة (قراءة وظيفية، إملاء وتوقيع بالاسم، وحساب يومي). النتيجة فورية مع استمارة نجاح رسمية مؤقتة.
            </p>
          </div>

          {/* Candidate Form */}
          <div className="bg-slate-50 rounded-2xl p-6 border border-slate-200 space-y-4">
            <h3 className="text-base font-black text-slate-900 flex items-center gap-2">
              <PenTool className="w-5 h-5 text-amber-600" />
              بيانات الدارس المتقدم للاختبار
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  الاسم الرباعي (كما هو ببطاقة الرقم القومي):
                </label>
                <input
                  type="text"
                  value={candidateName}
                  onChange={(e) => setCandidateName(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-300 text-sm font-bold bg-white focus:outline-none focus:ring-2 focus:ring-amber-500"
                  placeholder="مثال: أحمد عبد الرحيم علي حسن"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  الرقم القومي (١٤ رقماً):
                </label>
                <input
                  type="text"
                  maxLength={14}
                  value={nationalId}
                  onChange={(e) => setNationalId(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-300 text-sm font-mono font-bold bg-white focus:outline-none focus:ring-2 focus:ring-amber-500 text-left"
                  placeholder="28509142101234"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  المحافظة والمركز / قرية حياة كريمة:
                </label>
                <input
                  type="text"
                  value={governorate}
                  onChange={(e) => setGovernorate(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-300 text-sm font-bold bg-white focus:outline-none focus:ring-2 focus:ring-amber-500"
                  placeholder="مثال: سوهاج - مركز البلينا"
                />
              </div>
            </div>
          </div>

          {/* Exam Structure Brief */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 text-center">
              <span className="text-xs font-bold text-amber-800 block">الجزء الأول</span>
              <span className="text-lg font-black text-slate-900 block mt-1">القراءة والفهم</span>
              <span className="text-xs text-amber-700 font-bold">٤٠ درجة (٤ أسئلة)</span>
            </div>
            <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-center">
              <span className="text-xs font-bold text-emerald-800 block">الجزء الثاني</span>
              <span className="text-lg font-black text-slate-900 block mt-1">الإملاء والتوقيع</span>
              <span className="text-xs text-emerald-700 font-bold">٣٠ درجة (سؤالان)</span>
            </div>
            <div className="p-4 rounded-2xl bg-blue-50 border border-blue-200 text-center">
              <span className="text-xs font-bold text-blue-800 block">الجزء الثالث</span>
              <span className="text-lg font-black text-slate-900 block mt-1">الحساب اليومي</span>
              <span className="text-xs text-blue-700 font-bold">٣٠ درجة (٣ أسئلة)</span>
            </div>
          </div>

          <button
            onClick={startExam}
            className="w-full py-4 bg-gradient-to-r from-amber-600 via-amber-700 to-yellow-600 hover:from-amber-700 hover:to-yellow-700 text-white rounded-2xl text-base sm:text-lg font-black shadow-lg transition-all flex items-center justify-center gap-3"
          >
            <Sparkles className="w-5 h-5" />
            <span>توكل على الله وابدأ الاختبار التجريبي</span>
          </button>
        </div>
      )}

      {/* Step 2: Exam In Progress */}
      {examStep === 'testing' && (
        <div className="bg-white rounded-3xl p-6 sm:p-10 border border-slate-200 shadow-md space-y-8 max-w-4xl mx-auto">
          {/* Top Progress bar */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-5">
            <div>
              <span className="text-xs text-slate-500 font-bold block">ورقة إجابة الدارس:</span>
              <span className="text-lg font-black text-slate-900">{candidateName}</span>
            </div>

            <div className="flex items-center gap-2">
              {[
                { sec: 1, label: '١. القراءة والفهم' },
                { sec: 2, label: '٢. الإملاء والتوقيع' },
                { sec: 3, label: '٣. الحساب والمعاملات' },
              ].map((s) => (
                <button
                  key={s.sec}
                  onClick={() => setActiveExamSection(s.sec)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-black transition-all ${
                    activeExamSection === s.sec
                      ? 'bg-amber-600 text-white shadow-xs'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {s.label}
                </button>
              ))}
            </div>
          </div>

          {/* Section 1: Reading & Functional Comprehension (40 Marks) */}
          {activeExamSection === 1 && (
            <div className="space-y-6">
              <div className="p-5 rounded-2xl bg-amber-50 border border-amber-300 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black text-amber-900 bg-amber-200 px-3 py-1 rounded-full">
                    النص الوظيفي المقروء (٤٠ درجة)
                  </span>
                  <button
                    onClick={() => {
                      audioService.speak(
                        'النص الوظيفي: تعلن وزارة التضامن الاجتماعي عن بدء صرف منحة التمكين الاجتماعي بموجب بطاقتكم الذكية من منفذ البريد المصري في موعد غايته الأحد القادم، مصطحباً أصل بطاقة الرقم القومي السارية.'
                      );
                    }}
                    className="flex items-center gap-1.5 text-xs font-bold text-amber-900 bg-amber-200/80 hover:bg-amber-300 px-3 py-1.5 rounded-xl transition-colors"
                  >
                    <Volume2 className="w-4 h-4" />
                    <span>استمع للنص بالصوت</span>
                  </button>
                </div>
                <p className="text-base sm:text-lg font-bold text-slate-900 leading-relaxed bg-white p-4 rounded-xl border border-amber-200">
                  "تُعلن وزارة التضامن الاجتماعي عن بدء صرف منحة التمكين الاجتماعي بموجب بطاقتكم الذكية من منفذ البريد المصري في موعد غايته الأحد القادم، مصطحباً أصل بطاقة الرقم القومي السارية."
                </p>
              </div>

              {/* 4 Reading Questions */}
              <div className="space-y-4">
                <div className="p-4 rounded-2xl border border-slate-200 bg-slate-50/50 space-y-2">
                  <span className="text-xs font-bold text-amber-700">سؤال ١ (١٠ درجات):</span>
                  <p className="text-sm font-extrabold text-slate-900">
                    من أين يتم صرف منحة التمكين المذكورة في الإعلان؟
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-1">
                    {['منفذ البريد المصري', 'مكتب التموين', 'محطة المترو'].map((opt) => (
                      <button
                        key={opt}
                        onClick={() => {
                          setAnswers({ ...answers, q1: opt });
                          audioService.playSound('click');
                        }}
                        className={`p-3 rounded-xl text-xs font-bold border transition-all text-right ${
                          answers.q1 === opt
                            ? 'bg-amber-600 text-white border-amber-600 shadow-xs'
                            : 'bg-white hover:bg-slate-100 text-slate-800 border-slate-200'
                        }`}
                      >
                        {opt}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="p-4 rounded-2xl border border-slate-200 bg-slate-50/50 space-y-2">
                  <span className="text-xs font-bold text-amber-700">سؤال ٢ (١٠ درجات):</span>
                  <p className="text-sm font-extrabold text-slate-900">
                    ما هو المستند الرسمي المطلوب اصطحابه عند الصرف؟
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-1">
                    {['أصل بطاقة الرقم القومي', 'صورة شهادة الميلاد القديمة', 'عقد إيجار المنزل'].map(
                      (opt) => (
                        <button
                          key={opt}
                          onClick={() => {
                            setAnswers({ ...answers, q2: opt });
                            audioService.playSound('click');
                          }}
                          className={`p-3 rounded-xl text-xs font-bold border transition-all text-right ${
                            answers.q2 === opt
                              ? 'bg-amber-600 text-white border-amber-600 shadow-xs'
                              : 'bg-white hover:bg-slate-100 text-slate-800 border-slate-200'
                          }`}
                        >
                          {opt}
                        </button>
                      )
                    )}
                  </div>
                </div>

                <div className="p-4 rounded-2xl border border-slate-200 bg-slate-50/50 space-y-2">
                  <span className="text-xs font-bold text-amber-700">سؤال ٣ (١٠ درجات):</span>
                  <p className="text-sm font-extrabold text-slate-900">
                    ما هو آخر موعد محدد للاستلام وفقاً للإعلان؟
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-1">
                    {['الأحد القادم', 'الشهر القادم', 'الجمعة الماضية'].map((opt) => (
                      <button
                        key={opt}
                        onClick={() => {
                          setAnswers({ ...answers, q3: opt });
                          audioService.playSound('click');
                        }}
                        className={`p-3 rounded-xl text-xs font-bold border transition-all text-right ${
                          answers.q3 === opt
                            ? 'bg-amber-600 text-white border-amber-600 shadow-xs'
                            : 'bg-white hover:bg-slate-100 text-slate-800 border-slate-200'
                        }`}
                      >
                        {opt}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="p-4 rounded-2xl border border-slate-200 bg-slate-50/50 space-y-2">
                  <span className="text-xs font-bold text-amber-700">سؤال ٤ (١٠ درجات):</span>
                  <p className="text-sm font-extrabold text-slate-900">
                    ما هي الجهة الحكومية المانحة المعلنة عن المبادرة؟
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-1">
                    {['وزارة التضامن الاجتماعي', 'هيئة النقل العام', 'مصلحة الجمارك'].map((opt) => (
                      <button
                        key={opt}
                        onClick={() => {
                          setAnswers({ ...answers, q4: opt });
                          audioService.playSound('click');
                        }}
                        className={`p-3 rounded-xl text-xs font-bold border transition-all text-right ${
                          answers.q4 === opt
                            ? 'bg-amber-600 text-white border-amber-600 shadow-xs'
                            : 'bg-white hover:bg-slate-100 text-slate-800 border-slate-200'
                        }`}
                      >
                        {opt}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <div className="flex justify-end pt-4">
                <button
                  onClick={() => {
                    setActiveExamSection(2);
                    audioService.speak('الانتقال للجزء الثاني: الإملاء والتوقيع الشخصي.');
                  }}
                  className="px-6 py-3 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-sm font-bold"
                >
                  التالي: الإملاء والتوقيع ⬅️
                </button>
              </div>
            </div>
          )}

          {/* Section 2: Dictation and Legal Signature (30 Marks) */}
          {activeExamSection === 2 && (
            <div className="space-y-6">
              {/* Dictation Question (15 Marks) */}
              <div className="p-5 rounded-2xl border border-slate-200 bg-slate-50/50 space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black text-emerald-800 bg-emerald-100 px-3 py-1 rounded-full">
                    سؤال الإملاء الصوتي (١٥ درجة)
                  </span>
                  <button
                    onClick={() => {
                      audioService.speak('العلمُ نُورٌ والجهلُ ظَلام');
                    }}
                    className="flex items-center gap-1.5 text-xs font-bold text-emerald-800 bg-emerald-100 hover:bg-emerald-200 px-3 py-1.5 rounded-xl transition-colors"
                  >
                    <Volume2 className="w-4 h-4 text-emerald-700" />
                    <span>استمع للجملة بصوت المعلم</span>
                  </button>
                </div>

                <div className="space-y-2">
                  <p className="text-sm font-extrabold text-slate-900">
                    استمع للجملة أعلاه، واكتب الكلمة الناقصة في الفراغ:
                  </p>
                  <div className="flex items-center gap-3 bg-white p-4 rounded-xl border border-slate-200 text-base font-bold">
                    <span>العِلْمُ</span>
                    <input
                      type="text"
                      value={answers.dictationWord}
                      onChange={(e) => setAnswers({ ...answers, dictationWord: e.target.value })}
                      placeholder="اكتب الكلمة هنا..."
                      className="px-3 py-1.5 rounded-lg border-2 border-emerald-500 font-bold text-center w-36 focus:outline-none focus:ring-2 focus:ring-emerald-400"
                    />
                    <span>وَالجَهْلُ ظَلَامٌ</span>
                  </div>
                </div>
              </div>

              {/* Legal Signature Question (15 Marks) */}
              <div className="p-5 rounded-2xl border border-slate-200 bg-slate-50/50 space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-xs font-black text-purple-800 bg-purple-100 px-3 py-1 rounded-full">
                      سؤال التوقيع الشخصي المعتمد (١٥ درجة)
                    </span>
                    <p className="text-xs text-slate-500 mt-1">
                      اكتب اسمك أو إمضاءك الشخصي بيدك على السبورة الإلكترونية كما ستوقّع على بطاقتك وأوراقك الرسمية.
                    </p>
                  </div>
                  <button
                    onClick={clearSignature}
                    className="flex items-center gap-1 text-xs font-bold text-rose-600 hover:bg-rose-50 px-2.5 py-1.5 rounded-xl border border-rose-200 transition-colors"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>مسح السبورة</span>
                  </button>
                </div>

                <div className="bg-white rounded-2xl border-2 border-dashed border-slate-300 p-2 overflow-hidden flex flex-col items-center">
                  <canvas
                    ref={canvasRef}
                    width={500}
                    height={160}
                    onMouseDown={startDrawing}
                    onMouseMove={draw}
                    onMouseUp={stopDrawing}
                    onMouseLeave={stopDrawing}
                    onTouchStart={startDrawing}
                    onTouchMove={draw}
                    onTouchEnd={stopDrawing}
                    className="w-full max-w-[500px] h-[160px] bg-amber-50/30 rounded-xl cursor-crosshair touch-none"
                  />
                  <div className="flex items-center justify-between w-full px-4 py-2 border-t border-slate-100 text-xs text-slate-500">
                    <span>مساحة التوقيع الشخصي المعتمد</span>
                    {signatureSaved ? (
                      <span className="text-emerald-700 font-bold flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5" /> تم تسجيل التوقيع
                      </span>
                    ) : (
                      <span className="text-amber-700 font-bold">بانتظار توقيعك بالقلم...</span>
                    )}
                  </div>
                </div>
              </div>

              <div className="flex justify-between pt-4">
                <button
                  onClick={() => setActiveExamSection(1)}
                  className="px-5 py-2.5 bg-slate-200 hover:bg-slate-300 text-slate-800 rounded-xl text-sm font-bold"
                >
                  ➡️ السابق (القراءة)
                </button>
                <button
                  onClick={() => {
                    setActiveExamSection(3);
                    audioService.speak('الانتقال للجزء الثالث: الحساب والمعاملات اليومية.');
                  }}
                  className="px-6 py-3 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-sm font-bold"
                >
                  التالي: الحساب والمعاملات ⬅️
                </button>
              </div>
            </div>
          )}

          {/* Section 3: Functional Life Math (30 Marks) */}
          {activeExamSection === 3 && (
            <div className="space-y-6">
              <div className="space-y-4">
                {/* Math 1: Change calculation */}
                <div className="p-4 rounded-2xl border border-slate-200 bg-slate-50/50 space-y-2">
                  <span className="text-xs font-bold text-blue-700">سؤال ١ (١٠ درجات):</span>
                  <p className="text-sm font-extrabold text-slate-900">
                    اشتريت طلبات من البقالة بـ ٦٥ جنيهاً، وأعطيت البائع ورقة ١٠٠ جنيه. كم يرجع لك الباقي؟
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-1">
                    {[
                      { val: '35', label: '٣٥ جنيهاً (ورقة ٢٠ + ورقة ١٠ + ورقة ٥)' },
                      { val: '25', label: '٢٥ جنيهاً' },
                      { val: '45', label: '٤٥ جنيهاً' },
                    ].map((opt) => (
                      <button
                        key={opt.val}
                        onClick={() => {
                          setAnswers({ ...answers, math1: opt.val });
                          audioService.playSound('click');
                        }}
                        className={`p-3 rounded-xl text-xs font-bold border transition-all text-right ${
                          answers.math1 === opt.val
                            ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                            : 'bg-white hover:bg-slate-100 text-slate-800 border-slate-200'
                        }`}
                      >
                        {opt.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Math 2: Meter screen reading */}
                <div className="p-4 rounded-2xl border border-slate-200 bg-slate-50/50 space-y-2">
                  <span className="text-xs font-bold text-blue-700">سؤال ٢ (١٠ درجات):</span>
                  <p className="text-sm font-extrabold text-slate-900">
                    شاشة عداد الكهرباء الكودي الذكي تظهر الرقم التالي: [ ٧٥٫٠٠ ج.م ]. ما هو الرصيد المتبقي بالعداد؟
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-1">
                    {[
                      { val: '75', label: 'خمسة وسبعون جنيهاً (٧٥ ج)' },
                      { val: '57', label: 'سبعة وخمسون جنيهاً (٥٧ ج)' },
                      { val: '750', label: 'سبعمائة وخمسون جنيهاً' },
                    ].map((opt) => (
                      <button
                        key={opt.val}
                        onClick={() => {
                          setAnswers({ ...answers, math2: opt.val });
                          audioService.playSound('click');
                        }}
                        className={`p-3 rounded-xl text-xs font-bold border transition-all text-right ${
                          answers.math2 === opt.val
                            ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                            : 'bg-white hover:bg-slate-100 text-slate-800 border-slate-200'
                        }`}
                      >
                        {opt.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Math 3: Bread calculation */}
                <div className="p-4 rounded-2xl border border-slate-200 bg-slate-50/50 space-y-2">
                  <span className="text-xs font-bold text-blue-700">سؤال ٣ (١٠ درجات):</span>
                  <p className="text-sm font-extrabold text-slate-900">
                    أسرة مسجلة ببطاقة التموين بها ٤ أفراد، وحصة الفرد ٥ أرغفة يومياً. كم رغيفاً تستحقه الأسرة كل يوم؟
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-1">
                    {[
                      { val: '20', label: '٢٠ رغيفاً (٤ أفراد × ٥ أرغفة)' },
                      { val: '15', label: '١٥ رغيفاً' },
                      { val: '25', label: '٢٥ رغيفاً' },
                    ].map((opt) => (
                      <button
                        key={opt.val}
                        onClick={() => {
                          setAnswers({ ...answers, math3: opt.val });
                          audioService.playSound('click');
                        }}
                        className={`p-3 rounded-xl text-xs font-bold border transition-all text-right ${
                          answers.math3 === opt.val
                            ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                            : 'bg-white hover:bg-slate-100 text-slate-800 border-slate-200'
                        }`}
                      >
                        {opt.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <div className="flex justify-between pt-6 border-t border-slate-200">
                <button
                  onClick={() => setActiveExamSection(2)}
                  className="px-5 py-2.5 bg-slate-200 hover:bg-slate-300 text-slate-800 rounded-xl text-sm font-bold"
                >
                  ➡️ السابق (الإملاء والتوقيع)
                </button>
                <button
                  onClick={submitExam}
                  className="px-8 py-3 bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-700 hover:to-teal-800 text-white rounded-xl text-base font-black shadow-lg"
                >
                  تسليم ورقة الامتحان وإعلان النتيجة 🏆
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Step 3: Exam Result & Official Provisional Certificate */}
      {examStep === 'result' && (
        <div className="space-y-6 max-w-4xl mx-auto print:max-w-none print:m-0">
          {/* Result Banner (Screen Only) */}
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-md space-y-4 print:hidden">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div
                  className={`w-14 h-14 rounded-2xl flex items-center justify-center text-3xl font-bold ${
                    scoreData.passed ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                  }`}
                >
                  {scoreData.passed ? '🎉' : '📖'}
                </div>
                <div>
                  <h2 className="text-xl sm:text-2xl font-black text-slate-900 font-['Alexandria',sans-serif]">
                    {scoreData.passed ? 'مبروك الاجتياز والتفوق!' : 'نتيجة الاختبار التجريبي'}
                  </h2>
                  <p className="text-xs sm:text-sm text-slate-500">
                    الدارس: <strong className="text-slate-800">{candidateName}</strong> · الرقم القومي:{' '}
                    <span className="font-mono">{nationalId}</span>
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handlePrintCertificate}
                  className="flex items-center gap-2 px-5 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs sm:text-sm font-bold shadow-md"
                >
                  <Printer className="w-4 h-4" />
                  <span>طباعة استمارة النجاح الرسمية</span>
                </button>
                <button
                  onClick={() => setExamStep('intro')}
                  className="flex items-center gap-2 px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs sm:text-sm font-bold"
                >
                  <RotateCcw className="w-4 h-4" />
                  <span>إعادة الاختبار</span>
                </button>
              </div>
            </div>

            {/* Score Breakdown Cards */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
              <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 text-center">
                <span className="text-xs text-amber-800 font-bold block">القراءة والفهم</span>
                <span className="text-2xl font-black text-slate-900 mt-1 block">
                  {scoreData.reading} / ٤٠
                </span>
              </div>
              <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-center">
                <span className="text-xs text-emerald-800 font-bold block">الإملاء والتوقيع</span>
                <span className="text-2xl font-black text-slate-900 mt-1 block">
                  {scoreData.writing} / ٣٠
                </span>
              </div>
              <div className="p-4 rounded-2xl bg-blue-50 border border-blue-200 text-center">
                <span className="text-xs text-blue-800 font-bold block">الحساب اليومي</span>
                <span className="text-2xl font-black text-slate-900 mt-1 block">
                  {scoreData.math} / ٣٠
                </span>
              </div>
              <div className="p-4 rounded-2xl bg-slate-900 text-white text-center">
                <span className="text-xs text-amber-300 font-bold block">المجموع والتقدير</span>
                <span className="text-2xl font-black text-white mt-1 block font-mono">
                  {scoreData.total} / ١٠٠
                </span>
                <span className="text-[11px] text-emerald-300 font-bold block">{scoreData.grade}</span>
              </div>
            </div>
          </div>

          {/* Official Printable Certificate (A4 Styled Form) */}
          <div className="bg-[#fffdfa] rounded-3xl p-8 sm:p-12 border-4 border-amber-800/40 shadow-2xl relative overflow-hidden print:border-2 print:shadow-none print:rounded-none print:p-6 print:m-0 space-y-6">
            {/* Eagle & Official Insignia Watermark */}
            <div className="absolute inset-0 flex items-center justify-center opacity-[0.03] pointer-events-none text-[280px] font-black select-none">
              🦅
            </div>

            {/* Certificate Header */}
            <div className="flex items-center justify-between border-b-2 border-amber-900/20 pb-6 text-center">
              <div className="text-right space-y-0.5 text-xs text-slate-600 font-bold">
                <span>جمهورية مصر العربية</span>
                <span className="block text-slate-900 font-black">الهيئة العامة لتعليم الكبار</span>
                <span className="block text-emerald-800">مبادرة حياة كريمة</span>
              </div>

              <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-amber-600 to-amber-800 text-white flex items-center justify-center text-3xl font-black shadow-md border-2 border-amber-300">
                ن
              </div>

              <div className="text-left space-y-0.5 text-xs text-slate-600 font-bold font-mono">
                <span>الرقم المسلسل:</span>
                <span className="block text-slate-900 font-black">{scoreData.certificateSerial}</span>
                <span className="block text-slate-500">{new Date().toLocaleDateString('ar-EG')}</span>
              </div>
            </div>

            {/* Certificate Main Title */}
            <div className="text-center space-y-2 py-2">
              <h3 className="text-2xl sm:text-3xl font-black font-['Alexandria',sans-serif] text-slate-900 tracking-tight">
                اسْتِمَارَةُ اجْتِيَازِ اخْتِبَارِ مَحْوِ الأُمِّيَّةِ الْمُعْتَمَدِ
              </h3>
              <p className="text-xs sm:text-sm font-bold text-amber-900">
                طِبْقاً لِلْمَعَايِيرِ الْقَوْمِيَّةِ الْمُوَحَّدَةِ لِتَعْلِيمِ الْكِبَارِ فِي جُمْهُورِيَّةِ مِصْرَ الْعَرَبِيَّةِ
              </p>
            </div>

            {/* Candidate Statement */}
            <div className="bg-amber-50/50 rounded-2xl p-6 border border-amber-200/80 space-y-4 text-sm sm:text-base leading-relaxed text-slate-800">
              <p>
                تَشْهَدُ <strong className="text-slate-900">مَنَصَّةُ نُورٍ التَّعْلِيمِيَّةُ</strong> بالتَّعَاوُنِ النَّمَطِيِّ مَعَ{' '}
                <strong className="text-slate-900">الْهَيْئَةِ الْعَامَّةِ لِتَعْلِيمِ الْكِبَارِ</strong>، بِأَنَّ الدَّارِسَ /
              </p>

              <div className="text-center py-2">
                <span className="text-2xl sm:text-3xl font-black font-['Alexandria',sans-serif] text-amber-950 border-b-2 border-amber-600 px-8 pb-1 inline-block">
                  {candidateName}
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs sm:text-sm pt-2">
                <div>
                  <span className="font-bold text-slate-600">الرَّقَمُ الْقَوْمِيُّ: </span>
                  <span className="font-mono font-black text-slate-900 tracking-wider">
                    {nationalId}
                  </span>
                </div>
                <div>
                  <span className="font-bold text-slate-600">الْمُحَافَظَةُ وَالْمَرْكَزُ: </span>
                  <span className="font-bold text-slate-900">{governorate}</span>
                </div>
              </div>

              <p className="pt-2 text-xs sm:text-sm">
                قَدْ اجْتَازَ بِنَجَاحٍ اخْتِبَارَ التَّأْهِيلِ الْقَوْمِيِّ (قِرَاءَةً، كِتَابَةً، وَحِسَاباً)، وَحَصَلَ عَلَى مَجْمُوعِ{' '}
                <strong className="font-mono font-black text-emerald-800 text-lg">
                  ({scoreData.total} / ١٠٠)
                </strong>{' '}
                بِتَقْدِيرِ عَامٍ: <strong className="text-emerald-900 font-black">[{scoreData.grade}]</strong>، وَأَصْبَحَ مُؤَهَّلاً تَمَاماً لِلتَّعَامُلِ مَعَ كَافَّةِ الْمُسْتَنَدَاتِ وَالأَوْرَاقِ الرَّسْمِيَّةِ وَالتَّوْقِيعِ الشَّخْصِيِّ.
              </p>
            </div>

            {/* Official Stamps and Signatures Grid */}
            <div className="grid grid-cols-3 gap-4 pt-4 text-center text-xs">
              <div className="space-y-8">
                <span className="font-bold text-slate-700 block">تَوْقِيعُ الدَّارِسِ الْمُعْتَمَد</span>
                <div className="font-bold text-slate-900 border-b border-dotted border-slate-400 pb-1 w-32 mx-auto">
                  {answers.signatureDrawn ? '✍️ توقيع إلكتروني موثق' : candidateName}
                </div>
              </div>

              <div className="flex flex-col items-center justify-center space-y-1">
                <div className="w-20 h-20 rounded-full border-4 border-dashed border-amber-800/50 flex flex-col items-center justify-center text-amber-900 text-[10px] font-black p-1 rotate-[-8deg]">
                  <span>خَتْمُ النَّسْرِ</span>
                  <span className="text-base">🦅</span>
                  <span>مُعْتَمَدٌ رَسْمِيّاً</span>
                </div>
                <span className="text-[10px] text-slate-500 font-mono">{scoreData.certificateSerial}</span>
              </div>

              <div className="space-y-8">
                <span className="font-bold text-slate-700 block">لَجْنَةُ التَّقْيِيمِ وَالاعْتِمَاد</span>
                <div className="font-bold text-slate-900 border-b border-dotted border-slate-400 pb-1 w-32 mx-auto">
                  د. صلاح الدين عبد الرحمن
                </div>
              </div>
            </div>

            {/* Verification Barcode Footer */}
            <div className="border-t border-slate-200 pt-4 flex flex-col sm:flex-row items-center justify-between gap-2 text-[11px] text-slate-500">
              <div className="flex items-center gap-2">
                <QrCode className="w-4 h-4 text-slate-600" />
                <span>كود التحقق الإلكتروني المشفر: {scoreData.certificateSerial}</span>
              </div>
              <span>صالح كمسوغ تأهيلي لشهادات محو الأمية الرسمية في كافة المصالح الحكومية.</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
