import React, { useState, useEffect } from 'react';
import { Volume2, VolumeX, Award, Sparkles, User, Mic, Sliders } from 'lucide-react';
import { audioService } from '../utils/audio';
import { AudioSettingsModal } from './AudioSettingsModal';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  audioEnabled: boolean;
  setAudioEnabled: (enabled: boolean) => void;
  fontSize: 'normal' | 'large' | 'huge';
  setFontSize: (size: 'normal' | 'large' | 'huge') => void;
  onOpenCertificate: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  audioEnabled,
  setAudioEnabled,
  fontSize,
  setFontSize,
  onOpenCertificate,
}) => {
  const [isPlayingAudio, setIsPlayingAudio] = useState<boolean>(false);
  const [selectedVoice, setSelectedVoice] = useState<'salah' | 'eman'>('salah');
  const [isAudioSettingsOpen, setIsAudioSettingsOpen] = useState<boolean>(false);

  useEffect(() => {
    return audioService.subscribeState((playing) => {
      setIsPlayingAudio(playing);
    });
  }, []);

  const toggleAudio = () => {
    const next = !audioEnabled;
    setAudioEnabled(next);
    audioService.isAudioEnabled = next;
    if (next) {
      audioService.playSound('pop');
      audioService.speak('تم تشغيل الصوت المصري. اضغط على أي كلمة أو زرار لسماع نطقها فوراً.');
    } else {
      audioService.stop();
    }
  };

  const switchVoice = (voice: 'salah' | 'eman') => {
    setSelectedVoice(voice);
    audioService.voicePreference = voice;
    audioService.playSound('pop');
    if (voice === 'salah') {
      audioService.speak('أهلاً بيك يا غالي! معاك عم صلاح، بصوتي المصري الدافئ.');
    } else {
      audioService.speak('أهلاً بيك يا فندم! معاك مس إيمان، خطوة بخطوة هنتعلم وننور طريقنا.');
    }
  };

  const navItems = [
    { id: 'alphabet', label: 'الحروف والأصوات', icon: 'أ ب ت' },
    { id: 'phonics-lab', label: 'معمل المتشابهات واليافطة', icon: '🔍' },
    { id: 'words', label: 'تكوين الكلمات والمقاطع', icon: '📝' },
    { id: 'numbers', label: 'الأرقام والفلوس المصرية', icon: '💵' },
    { id: 'life', label: 'مواقف الحياة والشارع', icon: '🚌' },
    { id: 'simulator', label: 'محاكي الـ ATM والفواتير', icon: '🏧' },
    { id: 'canvas', label: 'سبورة التوقيع والرسم', icon: '✍️' },
    { id: 'teacher', label: 'اسأل عم صلاح', icon: '👨‍🏫' },
    { id: 'quiz', label: 'اختبر نفسك', icon: '⭐' },
    { id: 'exam', label: 'الامتحان المعتمد (GALAE)', icon: '📋' },
    { id: 'dossier', label: 'ملف الاعتماد الحكومي 🇪🇬', icon: '🏛️' },
  ];

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-amber-200/70 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo & Identity */}
          <div
            onClick={() => {
              setActiveTab('alphabet');
              audioService.speak('منصة نور لمحو الأمية في مصر. نورتنا يا غالي!');
            }}
            className="flex items-center gap-3 cursor-pointer group"
          >
            <div className="w-13 h-13 rounded-2xl bg-gradient-to-br from-amber-500 via-amber-600 to-amber-700 flex items-center justify-center text-white shadow-md shadow-amber-500/20 group-hover:scale-105 transition-transform relative">
              <span className="text-3xl font-extrabold font-['Alexandria',sans-serif]">ن</span>
              {isPlayingAudio && (
                <span className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-emerald-400 rounded-full animate-ping" />
              )}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight font-['Alexandria',sans-serif]">
                  نُـــــور
                </span>
                <span className="text-xs bg-amber-100 text-amber-800 font-bold px-2 py-0.5 rounded-full border border-amber-300">
                  مصر 🇪🇬
                </span>
                {isPlayingAudio && (
                  <span className="hidden sm:inline-flex items-center gap-1 text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200 animate-pulse">
                    <Mic className="w-3 h-3" />
                    <span>الصوت شغال الآن</span>
                  </span>
                )}
              </div>
              <p className="text-xs sm:text-sm text-slate-600 font-medium hidden sm:block">
                منصة تعليم القراءة والكتابة والحساب للكبار بالعامية المصرية
              </p>
            </div>
          </div>

          {/* Controls: Voice Selector, Audio Toggle, Text Size, Diploma */}
          <div className="flex items-center gap-2 sm:gap-2.5">
            {/* Egyptian Voice Persona Selector (عم صلاح / مس إيمان) */}
            <div className="hidden lg:flex items-center bg-amber-50 border border-amber-200 p-1 rounded-xl text-xs font-bold">
              <button
                onClick={() => switchVoice('salah')}
                className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg transition-all ${
                  selectedVoice === 'salah'
                    ? 'bg-amber-600 text-white shadow-xs'
                    : 'text-amber-900 hover:text-black'
                }`}
                title="صوت عم صلاح (معلم مصري دافئ)"
              >
                <span>👨‍🏫 عم صلاح</span>
              </button>
              <button
                onClick={() => switchVoice('eman')}
                className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg transition-all ${
                  selectedVoice === 'eman'
                    ? 'bg-amber-600 text-white shadow-xs'
                    : 'text-amber-900 hover:text-black'
                }`}
                title="صوت مس إيمان (معلمة مصرية مشجعة)"
              >
                <span>👩‍🏫 مس إيمان</span>
              </button>
            </div>

            {/* Free Voice Engine Settings Trigger */}
            <button
              onClick={() => {
                audioService.playSound('pop');
                setIsAudioSettingsOpen(true);
              }}
              className="flex items-center gap-1.5 px-3 py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 rounded-xl text-xs sm:text-sm font-black transition-all shadow-xs"
              title="إعدادات الصوت والنطق المصري المجاني ١٠٠٪"
            >
              <span>🎙️</span>
              <span className="hidden sm:inline">صوت مجاني ١٠٠٪</span>
            </button>

            {/* Audio Toggle Button */}
            <button
              onClick={toggleAudio}
              className={`flex items-center gap-2 px-3 sm:px-3.5 py-2 rounded-xl text-xs sm:text-sm font-bold border transition-all ${
                audioEnabled
                  ? 'bg-amber-500 hover:bg-amber-600 text-white border-amber-600 shadow-sm'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-600 border-slate-300'
              }`}
              title={audioEnabled ? 'الصوت شغال - اضغط لكتم الصوت' : 'الصوت مكتوم - اضغط للتشغيل'}
            >
              {audioEnabled ? (
                <Volume2 className={`w-4 h-4 ${isPlayingAudio ? 'animate-bounce' : ''}`} />
              ) : (
                <VolumeX className="w-4 h-4 text-slate-400" />
              )}
              <span className="hidden md:inline">{audioEnabled ? 'القارئ مفعّل' : 'تشغيل الصوت'}</span>
            </button>

            {/* Font Size Selector */}
            <div className="flex items-center bg-slate-100 p-1 rounded-xl border border-slate-200 text-xs font-bold text-slate-700">
              <button
                onClick={() => setFontSize('normal')}
                className={`px-2 py-1.5 rounded-lg transition-colors ${
                  fontSize === 'normal' ? 'bg-white shadow-xs text-slate-900' : 'hover:text-slate-900'
                }`}
                title="خط عادي"
              >
                عادي
              </button>
              <button
                onClick={() => setFontSize('large')}
                className={`px-2 py-1.5 rounded-lg transition-colors ${
                  fontSize === 'large' ? 'bg-white shadow-xs text-slate-900' : 'hover:text-slate-900'
                }`}
                title="خط كبير"
              >
                كبير
              </button>
              <button
                onClick={() => setFontSize('huge')}
                className={`px-2 py-1.5 rounded-lg transition-colors ${
                  fontSize === 'huge' ? 'bg-white shadow-xs text-slate-900' : 'hover:text-slate-900'
                }`}
                title="خط كبير جداً"
              >
                أكبر
              </button>
            </div>

            {/* Diploma / Certificate Generator */}
            <button
              onClick={() => {
                audioService.cheerSuccess();
                audioService.speak('شهادة التقدير والاجتياز لمحو الأمية. خطوتك تستاهل كل التقدير!');
                onOpenCertificate();
              }}
              className="flex items-center gap-1.5 px-3 sm:px-3.5 py-2 bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-700 hover:to-teal-800 text-white rounded-xl text-xs sm:text-sm font-bold shadow-sm transition-all"
            >
              <Award className="w-4 h-4 text-amber-300" />
              <span className="hidden sm:inline">شهادة إتمام</span>
            </button>
          </div>
        </div>

        {/* Navigation Tabs Bar */}
        <nav className="flex items-center gap-1.5 overflow-x-auto pb-3 pt-1 scrollbar-none no-scrollbar">
          {navItems.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  setActiveTab(item.id);
                  audioService.playSound('click');
                  audioService.speak(`قسم ${item.label}`);
                }}
                className={`flex items-center gap-2 px-3 sm:px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap transition-all ${
                  isActive
                    ? 'bg-amber-600 text-white shadow-md shadow-amber-600/20'
                    : 'bg-amber-100/60 hover:bg-amber-200/60 text-slate-800 border border-amber-200/60'
                }`}
              >
                <span className="text-base">{item.icon}</span>
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>
      </div>

      {/* Audio Settings Modal */}
      <AudioSettingsModal
        isOpen={isAudioSettingsOpen}
        onClose={() => setIsAudioSettingsOpen(false)}
      />
    </header>
  );
};
