import React, { useState, useRef, useEffect } from 'react';
import { Play, Pause, Volume2, Headphones, Sparkles, CheckCircle2, RotateCcw } from 'lucide-react';
import { audioService } from '../utils/audio';

export const MasterAudioPlayer: React.FC = () => {
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [activeTrack, setActiveTrack] = useState<'guide' | 'letters'>('guide');
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [duration, setDuration] = useState<number>(0);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const tracks = {
    guide: {
      id: 'noor_master_guide',
      src: '/audio/noor_master_guide.mp3',
      title: 'الشرح الشامل ومواقف الحياة اليومية',
      desc: 'جولة كاملة بصوت عم صلاح تشرح المنصة، أسرار قراءة اليافطات، الفلوس، ومواقف الشارع',
      fallbackText: 'أهلاً بيك يا غالي في الدورة الصوتية الكاملة لمنصة نور لمحو الأمية في مصر! خطوة بخطوة القراءة والكتابة هتنور طريقك.',
    },
    letters: {
      id: 'noor_letters_complete',
      src: '/audio/noor_letters_complete.mp3',
      title: 'دورة الحروف الهجائية الـ ٢٨ بالتسلسل',
      desc: 'نطق الحروف الثمانية والعشرين بالترتيب من الألف إلى الياء بالحركات والأمثلة المصرية',
      fallbackText: 'دورة الحروف الهجائية الثمانية والعشرون: ألف، باء، تاء، ثاء، جيم، حاء، خاء، دال، ذال، راء، زاي، سين، شين، صاد، ضاد، طاء، ظاء، عين، غين، فاء، قاف، كاف، لام، ميم، نون، هاء، واو، ياء.',
    },
  };

  const currentTrackData = tracks[activeTrack];

  const togglePlay = () => {
    const audio = audioRef.current;
    if (!audio) return;

    if (isPlaying) {
      audio.pause();
      setIsPlaying(false);
      audioService.stop();
    } else {
      audioService.stop();
      audio
        .play()
        .then(() => {
          setIsPlaying(true);
        })
        .catch(() => {
          // File not uploaded yet, fallback to audioService speak
          setIsPlaying(true);
          audioService.speak(currentTrackData.fallbackText, () => {
            setIsPlaying(false);
          });
        });
    }
  };

  const handleTrackChange = (track: 'guide' | 'letters') => {
    if (audioRef.current) {
      audioRef.current.pause();
    }
    audioService.stop();
    setIsPlaying(false);
    setActiveTrack(track);
    audioService.playSound('click');
  };

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  return (
    <div className="bg-gradient-to-r from-amber-900 via-amber-950 to-stone-900 text-white rounded-3xl p-5 sm:p-6 border-2 border-amber-500/50 shadow-xl space-y-4">
      {/* Audio element pointing to master MP3s */}
      <audio
        ref={audioRef}
        src={currentTrackData.src}
        onTimeUpdate={() => {
          if (audioRef.current) {
            setCurrentTime(audioRef.current.currentTime);
            setDuration(audioRef.current.duration || 0);
          }
        }}
        onEnded={() => setIsPlaying(false)}
        onError={() => {
          // File not found on server yet
        }}
      />

      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        {/* Left identity */}
        <div className="flex items-center gap-3.5">
          <div className="w-13 h-13 rounded-2xl bg-amber-500 text-slate-950 flex items-center justify-center text-2xl font-black shadow-md shadow-amber-500/20 shrink-0">
            <Headphones className="w-6 h-6 text-slate-950" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs bg-amber-500/30 text-amber-300 font-bold px-2.5 py-0.5 rounded-full border border-amber-400/30">
                تسجيل إيليفن لابس الاستوديو
              </span>
              <span className="text-xs text-slate-400">ملف كامل شامل</span>
            </div>
            <h3 className="text-lg sm:text-xl font-black text-white mt-0.5">
              {currentTrackData.title}
            </h3>
            <p className="text-xs text-amber-200/80 font-medium line-clamp-1">
              {currentTrackData.desc}
            </p>
          </div>
        </div>

        {/* Track switch buttons */}
        <div className="flex items-center gap-2 bg-black/40 p-1.5 rounded-2xl border border-white/10 text-xs font-bold self-start md:self-auto">
          <button
            onClick={() => handleTrackChange('guide')}
            className={`px-3 py-2 rounded-xl transition-all ${
              activeTrack === 'guide'
                ? 'bg-amber-500 text-slate-950 font-black shadow-xs'
                : 'text-slate-300 hover:text-white'
            }`}
          >
            ١. الشرح العام ومواقف الحياة
          </button>
          <button
            onClick={() => handleTrackChange('letters')}
            className={`px-3 py-2 rounded-xl transition-all ${
              activeTrack === 'letters'
                ? 'bg-amber-500 text-slate-950 font-black shadow-xs'
                : 'text-slate-300 hover:text-white'
            }`}
          >
            ٢. دورة الحروف الـ ٢٨ كاملة
          </button>
        </div>
      </div>

      {/* Playback Control Bar */}
      <div className="flex items-center gap-4 bg-white/5 p-3 rounded-2xl border border-white/10">
        <button
          onClick={togglePlay}
          className="w-12 h-12 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 flex items-center justify-center transition-all shadow-md shrink-0 hover:scale-105 active:scale-95"
          title={isPlaying ? 'إيقاف مؤقت' : 'تشغيل التسجيل الكامل'}
        >
          {isPlaying ? <Pause className="w-6 h-6 fill-current" /> : <Play className="w-6 h-6 fill-current ml-0.5" />}
        </button>

        <div className="flex-1 space-y-1">
          <div className="flex items-center justify-between text-[11px] font-bold text-amber-300">
            <span>{isPlaying ? 'جاري الاستماع الآن بصوت عم صلاح...' : 'اضغط تشغيل للاستماع للتسجيل الكامل دفعة واحدة'}</span>
            {duration > 0 && (
              <span>
                {formatTime(currentTime)} / {formatTime(duration)}
              </span>
            )}
          </div>
          <div className="w-full h-2 bg-white/10 rounded-full overflow-hidden">
            <div
              className="h-full bg-amber-400 rounded-full transition-all duration-300"
              style={{ width: `${duration > 0 ? (currentTime / duration) * 100 : isPlaying ? 100 : 0}%` }}
            />
          </div>
        </div>

        <button
          onClick={() => {
            if (audioRef.current) {
              audioRef.current.currentTime = 0;
            }
            setCurrentTime(0);
            audioService.playSound('click');
          }}
          className="p-2.5 text-slate-400 hover:text-white bg-white/5 rounded-xl transition-colors shrink-0"
          title="إعادة من البداية"
        >
          <RotateCcw className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
