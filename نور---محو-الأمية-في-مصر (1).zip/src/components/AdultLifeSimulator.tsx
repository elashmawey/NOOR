import React, { useState, useEffect } from 'react';
import {
  CreditCard,
  Receipt,
  FileCheck2,
  Calendar,
  Volume2,
  ShieldCheck,
  AlertTriangle,
  ArrowRight,
  CheckCircle2,
  RotateCcw,
  Sparkles,
  Lock,
  Smartphone,
  Eye,
  EyeOff,
  Building,
  HelpCircle,
  Award,
} from 'lucide-react';
import { audioService } from '../utils/audio';

export const AdultLifeSimulator: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'atm' | 'bills' | 'forms' | 'journey'>('atm');

  // ATM Simulator States
  const [atmStep, setAtmStep] = useState<'insert-card' | 'enter-pin' | 'select-service' | 'select-amount' | 'dispense' | 'receipt'>('insert-card');
  const [atmPin, setAtmPin] = useState<string>('');
  const [selectedAmount, setSelectedAmount] = useState<number>(500);
  const [atmAccountBalance, setAtmAccountBalance] = useState<number>(3450);
  const [showPin, setShowPin] = useState<boolean>(false);

  // Bills Simulator States
  const [selectedBill, setSelectedBill] = useState<'electricity' | 'water' | 'pension-sms'>('electricity');
  const [billQuizAnswered, setBillQuizAnswered] = useState<boolean>(false);
  const [billQuizSelected, setBillQuizSelected] = useState<number | null>(null);

  // Government Form States
  const [formName, setFormName] = useState<string>('حسن محمود السيد علي');
  const [formNid, setFormNid] = useState<string>('27508142109876');
  const [formAddress, setFormAddress] = useState<string>('قرية بني منصور - مركز البلينا - سوهاج');
  const [formJob, setFormJob] = useState<string>('عامل زراعي / حر');
  const [formSigned, setFormSigned] = useState<boolean>(false);
  const [formSubmitted, setFormSubmitted] = useState<boolean>(false);

  // 30-Day Journey States
  const [completedDays, setCompletedDays] = useState<number[]>(() => {
    try {
      const saved = localStorage.getItem('noor_journey_days');
      return saved ? JSON.parse(saved) : [1, 2, 3];
    } catch {
      return [1, 2, 3];
    }
  });

  const toggleDayComplete = (day: number) => {
    let nextDays: number[];
    if (completedDays.includes(day)) {
      nextDays = completedDays.filter((d) => d !== day);
    } else {
      nextDays = [...completedDays, day].sort((a, b) => a - b);
      audioService.cheerSuccess();
      audioService.speak(`الله ينور عليك! أتممت بنجاح اليوم رقم ${day} من تحدي النور.`);
    }
    setCompletedDays(nextDays);
    try {
      localStorage.setItem('noor_journey_days', JSON.stringify(nextDays));
    } catch {}
  };

  // ATM Logic
  const handleInsertCard = () => {
    audioService.playSound('pop');
    setAtmStep('enter-pin');
    audioService.speak('تم إدخال البطاقة بنجاح. اكتب رقمك السري المكون من أربعة أرقام على لوحة المفاتيح، وتأكد أن تغطي يدك لمنع أي شخص من رؤيته.');
  };

  const handleKeypadPress = (digit: string) => {
    if (atmPin.length < 4) {
      audioService.playSound('click');
      const nextPin = atmPin + digit;
      setAtmPin(nextPin);
      if (nextPin.length === 4) {
        audioService.playSound('correct');
        audioService.speak('تم إدخال الرقم السري. اضغط على زر استمرار أو تأكيد.');
      }
    }
  };

  const handleClearPin = () => {
    audioService.playSound('pop');
    setAtmPin('');
  };

  const handleConfirmPin = () => {
    if (atmPin.length !== 4) {
      audioService.encourageRetry();
      audioService.speak('الرقم السري لازم يكون أربعة أرقام بالتمام.');
      return;
    }
    audioService.playSound('correct');
    setAtmStep('select-service');
    audioService.speak('اختر نوع المعاملة: سحب نقدي للفلوس، أو استعلام عن الرصيد المتبقي.');
  };

  const handleSelectService = (service: 'withdraw' | 'balance') => {
    audioService.playSound('click');
    if (service === 'withdraw') {
      setAtmStep('select-amount');
      audioService.speak('اختر المبلغ الذي تريد سحبه بالجنيه المصري، أو حدد مبلغاً آخر.');
    } else {
      audioService.cheerSuccess();
      audioService.speak(`رصيدك المتاح في الحساب الآن هو: ${atmAccountBalance} جنيهاً مصرياً.`);
      setAtmStep('receipt');
    }
  };

  const handleWithdrawAmount = (amt: number) => {
    audioService.playSound('pop');
    setSelectedAmount(amt);
    setAtmStep('dispense');
    audioService.speak(`جاري تجهيز مبلغ ${amt} جنيهاً. يرجى الانتظار لاستلام بطاقتك أولاً ثم النقود والإيصال.`);
    setTimeout(() => {
      audioService.playSound('celebrate');
      setAtmAccountBalance((prev) => prev - amt);
      setAtmStep('receipt');
      audioService.speak('استلم نقودك وبطاقتك بأمان. لا تنسَ سحب الكارت قبل مغادرة الماكينة.');
    }, 2800);
  };

  const resetAtm = () => {
    setAtmStep('insert-card');
    setAtmPin('');
    audioService.speak('تمت إعادة ماكينة الصراف الآلي لوضع البداية.');
  };

  return (
    <div className="space-y-8">
      {/* Hero Banner */}
      <div className="bg-gradient-to-r from-teal-900 via-emerald-950 to-slate-900 rounded-3xl p-6 sm:p-8 text-white shadow-xl border border-emerald-500/30 relative overflow-hidden">
        <div className="relative z-10 max-w-3xl space-y-3">
          <div className="inline-flex items-center gap-2 bg-emerald-500/30 text-emerald-200 font-black px-3.5 py-1.5 rounded-full text-xs sm:text-sm border border-emerald-400/40">
            <Sparkles className="w-4 h-4 text-amber-300" />
            <span>التمكين الحياتي الفعلي للكبار · مبادرة الشمول الرقمي</span>
          </div>

          <h1 className="text-2xl sm:text-4xl font-black font-['Alexandria',sans-serif] tracking-tight leading-tight">
            محاكي المعاملات الحياتية: الـ ATM، الفواتير، والاستمارات الرسمية
          </h1>

          <p className="text-emerald-100 text-xs sm:text-base leading-relaxed">
            محو الأمية الحقيقي لا يتوقف عند قراءة الحروف؛ بل يمنحك الاستقلالية الكاملة لصرف معاشك من ماكينة الصراف الآلي بنفسك بأمان دون طلب مساعدة غريب، وقراءة فواتيرك، وملء أوراقك الحكومية بكل عزة نفس.
          </p>
        </div>

        {/* 4 Pillars ribbon */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6 pt-6 border-t border-emerald-800/50 text-xs">
          <div className="flex items-center gap-2 text-emerald-200">
            <CreditCard className="w-4 h-4 text-amber-400" />
            <span>محاكي ماكينة ATM واقعي</span>
          </div>
          <div className="flex items-center gap-2 text-emerald-200">
            <Receipt className="w-4 h-4 text-amber-400" />
            <span>قراءة فواتير ورسائل المعاش</span>
          </div>
          <div className="flex items-center gap-2 text-emerald-200">
            <FileCheck2 className="w-4 h-4 text-amber-400" />
            <span>ملء الاستمارات الرسمية</span>
          </div>
          <div className="flex items-center gap-2 text-emerald-200">
            <Calendar className="w-4 h-4 text-amber-400" />
            <span>خطة التحدي ٣٠ يوماً</span>
          </div>
        </div>
      </div>

      {/* Navigation Subtabs */}
      <div className="flex flex-wrap items-center gap-2 border-b border-slate-200 pb-3">
        {[
          { id: 'atm', label: 'محاكي ماكينة الـ ATM المصرية', icon: '🏧' },
          { id: 'bills', label: 'قراءة الفواتير والرسائل الحكومية', icon: '🧾' },
          { id: 'forms', label: 'ملء الاستمارة والبيانات الحكومية', icon: '📝' },
          { id: 'journey', label: 'خطة التحدي ٣٠ يوماً العملية', icon: '🗓️' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => {
              setActiveTab(tab.id as any);
              audioService.playSound('click');
              audioService.speak(`قسم ${tab.label}`);
            }}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl font-black text-xs sm:text-sm transition-all ${
              activeTab === tab.id
                ? 'bg-emerald-800 text-white shadow-md'
                : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200'
            }`}
          >
            <span>{tab.icon}</span>
            <span>{tab.label}</span>
          </button>
        ))}
      </div>

      {/* TAB 1: Real Egyptian ATM Simulator */}
      {activeTab === 'atm' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left ATM Machine Shell (Cols 1-7) */}
          <div className="lg:col-span-7 bg-slate-900 rounded-3xl p-6 sm:p-8 text-white shadow-2xl border-4 border-slate-800 relative space-y-6">
            {/* ATM Top Brand Banner */}
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-600 flex items-center justify-center font-black text-lg">
                  🏦
                </div>
                <div>
                  <span className="text-base font-black font-['Alexandria',sans-serif] block">
                    ماكينة الصراف الآلي (ATM)
                  </span>
                  <span className="text-xs text-emerald-400 font-bold">
                    شبكة كروت ميزة وبطاقات المعاشات المصرية
                  </span>
                </div>
              </div>

              <button
                onClick={resetAtm}
                className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-white bg-slate-800 px-3 py-1.5 rounded-xl border border-slate-700 transition-colors"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>إلغاء وبدء من جديد</span>
              </button>
            </div>

            {/* ATM Screen Display */}
            <div className="bg-[#0c2b23] border-4 border-emerald-700/80 rounded-2xl p-6 text-emerald-100 min-h-[300px] flex flex-col justify-between shadow-inner relative overflow-hidden">
              {/* ATM Step 1: Insert Card */}
              {atmStep === 'insert-card' && (
                <div className="text-center py-8 space-y-4 my-auto">
                  <div className="w-20 h-20 rounded-full bg-emerald-900/60 border-2 border-emerald-500/50 flex items-center justify-center mx-auto text-4xl animate-pulse">
                    💳
                  </div>
                  <h3 className="text-xl sm:text-2xl font-black text-white font-['Alexandria',sans-serif]">
                    مرحباً بكم في شبكة الصراف الآلي
                  </h3>
                  <p className="text-sm text-emerald-200 max-w-md mx-auto">
                    يرجى إدخال بطاقتك الذكية (كارت ميزة أو فيزا المعاشات) في المكان المخصص لأسفل.
                  </p>
                  <button
                    onClick={handleInsertCard}
                    className="px-6 py-3 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-sm rounded-xl shadow-lg transition-transform hover:scale-105 active:scale-95 inline-flex items-center gap-2"
                  >
                    <CreditCard className="w-5 h-5" />
                    <span>محاكاة: أدخل الكارت في الماكينة الآن</span>
                  </button>
                </div>
              )}

              {/* ATM Step 2: Enter PIN */}
              {atmStep === 'enter-pin' && (
                <div className="space-y-4 my-auto text-center">
                  <div className="inline-flex items-center gap-1.5 bg-emerald-900/80 text-emerald-300 text-xs font-bold px-3 py-1 rounded-full border border-emerald-600/50">
                    <Lock className="w-3.5 h-3.5" />
                    أمان تام: لا تشارك رقمك السري مع أي شخص
                  </div>

                  <h3 className="text-lg sm:text-xl font-black text-white">
                    أَدْخِلِ الرَّقَمَ السِّرِّيَّ (٤ أَرْقَام):
                  </h3>

                  {/* Masked PIN Dots */}
                  <div className="flex items-center justify-center gap-3 py-2">
                    {[0, 1, 2, 3].map((idx) => {
                      const hasChar = atmPin.length > idx;
                      return (
                        <div
                          key={idx}
                          className={`w-12 h-14 rounded-xl border-2 flex items-center justify-center text-2xl font-black font-mono transition-all ${
                            hasChar
                              ? 'bg-emerald-500 text-slate-950 border-emerald-400 shadow-md scale-105'
                              : 'bg-emerald-950/60 border-emerald-800 text-emerald-600'
                          }`}
                        >
                          {hasChar ? (showPin ? atmPin[idx] : '●') : '-'}
                        </div>
                      );
                    })}
                  </div>

                  <div className="flex items-center justify-center gap-3 pt-2">
                    <button
                      onClick={() => setShowPin(!showPin)}
                      className="text-xs text-emerald-300 hover:text-white flex items-center gap-1 bg-emerald-900/50 px-3 py-1.5 rounded-lg border border-emerald-700/50"
                    >
                      {showPin ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                      <span>{showPin ? 'إخفاء الرقم' : 'إظهار الرقم للمراجعة'}</span>
                    </button>
                    <button
                      onClick={handleConfirmPin}
                      disabled={atmPin.length !== 4}
                      className="text-xs font-black bg-emerald-500 hover:bg-emerald-400 disabled:opacity-40 text-slate-950 px-4 py-1.5 rounded-lg transition-all"
                    >
                      تأكيد والدخول ⬅️
                    </button>
                  </div>
                </div>
              )}

              {/* ATM Step 3: Select Service */}
              {atmStep === 'select-service' && (
                <div className="space-y-4 my-auto">
                  <div className="text-center">
                    <h3 className="text-xl font-black text-white">اختر نوع العملية المطلوبة:</h3>
                    <p className="text-xs text-emerald-300">
                      اضغط على الخدمة التي تريد تنفيذها اليوم
                    </p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                    <button
                      onClick={() => handleSelectService('withdraw')}
                      className="p-4 rounded-xl bg-emerald-800/80 hover:bg-emerald-600 text-white font-black text-right border border-emerald-500/50 flex items-center justify-between group transition-all"
                    >
                      <div>
                        <span className="text-base block">سَحْبٌ نَقْدِيٌّ (فُلُوس)</span>
                        <span className="text-[11px] text-emerald-200">استلام مبالغ نقدية كاش</span>
                      </div>
                      <ArrowRight className="w-5 h-5 text-emerald-300 group-hover:translate-x-[-4px] transition-transform" />
                    </button>

                    <button
                      onClick={() => handleSelectService('balance')}
                      className="p-4 rounded-xl bg-emerald-800/80 hover:bg-emerald-600 text-white font-black text-right border border-emerald-500/50 flex items-center justify-between group transition-all"
                    >
                      <div>
                        <span className="text-base block">اسْتِعْلَامٌ عَنِ الرَّصِيد</span>
                        <span className="text-[11px] text-emerald-200">معرفة المبلغ المتبقي بالحساب</span>
                      </div>
                      <ArrowRight className="w-5 h-5 text-emerald-300 group-hover:translate-x-[-4px] transition-transform" />
                    </button>
                  </div>
                </div>
              )}

              {/* ATM Step 4: Select Amount */}
              {atmStep === 'select-amount' && (
                <div className="space-y-4 my-auto">
                  <div className="text-center">
                    <h3 className="text-xl font-black text-white">اختر المبلغ المراد سحبه:</h3>
                    <p className="text-xs text-emerald-300">المبالغ بالجنيه المصري (ج.م)</p>
                  </div>

                  <div className="grid grid-cols-2 gap-2.5 pt-2">
                    {[100, 200, 500, 1000, 1500, 2000].map((amt) => (
                      <button
                        key={amt}
                        onClick={() => handleWithdrawAmount(amt)}
                        className="p-3 bg-emerald-900/80 hover:bg-emerald-500 hover:text-slate-950 text-white font-black rounded-xl border border-emerald-700/60 transition-all text-center"
                      >
                        <span className="text-lg font-mono block">{amt} ج.م</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* ATM Step 5: Dispensing Cash */}
              {atmStep === 'dispense' && (
                <div className="text-center py-10 space-y-4 my-auto">
                  <div className="w-20 h-20 rounded-full bg-emerald-500 text-slate-950 flex items-center justify-center text-3xl mx-auto animate-bounce">
                    💵
                  </div>
                  <h3 className="text-xl font-black text-white">جاري عدّ النقود وتجهيزها...</h3>
                  <p className="text-sm text-emerald-200">
                    استعد لاستلام بطاقتك أولاً، ثم اسحب النقود من الفتحة السفلية.
                  </p>
                </div>
              )}

              {/* ATM Step 6: Receipt & Card Ejection */}
              {atmStep === 'receipt' && (
                <div className="space-y-4 my-auto text-center">
                  <div className="w-14 h-14 rounded-full bg-emerald-500 text-slate-950 flex items-center justify-center text-2xl mx-auto">
                    <CheckCircle2 className="w-8 h-8" />
                  </div>
                  <h3 className="text-xl font-black text-white">تمت العملية بنجاح!</h3>
                  <div className="p-3 rounded-xl bg-emerald-950/80 border border-emerald-700/60 max-w-sm mx-auto text-xs space-y-1 text-emerald-200 font-mono text-right">
                    <div className="flex justify-between">
                      <span>المبلغ المسحوب:</span>
                      <span className="font-bold text-white">{selectedAmount} ج.م</span>
                    </div>
                    <div className="flex justify-between">
                      <span>الرصيد المتبقي بالحساب:</span>
                      <span className="font-bold text-emerald-400">{atmAccountBalance} ج.م</span>
                    </div>
                  </div>

                  <div className="p-2.5 rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-200 text-xs font-bold max-w-sm mx-auto flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
                    <span>تنبيه أمان: خذ بطاقتك الآن فوراً قبل مغادرة الماكينة!</span>
                  </div>

                  <button
                    onClick={resetAtm}
                    className="px-6 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs rounded-xl"
                  >
                    استرداد الكارت وإنهاء العملية
                  </button>
                </div>
              )}
            </div>

            {/* ATM Physical Keypad Simulation */}
            <div className="bg-slate-800 rounded-2xl p-4 border border-slate-700 space-y-3">
              <span className="text-xs font-bold text-slate-400 block text-center">
                لوحة الأرقام الفعلية (Keypad) - اضغط لإدخال الأرقام:
              </span>

              <div className="grid grid-cols-3 gap-2 max-w-xs mx-auto">
                {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((digit) => (
                  <button
                    key={digit}
                    onClick={() => handleKeypadPress(digit)}
                    className="h-12 bg-slate-700 hover:bg-slate-600 active:bg-slate-500 text-white font-mono font-black text-lg rounded-xl border border-slate-600 shadow-sm transition-all"
                  >
                    {digit}
                  </button>
                ))}
                <button
                  onClick={handleClearPin}
                  className="h-12 bg-amber-700/80 hover:bg-amber-600 text-white font-black text-xs rounded-xl border border-amber-600"
                >
                  مسح ⌫
                </button>
                <button
                  onClick={() => handleKeypadPress('0')}
                  className="h-12 bg-slate-700 hover:bg-slate-600 active:bg-slate-500 text-white font-mono font-black text-lg rounded-xl border border-slate-600"
                >
                  0
                </button>
                <button
                  onClick={handleConfirmPin}
                  className="h-12 bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs rounded-xl border border-emerald-500"
                >
                  إدخال ⏎
                </button>
              </div>
            </div>
          </div>

          {/* Right Safety Guide & ATM Rules (Cols 8-12) */}
          <div className="lg:col-span-5 space-y-4">
            <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
              <div className="flex items-center gap-2.5">
                <ShieldCheck className="w-6 h-6 text-emerald-600" />
                <h3 className="text-base font-black text-slate-900">
                  قواعد الأمان الذهبية أمام ماكينة الـ ATM
                </h3>
              </div>

              <div className="space-y-3 text-xs sm:text-sm text-slate-700">
                <div className="p-3 rounded-2xl bg-amber-50 border border-amber-200 flex items-start gap-2.5">
                  <span className="text-amber-700 font-black text-base shrink-0">١.</span>
                  <div>
                    <strong className="block text-slate-900 font-bold mb-0.5">
                      لا تعطي كارتك ورقمك السري لأي غريب:
                    </strong>
                    <span>
                      مهما بدا الشخص لطيفاً في طابور المعاشات، لا تعطِ كارتك أو الباسورد لأحد ليسحبه لك. تدرب هنا واسحب بنفسك!
                    </span>
                  </div>
                </div>

                <div className="p-3 rounded-2xl bg-blue-50 border border-blue-200 flex items-start gap-2.5">
                  <span className="text-blue-700 font-black text-base shrink-0">٢.</span>
                  <div>
                    <strong className="block text-slate-900 font-bold mb-0.5">
                      غطِّ لوحة المفاتيح بيدك الأخرى:
                    </strong>
                    <span>
                      وأنت تكتب الرقم السري (٤ أرقام)، ضع يدك الثانية فوق اللوحة لمنع الكاميرات أو الواقفين خلفك من حفظ رقمك.
                    </span>
                  </div>
                </div>

                <div className="p-3 rounded-2xl bg-emerald-50 border border-emerald-200 flex items-start gap-2.5">
                  <span className="text-emerald-700 font-black text-base shrink-0">٣.</span>
                  <div>
                    <strong className="block text-slate-900 font-bold mb-0.5">
                      اسحب الكارت أولاً ثم الفلوس:
                    </strong>
                    <span>
                      ماكينات مصر تصفر وتخرج الكارت أولاً لحمايتك من نسيانه، ثم تفتح بوابة خروج النقود الورقية.
                    </span>
                  </div>
                </div>
              </div>

              <button
                onClick={() => {
                  audioService.speak(
                    'قواعد الأمان أمام الـ ATM: لا تعطي كارتك أو رقمك السري لأي غريب مهما كان. غط لوحة المفاتيح بيدك الثانية وإنت بتكتب الباسورد. واسحب كارتك أول ما يخرج قبل ما الماكينة تسحبه.'
                  );
                }}
                className="w-full py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-xs font-bold flex items-center justify-center gap-2"
              >
                <Volume2 className="w-4 h-4 text-emerald-600" />
                <span>استمع لقواعد أمان الـ ATM بالصوت</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: Real Bills & Official SMS Reader */}
      {activeTab === 'bills' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Bill Picker (Cols 1-4) */}
          <div className="lg:col-span-4 space-y-3">
            <h3 className="text-base font-black text-slate-900">اختر المستند لقراءته:</h3>

            {[
              { id: 'electricity', title: 'فاتورة الكهرباء الشهرية', icon: '⚡', sub: 'قراءة المبلغ ورقم المشترك' },
              { id: 'water', title: 'فاتورة مياه الشرب', icon: '💧', sub: 'تاريخ الاستحقاق وفترة المحاسبة' },
              { id: 'pension-sms', title: 'رسالة صرف معاش التأمينات (SMS)', icon: '📱', sub: 'رسالة الموبايل الرسمية المعتمدة' },
            ].map((b) => (
              <div
                key={b.id}
                onClick={() => {
                  setSelectedBill(b.id as any);
                  setBillQuizAnswered(false);
                  setBillQuizSelected(null);
                  audioService.playSound('pop');
                  audioService.speak(`تم فتح ${b.title}. اقرأ البيانات أو استمع لشرحها.`);
                }}
                className={`p-4 rounded-2xl border-2 cursor-pointer transition-all flex items-start gap-3 ${
                  selectedBill === b.id
                    ? 'bg-emerald-50 border-emerald-600 shadow-sm'
                    : 'bg-white hover:bg-slate-50 border-slate-200'
                }`}
              >
                <span className="text-2xl p-2 rounded-xl bg-slate-100">{b.icon}</span>
                <div>
                  <h4 className="text-sm font-black text-slate-900">{b.title}</h4>
                  <p className="text-xs text-slate-500 mt-0.5">{b.sub}</p>
                </div>
              </div>
            ))}
          </div>

          {/* Interactive Document Showcase (Cols 5-12) */}
          <div className="lg:col-span-8 bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-6">
            {/* Electricity Bill Simulation */}
            {selectedBill === 'electricity' && (
              <div className="space-y-6">
                <div className="flex items-center justify-between border-b border-slate-200 pb-3">
                  <div>
                    <span className="text-xs font-bold text-amber-700 bg-amber-100 px-2.5 py-1 rounded-full">
                      وزارة الكهرباء والطاقة المتجددة
                    </span>
                    <h3 className="text-lg font-black text-slate-900 mt-1">
                      إيصال سداد فاتورة كهرباء منزلية
                    </h3>
                  </div>
                  <button
                    onClick={() => {
                      audioService.speak(
                        'فاتورة الكهرباء: المشترك أحمد عبد الرحيم، المبلغ المطلوب سداده هو مائة وخمسة وسبعون جنيهاً، الشريحة رقم اثنين، آخر موعد للسداد قبل يوم خمسة وعشرين من الشهر.'
                      );
                    }}
                    className="flex items-center gap-1.5 text-xs font-bold bg-slate-100 hover:bg-slate-200 text-slate-800 px-3 py-1.5 rounded-xl"
                  >
                    <Volume2 className="w-4 h-4 text-emerald-600" />
                    <span>اقرأ الفاتورة لي</span>
                  </button>
                </div>

                {/* Printable Styled Bill Box */}
                <div className="p-5 rounded-2xl bg-[#fffdf5] border-2 border-amber-300 shadow-inner font-mono text-xs sm:text-sm space-y-3">
                  <div className="flex justify-between border-b border-amber-200 pb-2">
                    <span className="font-bold text-slate-700">شركة جنوب الدلتا لتوزيع الكهرباء</span>
                    <span className="text-slate-500">رقم الفاتورة: #89412</span>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-slate-800">
                    <div>
                      <span className="text-slate-500 block text-xs">اسم المشترك:</span>
                      <strong className="text-slate-900 font-bold">أحمد عبد الرحيم حسن</strong>
                    </div>
                    <div>
                      <span className="text-slate-500 block text-xs">العنوان المسجل:</span>
                      <span>ش الجمهورية - عمارة ٤ - الدور ٢</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block text-xs">القراءة الحالية:</span>
                      <span className="font-bold">٤٥٨٠ ك.و.س</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block text-xs">الشريحة الحالية:</span>
                      <span className="font-bold text-emerald-800">الشريحة الثانية (٢)</span>
                    </div>
                  </div>

                  {/* Highlighted Amount */}
                  <div className="p-3 bg-amber-100/80 rounded-xl border border-amber-300 flex items-center justify-between">
                    <div>
                      <span className="text-xs text-amber-900 font-bold block">
                        إِجْمَالِي الْمَبْلَغِ الْمَطْلُوبِ سَدَادُهُ:
                      </span>
                      <span className="text-2xl font-black text-slate-950 font-mono">
                        ١٧٥٫٥٠ جُنَيْهاً
                      </span>
                    </div>
                    <span className="text-xs bg-amber-200 text-amber-900 font-black px-3 py-1 rounded-lg">
                      شامل الرسوم والنظافة
                    </span>
                  </div>
                </div>

                {/* Interactive Comprehension Question */}
                <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
                  <span className="text-xs font-black text-emerald-800">
                    تحدي القراءة السريعة (اختبر عينك):
                  </span>
                  <p className="text-sm font-extrabold text-slate-900">
                    كم هو المبلغ الإجمالي المطلوب سداده في الفاتورة أعلاه؟
                  </p>
                  <div className="grid grid-cols-3 gap-2">
                    {['١٧٥٫٥٠ ج.م', '٢٥٠٫٠٠ ج.م', '٧٥٫٠٠ ج.م'].map((opt, i) => (
                      <button
                        key={opt}
                        onClick={() => {
                          setBillQuizSelected(i);
                          setBillQuizAnswered(true);
                          if (i === 0) {
                            audioService.cheerSuccess();
                          } else {
                            audioService.encourageRetry();
                          }
                        }}
                        className={`p-2.5 rounded-xl text-xs font-black border transition-all ${
                          billQuizSelected === i
                            ? i === 0
                              ? 'bg-emerald-600 text-white border-emerald-600'
                              : 'bg-rose-600 text-white border-rose-600'
                            : 'bg-white hover:bg-slate-100 text-slate-800 border-slate-200'
                        }`}
                      >
                        {opt}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Official SMS Simulation */}
            {selectedBill === 'pension-sms' && (
              <div className="space-y-6">
                <div className="flex items-center justify-between border-b border-slate-200 pb-3">
                  <div>
                    <span className="text-xs font-bold text-blue-700 bg-blue-100 px-2.5 py-1 rounded-full">
                      الهيئة القومية للتأمين الاجتماعي
                    </span>
                    <h3 className="text-lg font-black text-slate-900 mt-1">
                      رسالة نصية على الموبايل (صرف المعاش الشهري)
                    </h3>
                  </div>
                  <button
                    onClick={() => {
                      audioService.speak(
                        'رسالة التأمينات: تم إيداع معاش شهر نوفمبر بمبلغ ألفين وثمانمائة جنيه في بطاقة ميزة الخاصة بك. يمكنك الصرف الآن من أي ماكينة صراف آلي بدون أي مصاريف.'
                      );
                    }}
                    className="flex items-center gap-1.5 text-xs font-bold bg-slate-100 hover:bg-slate-200 text-slate-800 px-3 py-1.5 rounded-xl"
                  >
                    <Volume2 className="w-4 h-4 text-emerald-600" />
                    <span>اقرأ الرسالة لي</span>
                  </button>
                </div>

                {/* Smartphone Screen Simulation */}
                <div className="max-w-md mx-auto bg-slate-900 rounded-3xl p-4 border-4 border-slate-800 shadow-xl space-y-3">
                  <div className="flex justify-between text-[11px] text-slate-400 font-mono px-2">
                    <span>9:41 AM</span>
                    <span>NOSI-EGYPT (التأمينات)</span>
                  </div>

                  <div className="p-4 rounded-2xl bg-emerald-950/80 border border-emerald-700/60 text-white space-y-2 text-xs sm:text-sm">
                    <p className="leading-relaxed">
                      "السيد المواطن / تم إيداع معاش شهر نوفمبر بمبلغ{' '}
                      <strong className="text-amber-300 font-mono text-base">٢٨٠٠ ج.م</strong> في
                      حساب كارت ميزة الخاص بكم، ويمكنكم الصرف مجاناً من أي ماكينة ATM."
                    </p>
                    <span className="text-[10px] text-emerald-400 block text-left">
                      تم الاستلام اليوم 9:40 ص
                    </span>
                  </div>
                </div>
              </div>
            )}

            {/* Water Bill Simulation */}
            {selectedBill === 'water' && (
              <div className="space-y-6">
                <div className="flex items-center justify-between border-b border-slate-200 pb-3">
                  <div>
                    <span className="text-xs font-bold text-teal-700 bg-teal-100 px-2.5 py-1 rounded-full">
                      الشركة القابضة لمياه الشرب والصرف الصحي
                    </span>
                    <h3 className="text-lg font-black text-slate-900 mt-1">فاتورة استهلاك المياه</h3>
                  </div>
                  <button
                    onClick={() => {
                      audioService.speak(
                        'فاتورة المياه: المبلغ المطلوب هو ثمانية وخمسون جنيهاً، فترة الاستهلاك عن شهرين، والسداد متاح لدى محصل الشركة أو عبر فوري.'
                      );
                    }}
                    className="flex items-center gap-1.5 text-xs font-bold bg-slate-100 hover:bg-slate-200 text-slate-800 px-3 py-1.5 rounded-xl"
                  >
                    <Volume2 className="w-4 h-4 text-emerald-600" />
                    <span>اقرأ الفاتورة لي</span>
                  </button>
                </div>

                <div className="p-5 rounded-2xl bg-teal-50/50 border border-teal-200 font-mono text-xs sm:text-sm space-y-2 text-slate-800">
                  <div className="flex justify-between border-b border-teal-200 pb-2">
                    <span className="font-bold">شركة مياه الشرب بالبحيرة</span>
                    <span>إيصال رقم #5411</span>
                  </div>
                  <div className="flex justify-between pt-1">
                    <span>كمية الاستهلاك:</span>
                    <strong>٢٢ متراً مكعباً</strong>
                  </div>
                  <div className="flex justify-between pt-1">
                    <span>المبلغ المستحق سداده:</span>
                    <strong className="text-teal-900 font-black text-lg">٥٨٫٠٠ جُنَيْهاً</strong>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 3: Official Egyptian Government Form Filler */}
      {activeTab === 'forms' && (
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-6 max-w-4xl mx-auto">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-4">
            <div>
              <span className="text-xs font-bold text-amber-800 bg-amber-100 px-3 py-1 rounded-full inline-block mb-1">
                تدريب تفاعلي عملي
              </span>
              <h2 className="text-xl sm:text-2xl font-black text-slate-900 font-['Alexandria',sans-serif]">
                استمارة طلب خدمة حكومية / تضامن اجتماعي
              </h2>
            </div>

            <button
              onClick={() => {
                audioService.speak(
                  'استمارة الطلب الحكومي: تدرب على كتابة اسمك الرباعي، رقمك القومي المكون من أربعة عشر رقماً، عنوانك، ثم ضع توقيعك الشخصي بالاسم بدلاً من البصمة.'
                );
              }}
              className="flex items-center gap-1.5 text-xs font-bold bg-slate-100 hover:bg-slate-200 text-slate-800 px-3.5 py-2 rounded-xl w-fit"
            >
              <Volume2 className="w-4 h-4 text-emerald-600" />
              <span>استمع لتعليمات ملء الاستمارة</span>
            </button>
          </div>

          {/* Real Egyptian Paperwork Look */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              setFormSubmitted(true);
              audioService.cheerSuccess();
              audioService.speak('عاش يا بطل! تم ملء واعتماد الاستمارة الرسمية بنجاح وببيانات كاملة.');
            }}
            className="p-6 rounded-2xl bg-[#fffefb] border-2 border-slate-300 space-y-5"
          >
            <div className="text-center space-y-1 border-b border-slate-200 pb-4">
              <span className="text-xs font-bold text-slate-500">جمهورية مصر العربية</span>
              <h3 className="text-base font-black text-slate-900">
                طَلَبُ الْحُصُولِ عَلَى خِدْمَةٍ تَمْكِينِيَّةٍ أَوْ مَعَاشِ كَرَامَة
              </h3>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs sm:text-sm">
              <div>
                <label className="font-bold text-slate-700 block mb-1">
                  ١. الاسْمُ الرُّبَاعِيُّ كَمَا بِالْبِطَاقَة:
                </label>
                <input
                  type="text"
                  required
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-300 font-bold bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">
                  ٢. الرَّقَمُ الْقَوْمِيُّ (١٤ رَقَماً):
                </label>
                <input
                  type="text"
                  maxLength={14}
                  required
                  value={formNid}
                  onChange={(e) => setFormNid(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-300 font-mono font-bold bg-white text-left focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="font-bold text-slate-700 block mb-1">
                  ٣. مَحَلُّ الإِقَامَةِ (الْقَرْيَةُ وَالْمَرْكَزُ وَالْمُحَافَظَة):
                </label>
                <input
                  type="text"
                  required
                  value={formAddress}
                  onChange={(e) => setFormAddress(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-300 bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">
                  ٤. الْمِهْنَةُ أَوِ الْعَمَلُ الْحَالِي:
                </label>
                <input
                  type="text"
                  value={formJob}
                  onChange={(e) => setFormJob(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-300 bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">
                  ٥. اعْتِمَادُ التَّوْقِيعِ الشَّخْصِيِّ (الإِمْضَاء):
                </label>
                <div
                  onClick={() => {
                    setFormSigned(!formSigned);
                    audioService.playSound('pop');
                  }}
                  className={`p-2.5 rounded-xl border-2 border-dashed cursor-pointer text-center font-bold transition-all ${
                    formSigned
                      ? 'bg-emerald-50 border-emerald-500 text-emerald-900'
                      : 'bg-slate-50 border-slate-300 text-slate-500 hover:border-emerald-400'
                  }`}
                >
                  {formSigned ? `✍️ ${formName} (توقيع معتمد)` : 'اضغط هنا للتوقيع بالاسم'}
                </div>
              </div>
            </div>

            {formSubmitted ? (
              <div className="p-4 bg-emerald-50 border border-emerald-300 rounded-2xl text-center space-y-1 text-emerald-900 font-bold">
                <CheckCircle2 className="w-6 h-6 text-emerald-600 mx-auto" />
                <span>تم قيد الطلب واعتماد الاستمارة بنجاح! كود المتابعة: #EG-DOC-2026</span>
              </div>
            ) : (
              <button
                type="submit"
                className="w-full py-3.5 bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-700 hover:to-teal-800 text-white rounded-xl text-sm font-black shadow-md transition-all"
              >
                اعتماد وتقديم الاستمارة الحكومية 📄
              </button>
            )}
          </form>
        </div>
      )}

      {/* TAB 4: 30-Day Step-by-Step Learning Journey */}
      {activeTab === 'journey' && (
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-4">
            <div>
              <span className="text-xs font-bold text-amber-800 bg-amber-100 px-3 py-1 rounded-full inline-block mb-1">
                تحدي النور ٣٠ يوماً للكبار
              </span>
              <h2 className="text-xl sm:text-2xl font-black text-slate-900 font-['Alexandria',sans-serif]">
                خطة التعلم الذاتي العملية خطوة بخطوة
              </h2>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-slate-500">تم إنجاز:</span>
              <span className="text-lg font-black font-mono text-emerald-700">
                {completedDays.length} / ٣٠ يوماً
              </span>
              <div className="w-24 h-2.5 bg-slate-200 rounded-full overflow-hidden">
                <div
                  className="h-full bg-emerald-600 transition-all duration-500"
                  style={{ width: `${(completedDays.length / 30) * 100}%` }}
                />
              </div>
            </div>
          </div>

          {/* 4 Structured Weeks */}
          <div className="space-y-6">
            {[
              {
                week: 'الأسبوع الأول (الأيام ١ - ٧): إتقان الأصوات وعائلة الأطباق وتوقيع الاسم',
                days: [
                  { day: 1, title: 'حرف الألف وعمود النور وحركاته' },
                  { day: 2, title: 'عائلة الأطباق: الباء والتاء وفرق النقط' },
                  { day: 3, title: 'الثاء واللسان ودمج أول كلمة (بَاب)' },
                  { day: 4, title: 'تدريب مسكة القلم وكتابة اسمك الأول' },
                  { day: 5, title: 'الجيم والحاء والخاء (عائلة الكروش)' },
                  { day: 6, title: 'أول ٥ أرقام بالجنيه المصري (١ إلى ٥)' },
                  { day: 7, title: 'تحدي نهاية الأسبوع الأول ومراجعة النجوم' },
                ],
              },
              {
                week: 'الأسبوع الثاني (الأيام ٨ - ١٤): حروف المد وقراءة أسماء الأسرة والشارع',
                days: [
                  { day: 8, title: 'الدال والذال والراء والزاي' },
                  { day: 9, title: 'السين والصاد والتفخيم والترقيق' },
                  { day: 10, title: 'الطاء والظاء والعين والغين' },
                  { day: 11, title: 'تكوين كلمات من مقطعين: مَكْـ + ـتَبْ' },
                  { day: 12, title: 'قراءة لافتات محطة المترو والشارع' },
                  { day: 13, title: 'العملات المصرية: الـ ١٠ والـ ٢٠ والـ ٥٠' },
                  { day: 14, title: 'تحدي الأسبوع الثاني واختبار الكلمات' },
                ],
              },
              {
                week: 'الأسبوع الثالث (الأيام ١٥ - ٢١): المعاملات الوظيفية والروشتة والأرقام',
                days: [
                  { day: 15, title: 'الفاء والقاف والكاف واللام' },
                  { day: 16, title: 'الميم والنون والهاء والواو والياء' },
                  { day: 17, title: 'سر اللام الشمسية واليافطة في الشارع' },
                  { day: 18, title: 'قراءة روشتة الدواء ومواعيد الجرعات' },
                  { day: 19, title: 'الـ ١٤ رقماً في بطاقة الرقم القومي' },
                  { day: 20, title: 'حساب باقي السوق وفئات الـ ١٠٠ والـ ٢٠٠' },
                  { day: 21, title: 'تحدي نهاية الأسبوع الثالث التفاعلي' },
                ],
              },
              {
                week: 'الأسبوع الرابع (الأيام ٢٢ - ٣٠): الشمول المالي والـ ATM والامتحان الوطني',
                days: [
                  { day: 22, title: 'بطاقة التموين ونقاط الخبز المدعم' },
                  { day: 23, title: 'كارت عداد الكهرباء الذكي والرصيد' },
                  { day: 24, title: 'محاكي ماكينة الصراف الآلي ATM بالكامل' },
                  { day: 25, title: 'أمان المحافظ الإلكترونية ورسائل الـ OTP' },
                  { day: 26, title: 'قراءة فواتير الكهرباء والمياه والغاز' },
                  { day: 27, title: 'ملء الاستمارة الحكومية الرسمية بالكامل' },
                  { day: 28, title: 'التوقيع القانوني الشخصي بالاسم بدقة' },
                  { day: 29, title: 'خوض الامتحان الوطني المعتمد (GALAE)' },
                  { day: 30, title: 'استلام وطباعة شهادة الإتمام والاحتفال 🎉' },
                ],
              },
            ].map((wk, widx) => (
              <div key={widx} className="p-5 rounded-2xl bg-slate-50/70 border border-slate-200 space-y-3">
                <h3 className="text-sm font-black text-slate-900 flex items-center gap-2">
                  <span className="w-6 h-6 rounded-lg bg-emerald-800 text-white flex items-center justify-center text-xs">
                    {widx + 1}
                  </span>
                  {wk.week}
                </h3>

                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-7 gap-2">
                  {wk.days.map((item) => {
                    const isDone = completedDays.includes(item.day);
                    return (
                      <div
                        key={item.day}
                        onClick={() => toggleDayComplete(item.day)}
                        className={`p-3 rounded-xl border-2 cursor-pointer transition-all flex flex-col justify-between min-h-[90px] ${
                          isDone
                            ? 'bg-emerald-50 border-emerald-500 shadow-xs'
                            : 'bg-white hover:bg-slate-100 border-slate-200'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-black font-mono text-slate-700">
                            اليوم {item.day}
                          </span>
                          {isDone ? (
                            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                          ) : (
                            <div className="w-3.5 h-3.5 rounded-full border border-slate-300" />
                          )}
                        </div>
                        <p className="text-[11px] font-bold text-slate-800 line-clamp-2 mt-1">
                          {item.title}
                        </p>
                      </div>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
