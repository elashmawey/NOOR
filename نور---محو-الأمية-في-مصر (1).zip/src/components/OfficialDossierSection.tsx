import React, { useState } from 'react';
import {
  FileText,
  Award,
  CheckCircle,
  Building2,
  Users,
  Clock,
  Printer,
  Volume2,
  ChevronDown,
  ChevronUp,
  Download,
  ShieldCheck,
  TrendingUp,
  GraduationCap,
  Sparkles,
  Layers,
  MapPin,
  PlusCircle,
  Trash2,
} from 'lucide-react';
import { audioService } from '../utils/audio';

interface StudentRosterItem {
  id: string;
  name: string;
  nationalIdMasked: string;
  village: string;
  attendanceRate: number; // percentage
  readingScore: number; // /40
  mathScore: number; // /30
  writingScore: number; // /30
  status: 'جاهز للامتحان المعتمد' | 'مستوى متوسط' | 'مستوى مبتدئ';
}

const INITIAL_ROSTER: StudentRosterItem[] = [
  {
    id: 'st-01',
    name: 'محمود عبد الرازق حسن',
    nationalIdMasked: '2780514210****',
    village: 'قرية سد خميس - مركز سيدي سالم (كفر الشيخ)',
    attendanceRate: 95,
    readingScore: 38,
    mathScore: 28,
    writingScore: 27,
    status: 'جاهز للامتحان المعتمد',
  },
  {
    id: 'st-02',
    name: 'فاطمة إبراهيم الشناوي',
    nationalIdMasked: '2840922150****',
    village: 'قرية بني منصور - مركز البلينا (سوهاج)',
    attendanceRate: 90,
    readingScore: 36,
    mathScore: 27,
    writingScore: 28,
    status: 'جاهز للامتحان المعتمد',
  },
  {
    id: 'st-03',
    name: 'شعبان إسماعيل مرسي',
    nationalIdMasked: '2691203240****',
    village: 'قرية المعابدة - مركز أبنوب (أسيوط)',
    attendanceRate: 85,
    readingScore: 32,
    mathScore: 25,
    writingScore: 22,
    status: 'جاهز للامتحان المعتمد',
  },
  {
    id: 'st-04',
    name: 'سعاد متولي عبد العاطي',
    nationalIdMasked: '2880311180****',
    village: 'قرية صفط تراب - مركز المحلة (الغربية)',
    attendanceRate: 75,
    readingScore: 28,
    mathScore: 20,
    writingScore: 19,
    status: 'مستوى متوسط',
  },
  {
    id: 'st-05',
    name: 'عاشور عبد التواب علي',
    nationalIdMasked: '2750608260****',
    village: 'قرية إطسا - مركز سمالوط (المنيا)',
    attendanceRate: 92,
    readingScore: 37,
    mathScore: 29,
    writingScore: 26,
    status: 'جاهز للامتحان المعتمد',
  },
];

export const OfficialDossierSection: React.FC = () => {
  const [activeSubTab, setActiveSubTab] = useState<'brief' | 'curriculum' | 'supervisor' | 'kpis'>('brief');
  const [roster, setRoster] = useState<StudentRosterItem[]>(() => {
    try {
      const saved = localStorage.getItem('noor_field_roster');
      return saved ? JSON.parse(saved) : INITIAL_ROSTER;
    } catch {
      return INITIAL_ROSTER;
    }
  });

  const [selectedGovernorate, setSelectedGovernorate] = useState<string>('سوهاج (مراكز حياة كريمة)');
  const [newStudentName, setNewStudentName] = useState<string>('');
  const [newStudentVillage, setNewStudentVillage] = useState<string>('');
  const [isAddingStudent, setIsAddingStudent] = useState<boolean>(false);

  const saveRoster = (newList: StudentRosterItem[]) => {
    setRoster(newList);
    try {
      localStorage.setItem('noor_field_roster', JSON.stringify(newList));
    } catch (e) {
      console.warn('Could not save roster to localStorage', e);
    }
  };

  const handleAddStudent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newStudentName.trim()) return;
    const newItem: StudentRosterItem = {
      id: `st-${Date.now()}`,
      name: newStudentName.trim(),
      nationalIdMasked: '2' + Math.floor(100000000000 + Math.random() * 900000000000).toString().slice(0, 10) + '****',
      village: newStudentVillage.trim() || `مركز حياة كريمة (${selectedGovernorate})`,
      attendanceRate: 100,
      readingScore: 30,
      mathScore: 25,
      writingScore: 25,
      status: 'جاهز للامتحان المعتمد',
    };
    const updated = [newItem, ...roster];
    saveRoster(updated);
    setNewStudentName('');
    setNewStudentVillage('');
    setIsAddingStudent(false);
    audioService.cheerSuccess();
    audioService.speak(`تم قيد الدارس ${newItem.name} في كشف الفصل الميداني بنجاح.`);
  };

  const handleDeleteStudent = (id: string, name: string) => {
    if (confirm(`هل تريد حذف الدارس (${name}) من كشف الفصل؟`)) {
      const updated = roster.filter((s) => s.id !== id);
      saveRoster(updated);
      audioService.speak('تم تحديث كشف الفصل.');
    }
  };

  const printDossier = () => {
    audioService.speak('جاري تحضير ملف الاعتماد الرسمي للطباعة بصيغة كشوف معتمدة.');
    window.print();
  };

  const playDossierAudioBrief = () => {
    audioService.speak(
      'ملف الاعتماد الرسمي لمنصة نور لمحو الأمية. تم تصميم المنصة طبقاً للمعيار الوطني للهيئة العامة لتعليم الكبار ومبادرة فخامة رئيس الجمهورية حياة كريمة. يشمل المنهج ستين ساعة معتمدة مقسمة بين القراءة الصوتية والحساب والمهارات الحياتية والتوقيع القانوني، لتمكين كل مواطن مصري بكرامة واقتدار.'
    );
  };

  return (
    <div className="space-y-8 print:p-0 print:space-y-4">
      {/* Official Government Presentation Header */}
      <div className="bg-gradient-to-r from-slate-900 via-emerald-950 to-slate-900 rounded-3xl p-6 sm:p-8 text-white shadow-xl border border-emerald-500/30 relative overflow-hidden">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 relative z-10">
          <div className="space-y-3 max-w-3xl">
            <div className="flex flex-wrap items-center gap-2">
              <span className="bg-amber-500/20 text-amber-300 font-bold px-3 py-1 rounded-full text-xs border border-amber-400/30 inline-flex items-center gap-1.5">
                <span>🇪🇬</span>
                جمهورية مصر العربية · المبادرة الوطنية لمحو الأمية
              </span>
              <span className="bg-emerald-500/20 text-emerald-300 font-bold px-3 py-1 rounded-full text-xs border border-emerald-400/30">
                جاهز للاعتماد والتشغيل الميداني
              </span>
            </div>

            <h1 className="text-2xl sm:text-4xl font-black font-['Alexandria',sans-serif] tracking-tight leading-tight">
              ملف العرض والاعتماد المؤسسي الرسمي
            </h1>

            <p className="text-emerald-100 text-sm sm:text-base leading-relaxed">
              موجه إلى <strong className="text-amber-300">الهيئة العامة لتعليم الكبار ومحو الأمية (GALAE)</strong>، و
              <strong className="text-amber-300">وزارة التضامن الاجتماعي (مبادرة حياة كريمة)</strong>، و
              <strong className="text-amber-300">وزارة التربية والتعليم والتعليم الفني</strong>.
            </p>
          </div>

          <div className="flex flex-wrap sm:flex-col gap-2.5 shrink-0 print:hidden">
            <button
              onClick={playDossierAudioBrief}
              className="flex items-center justify-center gap-2 px-4 py-2.5 bg-emerald-700 hover:bg-emerald-600 text-white rounded-xl text-xs sm:text-sm font-bold shadow-md transition-all border border-emerald-500"
            >
              <Volume2 className="w-4 h-4 text-emerald-200" />
              <span>استمع للموجز الرسمي</span>
            </button>

            <button
              onClick={printDossier}
              className="flex items-center justify-center gap-2 px-4 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-xl text-xs sm:text-sm font-black shadow-md transition-all"
            >
              <Printer className="w-4 h-4" />
              <span>طباعة الملف التنفيذي (A4)</span>
            </button>
          </div>
        </div>

        {/* 4 Pillars Badge Ribbon */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6 pt-6 border-t border-emerald-800/40 text-xs">
          <div className="flex items-center gap-2 text-emerald-200">
            <Building2 className="w-4 h-4 text-amber-400 shrink-0" />
            <span>مطابق لمعايير GALAE</span>
          </div>
          <div className="flex items-center gap-2 text-emerald-200">
            <Sparkles className="w-4 h-4 text-amber-400 shrink-0" />
            <span>مبادرة حياة كريمة</span>
          </div>
          <div className="flex items-center gap-2 text-emerald-200">
            <Clock className="w-4 h-4 text-amber-400 shrink-0" />
            <span>منهج ٦٠ ساعة معتمد</span>
          </div>
          <div className="flex items-center gap-2 text-emerald-200">
            <ShieldCheck className="w-4 h-4 text-amber-400 shrink-0" />
            <span>استراتيجية مصر ٢٠٣٠</span>
          </div>
        </div>
      </div>

      {/* Dossier Navigation Subtabs */}
      <div className="flex flex-wrap items-center gap-2 border-b border-slate-200 pb-3 print:hidden">
        {[
          { id: 'brief', label: 'الملخص التنفيذي والأهداف', icon: '🏛️' },
          { id: 'curriculum', label: 'مصفوفة منهج الـ ٦٠ ساعة', icon: '📚' },
          { id: 'supervisor', label: 'لوحة المشرف الميداني وفصول المحافظات', icon: '📋' },
          { id: 'kpis', label: 'مؤشرات الأثر والجدوى القومية', icon: '📊' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => {
              setActiveSubTab(tab.id as any);
              audioService.speak(`قسم ${tab.label}`);
            }}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl font-bold text-xs sm:text-sm transition-all ${
              activeSubTab === tab.id
                ? 'bg-emerald-800 text-white shadow-md'
                : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200'
            }`}
          >
            <span>{tab.icon}</span>
            <span>{tab.label}</span>
          </button>
        ))}
      </div>

      {/* Subtab 1: Executive Brief & Strategic Objectives */}
      {activeSubTab === 'brief' && (
        <div className="space-y-6">
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-emerald-100 text-emerald-800 flex items-center justify-center text-2xl font-bold">
                🏛️
              </div>
              <div>
                <h2 className="text-xl sm:text-2xl font-black text-slate-900 font-['Alexandria',sans-serif]">
                  الملخص التنفيذي للمشروع القومي الرقمي
                </h2>
                <p className="text-xs sm:text-sm text-slate-500">
                  إطار العمل المشترك لنشر التعلم الذاتي والصوتي المدعوم بالذكاء الاصطناعي في ربوع مصر
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-5 rounded-2xl bg-amber-50/80 border border-amber-200 space-y-2">
                <span className="text-xs font-bold text-amber-800 uppercase tracking-wide block">
                  ١. مشكلة الاستحياء والحرج الاجتماعي
                </span>
                <h3 className="text-base font-black text-slate-900">التعلم الذاتي بخصوصية تامة</h3>
                <p className="text-xs text-slate-600 leading-relaxed">
                  يمتنع أكثر من ٦٠٪ من الكبار غير المتعلمين عن الذهاب للفصول التقليدية حرجاً من أقرانهم. تتيح منصة نور التعلم عبر الموبايل الشخصي بصوت مصري دافئ في أي وقت.
                </p>
              </div>

              <div className="p-5 rounded-2xl bg-emerald-50/80 border border-emerald-200 space-y-2">
                <span className="text-xs font-bold text-emerald-800 uppercase tracking-wide block">
                  ٢. التحول من التلقين إلى الصوتيات الوظيفية
                </span>
                <h3 className="text-base font-black text-slate-900">طريقة القرائية المصرية</h3>
                <p className="text-xs text-slate-600 leading-relaxed">
                  تعتمد المنصة على التحليل الصوتي للمقاطع، والتمييز البصري بين الحروف المتشابهة (عائلة الأطباق، وس/ص، ود/ض)، وفك لغز اللام الشمسية واللافتات.
                </p>
              </div>

              <div className="p-5 rounded-2xl bg-blue-50/80 border border-blue-200 space-y-2">
                <span className="text-xs font-bold text-blue-800 uppercase tracking-wide block">
                  ٣. الشمول المالي والتمكين الوظيفي
                </span>
                <h3 className="text-base font-black text-slate-900">قراءة الواقع اليومي</h3>
                <p className="text-xs text-slate-600 leading-relaxed">
                  دمج قراءة العملات المصرية الجديدة (البلاستيكية والورقية)، حساب باقي السوق، وفهم رسائل المحافظ الذكية (فودافون كاش وإنستاباي) لقطع الطريق أمام النصب.
                </p>
              </div>
            </div>

            <div className="border-t border-slate-200 pt-6 space-y-4">
              <h3 className="text-base font-extrabold text-slate-900">
                محاور المواءمة المؤسسية مع الجهات الشريكة:
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs sm:text-sm">
                <div className="flex items-start gap-3 p-4 rounded-2xl bg-slate-50 border border-slate-200">
                  <CheckCircle className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                  <div>
                    <strong className="block text-slate-900 font-bold mb-0.5">
                      الهيئة العامة لتعليم الكبار ومحو الأمية (GALAE):
                    </strong>
                    <span className="text-slate-600">
                      تأهيل الدارسين لاجتياز الاختبار النمطي الرسمي بنسبة نجاح متوقعة تتجاوز ٨٨٪، وتسهيل حصر الدارسين بالمراكز والقرى.
                    </span>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-4 rounded-2xl bg-slate-50 border border-slate-200">
                  <CheckCircle className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                  <div>
                    <strong className="block text-slate-900 font-bold mb-0.5">
                      مبادرة فخامة الرئيس "حياة كريمة":
                    </strong>
                    <span className="text-slate-600">
                      نشر التطبيق عبر مراكز تكنولوجيا المعلومات ومجمعات الخدمات الحكومية المنشأة حديثاً بالقرى المصرية الأكثر احتياجاً.
                    </span>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-4 rounded-2xl bg-slate-50 border border-slate-200">
                  <CheckCircle className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                  <div>
                    <strong className="block text-slate-900 font-bold mb-0.5">
                      وزارة التضامن الاجتماعي (برنامج تكافل وكرامة):
                    </strong>
                    <span className="text-slate-600">
                      اشتراط أو تشجيع مستفيدي الدعم النقدي على قراءة رسائل المعاش، واستخدام كارت ميزة، والتوقيع القانوني بالاسم دون بصمة الإبهام.
                    </span>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-4 rounded-2xl bg-slate-50 border border-slate-200">
                  <CheckCircle className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                  <div>
                    <strong className="block text-slate-900 font-bold mb-0.5">
                      المجلس القومي للمرأة:
                    </strong>
                    <span className="text-slate-600">
                      تمكين المرأة المعيلة في الريف والحضر من قراءة روشتات أطفالها، تواريخ الصلاحية، وفهم حقوقها وأرقام الاستغاثة والشكاوى.
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Subtab 2: 60-Hour Certified Curriculum Matrix */}
      {activeSubTab === 'curriculum' && (
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="inline-flex items-center gap-1.5 bg-emerald-100 text-emerald-800 text-xs font-bold px-3 py-1 rounded-full mb-2">
                <Clock className="w-3.5 h-3.5" />
                معتمد وفق الخطة الزمنية للمناهج النوعية للكبار
              </div>
              <h2 className="text-xl sm:text-2xl font-black text-slate-900 font-['Alexandria',sans-serif]">
                مصفوفة الساعات التدريبية (منهج الـ ٦٠ ساعة)
              </h2>
            </div>
            <button
              onClick={() => {
                audioService.speak(
                  'منهج الستين ساعة مقسم إلى أربع وحدات رئيسية: عشرون ساعة للأصوات والقرائية، وخمس عشرة ساعة للحساب الوظيفي، وخمس عشرة ساعة للمهارات الحياتية، وعشر ساعات للإملاء والتوقيع الشخصي والتهيئة للامتحان.'
                );
              }}
              className="flex items-center gap-2 text-xs font-bold bg-slate-100 hover:bg-slate-200 text-slate-700 px-3.5 py-2 rounded-xl w-fit"
            >
              <Volume2 className="w-4 h-4 text-emerald-600" />
              <span>استمع لخطة الساعات</span>
            </button>
          </div>

          <div className="space-y-4">
            {[
              {
                unit: 'الوحدة الأولى: الوعي الصوتي والقراءة التحليلية',
                hours: '٢٠ ساعة تدريبية',
                color: 'emerald',
                topics: [
                  'التعرف على ٢٨ صوتاً هجائياً بحركات الفتح والضم والكسر والسكون.',
                  'التحليل المقطعي الصوتي (تفكيك الكلمة إلى مقاطع ودمجها).',
                  'معمل المتشابهات والتفريق بين عائلة الأطباق (ب/ت/ث/ن/ي) وحروف التفخيم (س/ص، ت/ط، د/ض).',
                  'قاعدة اللام الشمسية والقمرية لقراءة لافتات الشارع وأسماء المحطات.',
                ],
              },
              {
                unit: 'الوحدة الثانية: الحساب الوظيفي والوعي المالي والمصرفي',
                hours: '١٥ ساعة تدريبية',
                color: 'blue',
                topics: [
                  'الأرقام المشرقية والمغربية (من ١ إلى ١٠٠٠).',
                  'فئات العملة المصرية الجديدة (الـ ٥ والـ ١٠ والـ ٢٠ البوليمر، والـ ٥٠ والـ ١٠٠ والـ ٢٠٠).',
                  'معاملات الشراء وحساب الباقي بالسوق لمنع الغش التجاري.',
                  'قراءة عدادات الاستهلاك المنزلية (الكهرباء مسبقة الدفع والمياه والغاز).',
                ],
              },
              {
                unit: 'الوحدة الثالثة: القراءة الوظيفية والحياتية اليومية',
                hours: '١٥ ساعة تدريبية',
                color: 'amber',
                topics: [
                  'يافطات المواصلات العامة (محطات المترو الرئيسية، لافتات الميكروباص).',
                  'تعليمات الصيدلية، علامات أوقات الجرعات وتاريخ انتهاء الصلاحية EXP.',
                  'قراءة بيانات بطاقة الرقم القومي المصرية (تاريخ الميلاد، المحافظة، والباركود).',
                  'بطاقة التموين الذكية وبون صرف الخبز المدعم ورصيد النقاط.',
                  'رسائل الأمان في المحافظ الإلكترونية ومنع مشاركة الرقم السري OTP.',
                ],
              },
              {
                unit: 'الوحدة الرابعة: الإملاء والتوقيع القانوني والتأهيل للاختبار',
                hours: '١٠ ساعات تدريبية',
                color: 'purple',
                topics: [
                  'مسك القلم وتدريب اليد على حركة السطور عبر السبورة التفاعلية.',
                  'كتابة الاسم الرباعي بدون خطأ إملائي.',
                  'تصميم التوقيع الشخصي (الإمضاء) للاستغناء عن بصمة الإبهام في المعاملات الرسمية والبنوك.',
                  'محاكاة الامتحان الوطني المعتمد للهيئة العامة لتعليم الكبار وإصدار الشهادة التجريبية.',
                ],
              },
            ].map((item, idx) => (
              <div
                key={idx}
                className="p-5 rounded-2xl border border-slate-200 bg-slate-50/50 hover:bg-slate-50 transition-colors space-y-3"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div className="flex items-center gap-2.5">
                    <span className="w-8 h-8 rounded-xl bg-slate-900 text-white font-black text-sm flex items-center justify-center">
                      {idx + 1}
                    </span>
                    <h3 className="text-base font-black text-slate-900">{item.unit}</h3>
                  </div>
                  <span className="bg-emerald-100 text-emerald-800 font-extrabold text-xs px-3 py-1 rounded-full border border-emerald-300 w-fit">
                    {item.hours}
                  </span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs sm:text-sm text-slate-600 mr-10">
                  {item.topics.map((topic, tidx) => (
                    <div key={tidx} className="flex items-start gap-2">
                      <span className="text-emerald-600 font-black">•</span>
                      <span>{topic}</span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Subtab 3: Field Supervisor & Governorates Classroom Roster */}
      {activeSubTab === 'supervisor' && (
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-6">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
            <div>
              <div className="inline-flex items-center gap-1.5 bg-blue-100 text-blue-800 text-xs font-bold px-3 py-1 rounded-full mb-2">
                <MapPin className="w-3.5 h-3.5" />
                سجل متابعة فصول المبادرة الميدانية بالقرى والمراكز
              </div>
              <h2 className="text-xl sm:text-2xl font-black text-slate-900 font-['Alexandria',sans-serif]">
                لوحة تحكم المشرف والمعلم الميداني
              </h2>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <select
                value={selectedGovernorate}
                onChange={(e) => {
                  setSelectedGovernorate(e.target.value);
                  audioService.speak(`تم اختيار نطاق ${e.target.value}`);
                }}
                className="px-3.5 py-2 rounded-xl border border-slate-300 text-xs sm:text-sm font-bold bg-white text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
              >
                <option value="سوهاج (مراكز حياة كريمة)">محافظة سوهاج (مراكز حياة كريمة)</option>
                <option value="أسيوط (مراكز أبنوب وساحل سليم)">محافظة أسيوط (مراكز أبنوب وساحل سليم)</option>
                <option value="المنيا (مراكز سمالوط وأبو قرقاص)">محافظة المنيا (سمالوط وأبو قرقاص)</option>
                <option value="البحيرة (مراكز دمنهور وأبو المطامير)">محافظة البحيرة (دمنهور وأبو المطامير)</option>
                <option value="كفر الشيخ (مراكز سيدي سالم ومطوبس)">محافظة كفر الشيخ (مطوبس وسيدي سالم)</option>
                <option value="قنا (مراكز دشنا والوقف)">محافظة قنا (دشنا والوقف)</option>
                <option value="الجيزة (قرى أطفيح والصف)">محافظة الجيزة (قرى أطفيح والصف)</option>
              </select>

              <button
                onClick={() => setIsAddingStudent(!isAddingStudent)}
                className="flex items-center gap-1.5 px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs sm:text-sm font-bold shadow-xs transition-all"
              >
                <PlusCircle className="w-4 h-4" />
                <span>إضافة دارس بالفصل</span>
              </button>

              <button
                onClick={printDossier}
                className="flex items-center gap-1.5 px-3.5 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs sm:text-sm font-bold shadow-xs transition-all"
              >
                <Printer className="w-4 h-4" />
                <span>طباعة كشف الحضور والدرجات</span>
              </button>
            </div>
          </div>

          {/* Quick Roster Stats */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
              <span className="text-xs text-slate-500 font-bold block">إجمالي المقيدين بالفصل</span>
              <span className="text-2xl font-black text-slate-900 mt-1 block">{roster.length} دارساً</span>
            </div>
            <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200">
              <span className="text-xs text-emerald-700 font-bold block">مؤهل للاختبار الرسمي</span>
              <span className="text-2xl font-black text-emerald-800 mt-1 block">
                {roster.filter((s) => s.status === 'جاهز للامتحان المعتمد').length} دارساً
              </span>
            </div>
            <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200">
              <span className="text-xs text-amber-700 font-bold block">متوسط الحضور الفصلي</span>
              <span className="text-2xl font-black text-amber-800 mt-1 block">
                {Math.round(roster.reduce((a, b) => a + b.attendanceRate, 0) / (roster.length || 1))}%
              </span>
            </div>
            <div className="p-4 rounded-2xl bg-blue-50 border border-blue-200">
              <span className="text-xs text-blue-700 font-bold block">الدرجة الكلية المتوقعة</span>
              <span className="text-2xl font-black text-blue-800 mt-1 block">٨٨ / ١٠٠</span>
            </div>
          </div>

          {/* Add Student Inline Form */}
          {isAddingStudent && (
            <form
              onSubmit={handleAddStudent}
              className="p-5 rounded-2xl bg-emerald-50 border border-emerald-300 space-y-4 animate-in fade-in"
            >
              <h3 className="text-sm font-black text-emerald-950 flex items-center gap-2">
                <PlusCircle className="w-4 h-4 text-emerald-600" />
                قيد دارس جديد في كشف الفصل المعتمد
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">
                    الاسم الرباعي للدارس:
                  </label>
                  <input
                    type="text"
                    required
                    value={newStudentName}
                    onChange={(e) => setNewStudentName(e.target.value)}
                    placeholder="مثال: إبراهيم مصطفى علي السيد"
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-xs sm:text-sm bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500 font-bold"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">
                    القرية / النجع / الوحدة المحلية:
                  </label>
                  <input
                    type="text"
                    value={newStudentVillage}
                    onChange={(e) => setNewStudentVillage(e.target.value)}
                    placeholder="مثال: قرية شندويل - مركز المراغة"
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-xs sm:text-sm bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>
              <div className="flex items-center gap-2 justify-end">
                <button
                  type="button"
                  onClick={() => setIsAddingStudent(false)}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-200"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-xs"
                >
                  حفظ وقيد في السجل
                </button>
              </div>
            </form>
          )}

          {/* Roster Table */}
          <div className="overflow-x-auto border border-slate-200 rounded-2xl">
            <table className="w-full text-right text-xs sm:text-sm">
              <thead className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
                <tr>
                  <th className="py-3 px-4">م</th>
                  <th className="py-3 px-4">اسم الدارس الرباعي</th>
                  <th className="py-3 px-4">القرية / المركز</th>
                  <th className="py-3 px-4 text-center">نسبة الحضور</th>
                  <th className="py-3 px-4 text-center">القراءة (/40)</th>
                  <th className="py-3 px-4 text-center">الحساب (/30)</th>
                  <th className="py-3 px-4 text-center">الكتابة (/30)</th>
                  <th className="py-3 px-4 text-center">المجموع (/100)</th>
                  <th className="py-3 px-4 text-center">حالة الدارس</th>
                  <th className="py-3 px-4 text-center print:hidden">إجراء</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {roster.map((st, i) => {
                  const total = st.readingScore + st.mathScore + st.writingScore;
                  return (
                    <tr key={st.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="py-3 px-4 font-mono font-bold text-slate-400">{i + 1}</td>
                      <td className="py-3 px-4">
                        <span className="font-extrabold text-slate-900 block">{st.name}</span>
                        <span className="text-[11px] font-mono text-slate-400">{st.nationalIdMasked}</span>
                      </td>
                      <td className="py-3 px-4 text-slate-600">{st.village}</td>
                      <td className="py-3 px-4 text-center font-bold font-mono">
                        <span className={st.attendanceRate >= 85 ? 'text-emerald-700' : 'text-amber-700'}>
                          {st.attendanceRate}%
                        </span>
                      </td>
                      <td className="py-3 px-4 text-center font-mono font-bold text-slate-700">
                        {st.readingScore}
                      </td>
                      <td className="py-3 px-4 text-center font-mono font-bold text-slate-700">
                        {st.mathScore}
                      </td>
                      <td className="py-3 px-4 text-center font-mono font-bold text-slate-700">
                        {st.writingScore}
                      </td>
                      <td className="py-3 px-4 text-center font-mono font-black text-emerald-800">
                        {total}
                      </td>
                      <td className="py-3 px-4 text-center">
                        <span
                          className={`inline-block px-2.5 py-1 rounded-full text-[11px] font-bold ${
                            st.status === 'جاهز للامتحان المعتمد'
                              ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                              : 'bg-amber-100 text-amber-800 border border-amber-300'
                          }`}
                        >
                          {st.status}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-center print:hidden">
                        <button
                          onClick={() => handleDeleteStudent(st.id, st.name)}
                          className="p-1 text-slate-400 hover:text-rose-600 transition-colors"
                          title="حذف من الكشف"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-500 pt-2 border-t border-slate-100">
            <span>تم التوثيق والاعتماد تحت إشراف لجنة المتابعة الميدانية المشتركة.</span>
            <div className="flex items-center gap-4">
              <span>توقيع المعلم الميداني: ......................</span>
              <span>ختم الإدارة التعليمية: ......................</span>
            </div>
          </div>
        </div>
      )}

      {/* Subtab 4: KPIs & Strategic Impact */}
      {activeSubTab === 'kpis' && (
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-6">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-amber-100 text-amber-800 flex items-center justify-center text-2xl font-bold">
              📊
            </div>
            <div>
              <h2 className="text-xl sm:text-2xl font-black text-slate-900 font-['Alexandria',sans-serif]">
                مؤشرات الأداء والجدوى القومية والتكلفة
              </h2>
              <p className="text-xs sm:text-sm text-slate-500">
                التحليل الكمي والنوعي لعائد الاستثمار في التحول الرقمي لمحو الأمية
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
              <span className="text-3xl font-black text-emerald-700 block">٩٢٪</span>
              <h3 className="text-sm font-black text-slate-900">انخفاض تكلفة الدارس الواحد</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                مقارنة بالطباعة الورقية للكتب وكراسات التمارين؛ التطبيق يعمل على أي هاتف ذكي متاح داخل الأسرة مجاناً وبلا رسوم مستمرة.
              </p>
            </div>

            <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
              <span className="text-3xl font-black text-blue-700 block">١٢ إلى ١٦</span>
              <h3 className="text-sm font-black text-slate-900">أسبوعاً للإتقان الكامل</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                بمعدل ٤ ساعات أسبوعياً مقسمة على جلسات ذاتية، ينتقل الدارس من مرحلة الجهل التام بالحروف إلى القدرة على قراءة وكتابة اسمه والتوقيع.
              </p>
            </div>

            <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
              <span className="text-3xl font-black text-purple-700 block">١٠٠٪</span>
              <h3 className="text-sm font-black text-slate-900">تغطية اللهجة المصرية</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                اعتماد النطق المصري الطبيعي والأمثلة الواقعية المألوفة في الشارع والبيت المصري يزيل أي حاجز لغوي نفسي عند الكبار.
              </p>
            </div>
          </div>

          <div className="p-5 rounded-2xl bg-gradient-to-r from-amber-50 to-orange-50 border border-amber-200 space-y-3">
            <h3 className="text-sm font-black text-amber-950 flex items-center gap-2">
              <Award className="w-4 h-4 text-amber-700" />
              جاهزية العرض والشراكة مع الهيئات الحكومية
            </h3>
            <p className="text-xs sm:text-sm text-slate-700 leading-relaxed">
              تضع منصة نور بنيتها التحتية المفتوحة وقواعد بياناتها تحت تصرف <strong>الهيئة العامة لتعليم الكبار</strong> و<strong>مبادرة حياة كريمة</strong> للربط مع قواعد البيانات القومية وإصدار أرقام جلوس امتحانات حقيقية للدارسين في كافة محافظات مصر.
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
