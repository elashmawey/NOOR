import React, { useState } from 'react';
import { Volume2, Sparkles, Sun, Moon, Check, HelpCircle, ArrowRight } from 'lucide-react';
import { SIMILAR_LETTERS_GROUPS, LAM_RULES, SimilarLetterGroup, LamRuleItem } from '../data/literacyData';
import { audioService } from '../utils/audio';

export const PhonicsLaboratory: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'similar' | 'lam'>('similar');
  const [selectedGroup, setSelectedGroup] = useState<SimilarLetterGroup>(SIMILAR_LETTERS_GROUPS[0]);

  return (
    <div className="space-y-8">
      {/* Banner */}
      <div className="bg-gradient-to-r from-purple-800 via-indigo-900 to-slate-900 rounded-3xl p-6 sm:p-8 text-white shadow-lg relative overflow-hidden">
        <div className="relative z-10 max-w-2xl">
          <div className="inline-flex items-center gap-2 bg-purple-500/40 text-purple-100 font-bold px-3 py-1 rounded-full text-xs sm:text-sm border border-purple-400/40 mb-3">
            <Sparkles className="w-4 h-4 text-purple-200" />
            أسرار القرائية المصرية: ما تتلخبطش تاني أبداً!
          </div>
          <h1 className="text-2xl sm:text-4xl font-black font-['Alexandria',sans-serif] leading-tight mb-2">
            معمل التمييز بين الحروف وقراءة اليافطات
          </h1>
          <p className="text-purple-100 text-sm sm:text-base leading-relaxed">
            هنا هتتعلم أسرار القرائية: إزاي تفرق بين نقط الباء والتاء والنون، وإزاي تقرأ أي يافطة بتبدأ بـ (الـ) في الشارع زي الصاروخ.
          </p>
        </div>
      </div>

      {/* Track Selector */}
      <div className="flex flex-wrap items-center gap-2 border-b border-slate-200 pb-3">
        <button
          onClick={() => {
            setActiveTab('similar');
            audioService.speak('قسم الحروف المتشابهة وحل لغز النقط والمفخم والمرقق');
          }}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl font-bold text-sm transition-all ${
            activeTab === 'similar'
              ? 'bg-purple-700 text-white shadow-md'
              : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200'
          }`}
        >
          <span>🔍</span>
          <span>الحروف المتشابهة ولغز النقط (ب ت ث ن ي)</span>
        </button>

        <button
          onClick={() => {
            setActiveTab('lam');
            audioService.speak('قسم سر قراءة يافطات الشارع، اللام الشمسية واللام القمرية');
          }}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl font-bold text-sm transition-all ${
            activeTab === 'lam'
              ? 'bg-purple-700 text-white shadow-md'
              : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200'
          }`}
        >
          <Sun className="w-4 h-4 text-amber-500" />
          <span>سر قراءة اليافطة: اللام الشمسية والقمرية (الـ)</span>
        </button>
      </div>

      {/* TRACK 1: Similar Letters */}
      {activeTab === 'similar' && (
        <div className="space-y-6">
          {/* Group Selector Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {SIMILAR_LETTERS_GROUPS.map((group) => {
              const isSelected = selectedGroup.id === group.id;
              return (
                <div
                  key={group.id}
                  onClick={() => {
                    setSelectedGroup(group);
                    audioService.playSound('pop');
                    audioService.speak(
                      `${group.title}. القاعدة الذهبية: ${group.goldenRule}`
                    );
                  }}
                  className={`p-4 rounded-2xl border-2 cursor-pointer transition-all ${
                    isSelected
                      ? 'bg-purple-50 border-purple-600 shadow-md scale-105'
                      : 'bg-white hover:bg-slate-50 border-slate-200 hover:border-purple-300'
                  }`}
                >
                  <span className="text-sm font-black text-slate-900 block mb-1">
                    {group.title}
                  </span>
                  <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed">
                    {group.subtitle}
                  </p>
                </div>
              );
            })}
          </div>

          {/* Group Detailed Laboratory Card */}
          <div className="bg-white rounded-3xl p-6 sm:p-8 border-2 border-purple-200 shadow-md space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100">
              <div>
                <span className="text-xs font-bold text-purple-700 bg-purple-50 px-3 py-1 rounded-full border border-purple-200">
                  حل اللغز البصري والصوتي
                </span>
                <h2 className="text-xl sm:text-2xl font-black text-slate-900 mt-2">
                  {selectedGroup.title}
                </h2>
                <p className="text-sm text-slate-600 font-medium mt-0.5">
                  {selectedGroup.whyConfusing}
                </p>
              </div>

              <button
                onClick={() => {
                  audioService.speak(
                    `${selectedGroup.title}. القاعدة الذهبية لحفظها: ${selectedGroup.goldenRule}`
                  );
                }}
                className="flex items-center gap-1.5 px-3.5 py-2 bg-purple-100 hover:bg-purple-200 text-purple-900 font-bold rounded-xl text-xs sm:text-sm border border-purple-300 transition-colors w-fit"
              >
                <Volume2 className="w-4 h-4 text-purple-700" />
                <span>استمع للقاعدة الذهبية</span>
              </button>
            </div>

            {/* Golden Rule Highlight Box */}
            <div className="p-4 bg-gradient-to-r from-amber-50 to-purple-50 border-2 border-amber-300 rounded-2xl flex items-start gap-3">
              <span className="text-2xl">💡</span>
              <div>
                <b className="text-sm font-black text-amber-950 block mb-0.5">القاعدة الذهبية من عم صلاح:</b>
                <p className="text-sm sm:text-base font-extrabold text-purple-950 leading-relaxed">
                  {selectedGroup.goldenRule}
                </p>
              </div>
            </div>

            {/* Letter Cards Comparison */}
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3.5">
              {selectedGroup.letters.map((l, i) => (
                <div
                  key={i}
                  onClick={() => {
                    audioService.playSound('pop');
                    audioService.speak(
                      `حرف ${l.char}. النقط: ${l.dotsDesc}. مثاله: ${l.sampleWord}. ${l.audioHint}`
                    );
                  }}
                  className="p-4 bg-slate-50 hover:bg-purple-50 border-2 border-slate-200 hover:border-purple-400 rounded-2xl text-center cursor-pointer transition-all group select-none"
                >
                  <div className="text-4xl sm:text-5xl font-black font-['Alexandria',sans-serif] text-purple-900 mb-2 group-hover:scale-110 transition-transform">
                    {l.char}
                  </div>
                  <span className="block text-xs font-black text-slate-800 bg-white py-1 px-2 rounded-lg border border-slate-200 mb-1">
                    {l.dotsDesc}
                  </span>
                  <span className="block text-xs text-purple-700 font-bold mb-1">
                    {l.soundTrait}
                  </span>
                  <div className="text-sm font-black text-emerald-800 border-t border-slate-200 pt-1 mt-1">
                    مثال: {l.sampleWord}
                  </div>
                  <div className="mt-2 text-slate-400 group-hover:text-purple-600 flex justify-center">
                    <Volume2 className="w-4 h-4" />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TRACK 2: Sun and Moon Lam (اللام الشمسية واللام القمرية) */}
      {activeTab === 'lam' && (
        <div className="space-y-6">
          <div className="bg-white p-5 rounded-3xl border border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div>
              <h2 className="text-xl sm:text-2xl font-black text-slate-900">
                سر قراءة يافطات المحلات والمحطات في مصر
              </h2>
              <p className="text-sm text-slate-600 mt-1">
                معظم اليافطات بتبدأ بألف ولام (الـ). فيه لام بتتنطق واضحة (قمرية)، وفيه لام بتستخبى في النطق (شمسية).
              </p>
            </div>
            <button
              onClick={() => {
                audioService.speak(
                  'سر قراءة اليافطات في مصر: لو اللام قمرية زي كلمة المترو، انطق اللام واضحة: اَلْـمِتْرُو. ولو اللام شمسية زي التحرير والشارع، اوعى تنطق اللام! انطق إتْـتحرير وإشْـشارع على طول!'
                );
              }}
              className="flex items-center gap-1.5 px-3.5 py-2 bg-amber-100 hover:bg-amber-200 text-amber-900 font-bold rounded-xl text-xs sm:text-sm border border-amber-300 shrink-0"
            >
              <Volume2 className="w-4 h-4 text-amber-700" />
              <span>استمع لسر اليافطة</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {LAM_RULES.map((rule) => {
              const isShams = rule.type === 'shamsiya';
              return (
                <div
                  key={rule.type}
                  className={`rounded-3xl p-6 sm:p-7 border-2 space-y-5 ${
                    isShams
                      ? 'bg-amber-50/70 border-amber-300'
                      : 'bg-blue-50/70 border-blue-300'
                  }`}
                >
                  <div className="flex items-center justify-between pb-3 border-b border-black/10">
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-12 h-12 rounded-2xl flex items-center justify-center text-2xl shadow-xs ${
                          isShams ? 'bg-amber-500 text-white' : 'bg-blue-600 text-white'
                        }`}
                      >
                        {isShams ? <Sun className="w-6 h-6" /> : <Moon className="w-6 h-6" />}
                      </div>
                      <div>
                        <h3 className="text-xl font-black text-slate-900">{rule.nameAr}</h3>
                        <span className="text-xs font-bold text-slate-600">{rule.title}</span>
                      </div>
                    </div>

                    <button
                      onClick={() => {
                        audioService.speak(
                          `${rule.title}. القاعدة: ${rule.ruleExplanation}. سر النطق: ${rule.readingSecret}`
                        );
                      }}
                      className="p-2 bg-white rounded-xl shadow-xs text-slate-700 hover:text-slate-950"
                      title="استمع للشرح"
                    >
                      <Volume2 className="w-5 h-5" />
                    </button>
                  </div>

                  <div className="space-y-2 text-sm">
                    <p className="font-extrabold text-slate-900">{rule.ruleExplanation}</p>
                    <div className="p-3 bg-white/90 rounded-2xl border border-black/10 font-bold text-slate-800">
                      <span className="text-xs text-purple-700 block mb-0.5">سر النطق الصحيح:</span>
                      {rule.readingSecret}
                    </div>
                  </div>

                  {/* Real Egyptian Signs Example Cards */}
                  <div className="space-y-2">
                    <span className="text-xs font-bold text-slate-600 block">
                      يافطات حقيقية في شوارع مصر:
                    </span>
                    <div className="grid grid-cols-2 gap-2">
                      {rule.signsInEgypt.map((sign, i) => (
                        <div
                          key={i}
                          onClick={() => {
                            audioService.playSound('pop');
                            audioService.speak(
                              `يافطة: ${sign.text}. وتتنطق بالصوت: ${sign.phoneticSpelling}. معناها: ${sign.meaning}`
                            );
                          }}
                          className="p-3 bg-white rounded-2xl border border-slate-200 hover:border-slate-400 cursor-pointer transition-all shadow-xs group"
                        >
                          <div className="flex items-center justify-between mb-1">
                            <span className="text-lg">{sign.emoji}</span>
                            <Volume2 className="w-3.5 h-3.5 text-slate-400 group-hover:text-amber-600" />
                          </div>
                          <span className="text-base font-black text-slate-900 block font-['Alexandria',sans-serif]">
                            {sign.text}
                          </span>
                          <span className="text-[11px] font-bold text-emerald-700 block mt-0.5">
                            {sign.phoneticSpelling}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
