import React, { useState } from 'react';
import { Volume2, Sparkles, AlertTriangle, ShieldCheck, HelpCircle, Check, ArrowRight } from 'lucide-react';
import { EGYPTIAN_LIFE_SCENARIOS, LifeScenario } from '../data/literacyData';
import { audioService } from '../utils/audio';

export const LifeSituationsSection: React.FC = () => {
  const [selectedScenario, setSelectedScenario] = useState<LifeScenario>(EGYPTIAN_LIFE_SCENARIOS[0]);
  const [activeCategoryFilter, setActiveCategoryFilter] = useState<string>('all');
  const [interactiveQuizOpen, setInteractiveQuizOpen] = useState<boolean>(false);
  const [quizAnswered, setQuizAnswered] = useState<boolean>(false);

  const filteredScenarios = EGYPTIAN_LIFE_SCENARIOS.filter((s) => {
    if (activeCategoryFilter === 'all') return true;
    return s.category === activeCategoryFilter;
  });

  const handleSelectScenario = (scenario: LifeScenario) => {
    setSelectedScenario(scenario);
    setInteractiveQuizOpen(false);
    setQuizAnswered(false);
    audioService.playSound('pop');
    audioService.speak(
      `موقف: ${scenario.title}. النص المكتوب: ${scenario.signText}. ${scenario.explanation}`
    );
  };

  return (
    <div className="space-y-8">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-blue-800 via-indigo-900 to-slate-900 rounded-3xl p-6 sm:p-8 text-white shadow-lg relative overflow-hidden">
        <div className="relative z-10 max-w-2xl">
          <div className="inline-flex items-center gap-2 bg-blue-500/40 text-blue-100 font-bold px-3 py-1 rounded-full text-xs sm:text-sm border border-blue-400/40 mb-3">
            <Sparkles className="w-4 h-4 text-blue-200" />
            المستوى الرابع: مواقف الحياة والشارع والخدمات في مصر
          </div>
          <h1 className="text-2xl sm:text-4xl font-black font-['Alexandria',sans-serif] leading-tight mb-2">
            قراءة لافتات الشارع، المواصلات والدواء
          </h1>
          <p className="text-blue-100 text-sm sm:text-base leading-relaxed">
            محو الأمية الحقيقي هو أن تقرأ يافطة الميكروباص بنفسك، تفهم جرعة دواء الصيدلية، وتعرف بيانات بطاقتك ورسائل تحويل الفلوس بأمان.
          </p>
        </div>
      </div>

      {/* Category Filter Buttons */}
      <div className="flex flex-wrap items-center gap-2 border-b border-slate-200 pb-3">
        {[
          { id: 'all', label: 'كل المواقف', icon: '🌟' },
          { id: 'transport', label: 'المواصلات والمترو', icon: '🚇' },
          { id: 'pharmacy', label: 'الدواء والصيدلية', icon: '💊' },
          { id: 'official', label: 'البطاقة والتموين والكهرباء', icon: '🏛️' },
          { id: 'digital', label: 'الموبايل وفودافون كاش', icon: '📱' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => {
              setActiveCategoryFilter(tab.id);
              audioService.speak(`قسم ${tab.label}`);
            }}
            className={`flex items-center gap-1.5 px-3.5 py-2 rounded-2xl font-bold text-xs sm:text-sm transition-all ${
              activeCategoryFilter === tab.id
                ? 'bg-blue-700 text-white shadow-md'
                : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200'
            }`}
          >
            <span>{tab.icon}</span>
            <span>{tab.label}</span>
          </button>
        ))}
      </div>

      {/* Scenarios Grid & Detail Showcase */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Scenarios List (Cols 1-5) */}
        <div className="lg:col-span-5 space-y-3">
          <h2 className="text-base font-extrabold text-slate-800">اختر الموقف للتعرف عليه:</h2>
          <div className="space-y-2.5">
            {filteredScenarios.map((sc) => {
              const isSelected = selectedScenario.id === sc.id;
              return (
                <div
                  key={sc.id}
                  onClick={() => handleSelectScenario(sc)}
                  className={`p-4 rounded-2xl border-2 cursor-pointer transition-all flex items-start gap-3.5 ${
                    isSelected
                      ? 'bg-blue-50 border-blue-600 shadow-md scale-[1.02]'
                      : 'bg-white hover:bg-slate-50 border-slate-200 hover:border-blue-300'
                  }`}
                >
                  <div className="text-3xl p-2.5 bg-slate-100 rounded-2xl shrink-0">{sc.icon}</div>
                  <div className="flex-1 min-w-0">
                    <span className="text-base font-black text-slate-900 block truncate">
                      {sc.titleAr}
                    </span>
                    <p className="text-xs text-slate-500 font-medium line-clamp-1 mt-0.5">
                      {sc.signText}
                    </p>
                  </div>
                  <Volume2
                    onClick={(e) => {
                      e.stopPropagation();
                      audioService.speak(sc.voiceGuide);
                    }}
                    className="w-5 h-5 text-blue-600 shrink-0 mt-1 hover:scale-110 transition-transform"
                  />
                </div>
              );
            })}
          </div>
        </div>

        {/* Detailed Scenario Workbench (Cols 6-12) */}
        <div className="lg:col-span-7 bg-white rounded-3xl p-6 sm:p-8 border border-blue-200 shadow-md space-y-6">
          {/* Header */}
          <div className="flex items-center justify-between pb-4 border-b border-slate-100">
            <div className="flex items-center gap-3">
              <span className="text-4xl">{selectedScenario.icon}</span>
              <div>
                <h3 className="text-xl sm:text-2xl font-black text-slate-900">
                  {selectedScenario.title}
                </h3>
                <span className="text-xs font-bold text-blue-600">
                  موقف واقعي متكرر في مصر
                </span>
              </div>
            </div>

            <button
              onClick={() => audioService.speak(selectedScenario.voiceGuide)}
              className="p-3 bg-blue-100 hover:bg-blue-200 text-blue-900 rounded-2xl transition-colors border border-blue-300"
              title="استمع للشرح الصوتي"
            >
              <Volume2 className="w-5 h-5" />
            </button>
          </div>

          {/* Realistic Egyptian Sign Mockup */}
          <div className="space-y-2">
            <span className="text-xs font-bold text-slate-500 block">
              شكل اليافطة أو الرسالة كما تراها في الواقع:
            </span>
            <div className="bg-slate-950 text-white rounded-2xl p-6 border-4 border-amber-400 shadow-inner relative overflow-hidden text-center space-y-2">
              <div className="text-2xl sm:text-3xl font-black font-['Alexandria',sans-serif] text-amber-300 tracking-wide leading-relaxed">
                {selectedScenario.signText}
              </div>
              {selectedScenario.signSubtext && (
                <div className="text-xs sm:text-sm text-slate-300 font-semibold border-t border-white/20 pt-2">
                  {selectedScenario.signSubtext}
                </div>
              )}
            </div>
          </div>

          {/* Key Vocabulary Pills */}
          <div className="space-y-2.5">
            <h4 className="text-sm font-bold text-slate-800">الكلمات المفتاحية وكيف تقرأها:</h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              {selectedScenario.keyWords.map((kw, i) => (
                <div
                  key={i}
                  onClick={() => {
                    audioService.playSound('pop');
                    audioService.speak(`${kw.word}. معناها: ${kw.meaning}`);
                  }}
                  className="p-3 bg-slate-50 hover:bg-blue-50 border border-slate-200 hover:border-blue-300 rounded-xl cursor-pointer transition-colors"
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-base font-extrabold text-blue-900">{kw.word}</span>
                    <Volume2 className="w-3.5 h-3.5 text-blue-600" />
                  </div>
                  <span className="text-xs text-slate-500 font-medium leading-tight block">
                    {kw.meaning}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Explanation in Egyptian Colloquial Context */}
          <div className="bg-blue-50/70 p-4 rounded-2xl border border-blue-200 space-y-1.5">
            <span className="text-xs font-bold text-blue-900 block">الشرح والتوضيح:</span>
            <p className="text-sm sm:text-base text-slate-800 leading-relaxed font-medium">
              {selectedScenario.explanation}
            </p>
          </div>

          {/* Safety & Practical Tip */}
          <div className="p-4 bg-amber-50 border border-amber-300 rounded-2xl flex items-start gap-3 text-amber-950">
            <ShieldCheck className="w-6 h-6 text-amber-700 shrink-0 mt-0.5" />
            <div>
              <b className="text-sm font-black block text-amber-900 mb-0.5">نصيحة أمان مهمة:</b>
              <p className="text-xs sm:text-sm text-amber-900/90 leading-relaxed font-medium">
                {selectedScenario.safetyTip}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
