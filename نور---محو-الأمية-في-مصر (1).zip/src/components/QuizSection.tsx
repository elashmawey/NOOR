import React, { useState } from 'react';
import { Volume2, Award, CheckCircle2, XCircle, Sparkles, RefreshCw, ArrowLeft } from 'lucide-react';
import confetti from 'canvas-confetti';
import { QUIZ_BANK, QuizQuestion } from '../data/literacyData';
import { audioService } from '../utils/audio';

interface QuizSectionProps {
  onOpenCertificate: () => void;
}

export const QuizSection: React.FC<QuizSectionProps> = ({ onOpenCertificate }) => {
  const [currentIdx, setCurrentIdx] = useState<number>(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [showExplanation, setShowExplanation] = useState<boolean>(false);
  const [score, setScore] = useState<number>(0);
  const [quizFinished, setQuizFinished] = useState<boolean>(false);
  const [isGeneratingAiQuiz, setIsGeneratingAiQuiz] = useState<boolean>(false);

  const question: QuizQuestion = QUIZ_BANK[currentIdx];

  const handleOptionSelect = (idx: number) => {
    if (showExplanation) return; // Already answered

    setSelectedOption(idx);
    setShowExplanation(true);

    if (idx === question.correctIndex) {
      setScore((s) => s + 1);
      audioService.playSound('celebrate');
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.7 },
      });
      audioService.speak(`الله ينور عليك يا بطل! إجابة صحيحة. ${question.explanation}`);
    } else {
      audioService.playSound('wrong');
      audioService.speak(`قربت، الإجابة الصح هي: ${question.options[question.correctIndex]}. ${question.explanation}`);
    }
  };

  const handleNext = () => {
    if (currentIdx + 1 < QUIZ_BANK.length) {
      setCurrentIdx((c) => c + 1);
      setSelectedOption(null);
      setShowExplanation(false);
      const nextQ = QUIZ_BANK[currentIdx + 1];
      audioService.playSound('pop');
      audioService.speak(`السؤال التالي: ${nextQ.audioPrompt}`);
    } else {
      setQuizFinished(true);
      audioService.playSound('celebrate');
      confetti({
        particleCount: 120,
        spread: 100,
        origin: { y: 0.6 },
      });
      audioService.speak(
        `ألف مبروك! أنهيت الاختبار وحققت ${score + (selectedOption === question.correctIndex ? 1 : 0)} من ${QUIZ_BANK.length}. تستاهل شهادة التقدير والتخرج لمحو الأمية!`
      );
    }
  };

  const restartQuiz = () => {
    setCurrentIdx(0);
    setSelectedOption(null);
    setShowExplanation(false);
    setScore(0);
    setQuizFinished(false);
    audioService.speak('بدأنا الاختبار من جديد. ركز يا بطل وبالتوفيق!');
  };

  return (
    <div className="space-y-8">
      {/* Banner */}
      <div className="bg-gradient-to-r from-amber-600 via-orange-600 to-amber-700 rounded-3xl p-6 sm:p-8 text-white shadow-lg relative overflow-hidden">
        <div className="relative z-10 max-w-2xl">
          <div className="inline-flex items-center gap-2 bg-amber-500/40 text-amber-100 font-bold px-3 py-1 rounded-full text-xs sm:text-sm border border-amber-400/40 mb-3">
            <Sparkles className="w-4 h-4 text-amber-200" />
            تحدي المعرفة وقياس المستوى
          </div>
          <h1 className="text-2xl sm:text-4xl font-black font-['Alexandria',sans-serif] leading-tight mb-2">
            اختبر مهاراتك في القراءة والحياة
          </h1>
          <p className="text-amber-100 text-sm sm:text-base leading-relaxed">
            أسئلة سهلة ومسلية من واقع الشارع والمواقف اليومية عشان تقيس تقدمك وتحصل على شهادة التقدير.
          </p>
        </div>
      </div>

      {/* Quiz Card */}
      {!quizFinished ? (
        <div className="bg-white rounded-3xl p-6 sm:p-8 border-2 border-amber-300 shadow-md space-y-6">
          {/* Progress Header */}
          <div className="flex items-center justify-between pb-4 border-b border-slate-100">
            <div className="flex items-center gap-3">
              <span className="text-xs font-bold bg-amber-100 text-amber-900 px-3 py-1.5 rounded-xl border border-amber-300">
                السؤال {currentIdx + 1} من {QUIZ_BANK.length}
              </span>
              <span className="text-xs font-bold text-slate-500">
                المجال: {question.badge}
              </span>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-amber-800 bg-amber-50 px-3 py-1 rounded-lg">
                النقاط: {score} ⭐
              </span>
              <button
                onClick={() => audioService.speak(question.audioPrompt)}
                className="p-2.5 bg-amber-100 hover:bg-amber-200 text-amber-900 rounded-xl transition-colors"
                title="استمع للسؤال بصوت عالي"
              >
                <Volume2 className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Question Text */}
          <div className="space-y-2">
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 leading-snug">
              {question.question}
            </h2>
            <p className="text-xs text-slate-500 font-semibold">
              اضغط على الإجابة الصحيحة أو اضغط على السماعة لسماع الخيارات
            </p>
          </div>

          {/* Options Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            {question.options.map((opt, i) => {
              const isSelected = selectedOption === i;
              const isCorrect = i === question.correctIndex;

              let style = 'bg-slate-50 border-slate-200 hover:bg-amber-50/70 hover:border-amber-300 text-slate-800';

              if (showExplanation) {
                if (isCorrect) {
                  style = 'bg-emerald-50 border-emerald-500 text-emerald-950 font-bold';
                } else if (isSelected) {
                  style = 'bg-rose-50 border-rose-400 text-rose-950 font-bold';
                } else {
                  style = 'bg-slate-50 border-slate-200 text-slate-400 opacity-60';
                }
              }

              return (
                <button
                  key={i}
                  disabled={showExplanation}
                  onClick={() => handleOptionSelect(i)}
                  className={`p-4 rounded-2xl border-2 text-right transition-all flex items-center justify-between gap-3 text-base sm:text-lg font-extrabold ${style}`}
                >
                  <div className="flex items-center gap-3">
                    <span className="w-8 h-8 rounded-xl bg-black/5 flex items-center justify-center text-xs font-bold">
                      {i + 1}
                    </span>
                    <span>{opt}</span>
                  </div>

                  {showExplanation && (
                    <div>
                      {isCorrect && <CheckCircle2 className="w-6 h-6 text-emerald-600" />}
                      {isSelected && !isCorrect && <XCircle className="w-6 h-6 text-rose-600" />}
                    </div>
                  )}
                </button>
              );
            })}
          </div>

          {/* Explanation Box */}
          {showExplanation && (
            <div className="p-5 bg-amber-50/80 border border-amber-300 rounded-2xl space-y-3 animate-in fade-in duration-200">
              <div className="flex items-center justify-between">
                <span className="text-xs font-extrabold text-amber-900 block">
                  💡 توضيح الإجابة الصحيحة:
                </span>
                <button
                  onClick={() => audioService.speak(question.explanation)}
                  className="text-amber-800 hover:text-amber-950 p-1"
                >
                  <Volume2 className="w-4 h-4" />
                </button>
              </div>
              <p className="text-sm sm:text-base font-semibold text-slate-800 leading-relaxed">
                {question.explanation}
              </p>
              <button
                onClick={handleNext}
                className="w-full py-3.5 bg-amber-600 hover:bg-amber-700 text-white font-extrabold text-base rounded-2xl shadow-md transition-all flex items-center justify-center gap-2 mt-2"
              >
                <span>{currentIdx + 1 < QUIZ_BANK.length ? 'السؤال التالي' : 'عرض النتيجة النهائية'}</span>
                <ArrowLeft className="w-5 h-5" />
              </button>
            </div>
          )}
        </div>
      ) : (
        /* Quiz Finished View */
        <div className="bg-white rounded-3xl p-8 sm:p-12 border-2 border-emerald-400 shadow-xl text-center space-y-6 max-w-xl mx-auto">
          <div className="w-24 h-24 mx-auto rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center text-5xl shadow-inner">
            🏆
          </div>

          <div className="space-y-2">
            <h2 className="text-3xl sm:text-4xl font-black text-slate-900 font-['Alexandria',sans-serif]">
              ألف مبروك يا بطل!
            </h2>
            <p className="text-base text-slate-600 font-medium">
              أتممت اختبار محو الأمية وحققت{' '}
              <b className="text-emerald-700 text-xl font-black">{score}</b> من{' '}
              <b className="text-slate-800 text-xl font-black">{QUIZ_BANK.length}</b> إجابات صحيحة.
            </p>
          </div>

          <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl text-emerald-950 text-sm font-semibold">
            خطوتك في تعلم القراءة والكتابة خطوة عظيمة ترفع الرأس. تقدر دلوقتي تستلم شهادة التقدير باسمك وتشاركها مع عائلتك وأولادك!
          </div>

          <div className="flex flex-col sm:flex-row gap-3 pt-2">
            <button
              onClick={onOpenCertificate}
              className="flex-1 py-4 bg-emerald-600 hover:bg-emerald-700 text-white font-black rounded-2xl shadow-md flex items-center justify-center gap-2 text-base transition-all"
            >
              <Award className="w-5 h-5 text-amber-300" />
              <span>استلام شهادة التقدير</span>
            </button>

            <button
              onClick={restartQuiz}
              className="py-4 px-6 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-2xl border border-slate-300 flex items-center justify-center gap-2 text-sm transition-all"
            >
              <RefreshCw className="w-4 h-4" />
              <span>إعادة الاختبار</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
