import React, { useState } from 'react';
import { Volume2, Sparkles, Check, RefreshCw, HelpCircle, BookOpen, ArrowLeft } from 'lucide-react';
import { WORD_BUILDING_LIST, WordBuildingCard } from '../data/literacyData';
import { audioService } from '../utils/audio';

export const WordsSection: React.FC = () => {
  const [activeCardIndex, setActiveCardIndex] = useState<number>(0);
  const [userLetters, setUserLetters] = useState<string[]>([]);
  const [isSuccess, setIsSuccess] = useState<boolean>(false);
  const [customWordInput, setCustomWordInput] = useState<string>('');
  const [analyzingWord, setAnalyzingWord] = useState<boolean>(false);
  const [aiExplanation, setAiExplanation] = useState<any>(null);

  const currentCard: WordBuildingCard = WORD_BUILDING_LIST[activeCardIndex];

  // Scrambled letters for the current card
  const availableLetters = React.useMemo(() => {
    return [...currentCard.letters].sort(() => Math.random() - 0.5);
  }, [currentCard]);

  const handleLetterClick = (letter: string) => {
    audioService.playSound('click');
    audioService.speak(letter);

    const next = [...userLetters, letter];
    setUserLetters(next);

    // Check if correct
    if (next.length === currentCard.letters.length) {
      if (next.join('') === currentCard.letters.join('')) {
        setIsSuccess(true);
        audioService.playSound('celebrate');
        audioService.speak(`الله ينور عليك! كونت كلمة ${currentCard.word}. ${currentCard.sentence}`);
      } else {
        audioService.playSound('wrong');
        audioService.speak('قربت يا بطل، جرب ترتب الحروف مرة تانية.');
      }
    }
  };

  const resetGame = () => {
    setUserLetters([]);
    setIsSuccess(false);
  };

  const nextCard = () => {
    const nextIdx = (activeCardIndex + 1) % WORD_BUILDING_LIST.length;
    setActiveCardIndex(nextIdx);
    setUserLetters([]);
    setIsSuccess(false);
  };

  const handleAnalyzeWord = async () => {
    if (!customWordInput.trim()) return;
    setAnalyzingWord(true);
    setAiExplanation(null);
    audioService.speak(`جاري تحليل كلمة ${customWordInput}...`);

    try {
      const res = await fetch('/api/gemini/explain-word', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ word: customWordInput.trim() }),
      });
      const data = await res.json();
      setAiExplanation(data);
      audioService.playSound('correct');
      audioService.speak(
        `كلمة ${data.word}. تتهجى: ${data.spelling}. معناها: ${data.meaning}. ${data.example}`
      );
    } catch (e) {
      console.error(e);
    } finally {
      setAnalyzingWord(false);
    }
  };

  return (
    <div className="space-y-8">
      {/* Banner */}
      <div className="bg-gradient-to-r from-teal-700 via-teal-800 to-emerald-900 rounded-3xl p-6 sm:p-8 text-white shadow-lg relative overflow-hidden">
        <div className="relative z-10 max-w-2xl">
          <div className="inline-flex items-center gap-2 bg-teal-500/40 text-teal-100 font-bold px-3 py-1 rounded-full text-xs sm:text-sm border border-teal-400/40 mb-3">
            <Sparkles className="w-4 h-4 text-teal-200" />
            المستوى الثاني: تكوين الكلمات وقراءة الجمل
          </div>
          <h1 className="text-2xl sm:text-4xl font-black font-['Alexandria',sans-serif] leading-tight mb-2">
            من الحروف إلى الكلمات والجمل
          </h1>
          <p className="text-teal-100 text-sm sm:text-base leading-relaxed">
            الحروف لما تتجمع مع بعض بتبني كلمة، والكلمات بتبني جملة. درب عينك وودنك على قراءة الكلمات خطوة بخطوة.
          </p>
        </div>
      </div>

      {/* Main Assembly Game */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-teal-200 shadow-md space-y-8">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div>
            <span className="text-xs font-bold text-teal-700 bg-teal-50 px-3 py-1 rounded-full border border-teal-200">
              تدريب رقم {activeCardIndex + 1} من {WORD_BUILDING_LIST.length}
            </span>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 mt-2">
              لعبة تجميع حروف الكلمة
            </h2>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                audioService.speak(
                  `المطلوب تكوين كلمة ${currentCard.word}. معناها ${currentCard.meaning}. اضغط على الحروف بالترتيب الصحيح.`
                );
              }}
              className="flex items-center gap-1.5 px-3 py-2 bg-teal-50 hover:bg-teal-100 text-teal-800 font-bold rounded-xl text-xs sm:text-sm border border-teal-200 transition-colors"
            >
              <Volume2 className="w-4 h-4 text-teal-600" />
              <span>استمع للمطلوب</span>
            </button>
            <button
              onClick={resetGame}
              className="p-2 text-slate-500 hover:text-slate-800 bg-slate-100 rounded-xl transition-colors"
              title="إعادة الترتيب"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Central Card with Target Image & Word Box */}
        <div className="max-w-xl mx-auto text-center space-y-6">
          <div className="w-24 h-24 sm:w-28 sm:h-28 mx-auto rounded-3xl bg-amber-50 border-2 border-amber-200 flex items-center justify-center text-5xl sm:text-6xl shadow-inner">
            {currentCard.emoji}
          </div>

          <div>
            <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-800">
              {currentCard.meaning}
            </h3>
            <p className="text-sm text-slate-500 mt-1">اضغط على الحروف بالترتيب من اليمين للشمال</p>

            {/* Syllables Exploration Pill Bar */}
            {currentCard.syllables && (
              <div className="mt-3 flex items-center justify-center gap-2">
                <span className="text-xs font-bold text-slate-400">اسمع مقاطع الكلمة:</span>
                {currentCard.syllables.map((syl, i) => (
                  <button
                    key={i}
                    onClick={() => {
                      audioService.playSound('pop');
                      audioService.speak(`مقطع: ${syl}`);
                    }}
                    className="px-3 py-1 bg-teal-50 hover:bg-teal-100 text-teal-800 font-black text-sm rounded-xl border border-teal-200 transition-colors flex items-center gap-1"
                    title="اضغط لسماع نطق المقطع"
                  >
                    <span>{syl}</span>
                    <Volume2 className="w-3.5 h-3.5 text-teal-600" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* User Word Assembly Slot */}
          <div className="flex items-center justify-center gap-3 py-4">
            {currentCard.letters.map((_, idx) => {
              const entered = userLetters[idx];
              return (
                <div
                  key={idx}
                  className={`w-14 h-16 sm:w-18 sm:h-20 rounded-2xl border-2 flex items-center justify-center text-3xl sm:text-4xl font-black font-['Alexandria',sans-serif] transition-all ${
                    entered
                      ? isSuccess
                        ? 'bg-emerald-500 text-white border-emerald-600 scale-105'
                        : 'bg-teal-50 text-teal-900 border-teal-400'
                      : 'bg-slate-50 border-dashed border-slate-300 text-slate-400'
                  }`}
                >
                  {entered || '؟'}
                </div>
              );
            })}
          </div>

          {/* Available Letter Tiles to Tap */}
          {!isSuccess && (
            <div className="space-y-3">
              <span className="text-xs font-bold text-slate-500">اختر الحرف التالي:</span>
              <div className="flex flex-wrap items-center justify-center gap-3">
                {availableLetters.map((l, i) => (
                  <button
                    key={i}
                    onClick={() => handleLetterClick(l)}
                    className="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl bg-amber-100 hover:bg-amber-200 text-amber-950 font-black text-2xl sm:text-3xl border-2 border-amber-300 shadow-sm hover:scale-105 active:scale-95 transition-all font-['Alexandria',sans-serif]"
                  >
                    {l}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Success Reveal & Sentence */}
          {isSuccess && (
            <div className="p-6 bg-emerald-50 border-2 border-emerald-300 rounded-3xl space-y-4 animate-in fade-in zoom-in duration-300">
              <div className="inline-flex items-center gap-2 text-emerald-800 font-extrabold text-base">
                <Check className="w-5 h-5 text-emerald-600" />
                <span>ممتاز جداً! قرأت كلمة:</span>
              </div>

              <div className="text-4xl sm:text-5xl font-black text-emerald-950 font-['Alexandria',sans-serif]">
                {currentCard.word}
              </div>

              <div className="p-3 bg-white rounded-2xl border border-emerald-200 flex items-center justify-between">
                <p className="text-base sm:text-lg font-bold text-slate-800 text-right">
                  {currentCard.sentence}
                </p>
                <button
                  onClick={() => audioService.speak(currentCard.sentence)}
                  className="p-2 bg-emerald-100 text-emerald-900 rounded-xl hover:bg-emerald-200 transition-colors"
                  title="استمع للجملة"
                >
                  <Volume2 className="w-5 h-5" />
                </button>
              </div>

              <button
                onClick={nextCard}
                className="w-full py-3.5 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-base rounded-2xl shadow-md transition-all flex items-center justify-center gap-2"
              >
                <span>الكلمة التالية</span>
                <ArrowLeft className="w-5 h-5" />
              </button>
            </div>
          )}
        </div>
      </div>

      {/* AI Word Breakdown Studio - "حلل أي كلمة تحبها" */}
      <div className="bg-slate-900 text-white rounded-3xl p-6 sm:p-8 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="inline-flex items-center gap-2 text-amber-400 font-bold text-xs uppercase tracking-wider mb-1">
              <Sparkles className="w-4 h-4" />
              معمل عم صلاح الذكي
            </div>
            <h2 className="text-xl sm:text-2xl font-black">
              اكتب أو اختر أي كلمة مصرية لنفككها ونشرحها بالصوت
            </h2>
          </div>

          <button
            onClick={() => {
              audioService.speak(
                'اكتب أي كلمة تقابلك في الشارع أو على يافطة، وعم صلاح هيفككها لحروف ويشرحها لك بالصوت.'
              );
            }}
            className="flex items-center gap-1.5 text-xs text-amber-300 hover:text-amber-200 w-fit"
          >
            <Volume2 className="w-4 h-4" />
            <span>استمع للشرح</span>
          </button>
        </div>

        <div className="flex flex-col sm:flex-row gap-3">
          <input
            type="text"
            value={customWordInput}
            onChange={(e) => setCustomWordInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleAnalyzeWord()}
            placeholder="اكتب كلمة هنا (مثال: مستشفى، رمسيس، صيدلية، كهرباء)..."
            className="flex-1 bg-slate-800 border-2 border-slate-700 focus:border-amber-500 rounded-2xl px-4 py-3.5 text-lg font-bold text-white placeholder-slate-400 outline-none transition-all"
          />
          <button
            onClick={handleAnalyzeWord}
            disabled={analyzingWord || !customWordInput.trim()}
            className="px-6 py-3.5 bg-amber-500 hover:bg-amber-600 disabled:opacity-50 text-slate-950 font-black rounded-2xl text-base transition-all flex items-center justify-center gap-2 shadow-md shadow-amber-500/20"
          >
            {analyzingWord ? (
              <RefreshCw className="w-5 h-5 animate-spin" />
            ) : (
              <Sparkles className="w-5 h-5" />
            )}
            <span>حلل الكلمة واشرحها</span>
          </button>
        </div>

        {/* Quick Suggestion Pills */}
        <div className="flex flex-wrap items-center gap-2 pt-1 text-xs">
          <span className="text-slate-400 font-medium">أو جرب هذه الكلمات:</span>
          {['مُسْتَشْفَى', 'صَيْدَلِيَّة', 'مِيكْرُوبَاص', 'تَعْلِيم', 'فَاتُورَة'].map((word) => (
            <button
              key={word}
              onClick={() => {
                setCustomWordInput(word);
              }}
              className="bg-slate-800 hover:bg-slate-700 text-amber-200 px-3 py-1.5 rounded-xl border border-slate-700 transition-colors font-bold"
            >
              {word}
            </button>
          ))}
        </div>

        {/* Result Breakdown Card */}
        {aiExplanation && (
          <div className="bg-slate-800/90 border border-slate-700 rounded-2xl p-5 sm:p-6 space-y-4 animate-in fade-in duration-300">
            <div className="flex items-center justify-between pb-3 border-b border-slate-700">
              <div className="flex items-center gap-3">
                <span className="text-3xl font-black text-amber-400 font-['Alexandria',sans-serif]">
                  {aiExplanation.word}
                </span>
                <span className="text-xs bg-amber-500/20 text-amber-300 font-bold px-2.5 py-1 rounded-lg border border-amber-500/30">
                  تهجئة: {aiExplanation.spelling}
                </span>
              </div>
              <button
                onClick={() => {
                  audioService.speak(
                    `كلمة ${aiExplanation.word}. تتهجى: ${aiExplanation.spelling}. معناها: ${aiExplanation.meaning}. ${aiExplanation.example}. نصيحة عم صلاح: ${aiExplanation.tip}`
                  );
                }}
                className="p-2.5 bg-amber-500 text-slate-950 rounded-xl hover:bg-amber-400 transition-colors"
                title="استمع للشرح كاملاً"
              >
                <Volume2 className="w-5 h-5" />
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
              <div className="bg-slate-900/60 p-4 rounded-xl border border-slate-700/60">
                <span className="text-xs text-amber-400 font-bold block mb-1">المعنى المبسط:</span>
                <p className="text-slate-200 leading-relaxed font-medium">{aiExplanation.meaning}</p>
              </div>
              <div className="bg-slate-900/60 p-4 rounded-xl border border-slate-700/60">
                <span className="text-xs text-amber-400 font-bold block mb-1">استخدامها في مصر:</span>
                <p className="text-slate-200 leading-relaxed font-medium">{aiExplanation.example}</p>
              </div>
            </div>

            {aiExplanation.tip && (
              <div className="p-3 bg-amber-500/10 border border-amber-500/30 rounded-xl flex items-start gap-2.5 text-amber-200 text-xs sm:text-sm">
                <span className="text-lg">💡</span>
                <p className="leading-relaxed font-medium">
                  <b className="text-amber-300 font-bold">نصيحة عم صلاح: </b>
                  {aiExplanation.tip}
                </p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
