import React, { useState, useRef } from 'react';
import { X, Award, Printer, Volume2, Sparkles, Check } from 'lucide-react';
import { audioService } from '../utils/audio';

interface CertificateModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CertificateModal: React.FC<CertificateModalProps> = ({ isOpen, onClose }) => {
  const [recipientName, setRecipientName] = useState<string>('مواطن مصري طموح');
  const certificateRef = useRef<HTMLDivElement | null>(null);

  if (!isOpen) return null;

  const todayArabic = new Intl.DateTimeFormat('ar-EG', {
    dateStyle: 'long',
  }).format(new Date());

  const handlePrint = () => {
    window.print();
  };

  const handleReadCertificate = () => {
    audioService.speak(
      `شهادة تقدير واجتياز. تشهد منصة نور لمحو الأمية في مصر بأن العزيز: ${recipientName}، قد اجتاز بنجاح برنامج تعلم القراءة والكتابة والحساب والمواقف الحياتية، بكل جدارة وعزيمة. مبارك لك هذا النور في مسيرتك!`
    );
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-3xl w-full p-6 sm:p-8 shadow-2xl border-4 border-amber-300 space-y-6 my-8">
        {/* Header Controls */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-200">
          <div className="flex items-center gap-2">
            <Award className="w-6 h-6 text-amber-600" />
            <h3 className="text-lg font-black text-slate-900">شهادة تقدير واجتياز محو الأمية</h3>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-700 bg-slate-100 rounded-xl transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Name Customization Input */}
        <div className="bg-amber-50 p-4 rounded-2xl border border-amber-200 flex flex-col sm:flex-row items-center gap-3">
          <label className="text-xs sm:text-sm font-extrabold text-amber-950 shrink-0">
            اكتب اسمك الذي سيظهر على الشهادة:
          </label>
          <input
            type="text"
            value={recipientName}
            onChange={(e) => setRecipientName(e.target.value)}
            className="flex-1 bg-white border-2 border-amber-300 focus:border-amber-600 rounded-xl px-3 py-2 text-base font-bold text-slate-900 outline-none"
            placeholder="اكتب اسمك هنا..."
          />
        </div>

        {/* The Printable Certificate Design */}
        <div
          ref={certificateRef}
          className="print-section bg-[#fffdfa] border-8 border-double border-amber-600/80 rounded-2xl p-6 sm:p-10 text-center space-y-6 relative overflow-hidden shadow-inner"
        >
          {/* Subtle Corner Ornaments */}
          <div className="absolute top-2 right-2 text-amber-500/20 text-3xl font-serif">❖</div>
          <div className="absolute top-2 left-2 text-amber-500/20 text-3xl font-serif">❖</div>
          <div className="absolute bottom-2 right-2 text-amber-500/20 text-3xl font-serif">❖</div>
          <div className="absolute bottom-2 left-2 text-amber-500/20 text-3xl font-serif">❖</div>

          {/* Top Logo / Eagle Motif */}
          <div className="space-y-1">
            <div className="w-16 h-16 mx-auto rounded-full bg-amber-500 text-white flex items-center justify-center text-3xl shadow-md border-2 border-amber-300">
              🇪🇬
            </div>
            <h4 className="text-xs font-bold text-slate-500 tracking-wider">
              جُمْهُورِيَّةُ مِصْرَ الْعَرَبِيَّة · مَنْصَّةُ نُور لِمَحْوِ الأُمِّيَّة
            </h4>
            <h2 className="text-2xl sm:text-4xl font-black font-['Alexandria',sans-serif] text-amber-950 pt-1">
              شَهَادَةُ تَقْدِيرٍ وَاجْتِيَاز
            </h2>
          </div>

          <p className="text-xs sm:text-sm text-slate-600 font-semibold max-w-lg mx-auto leading-relaxed">
            تَشْهَدُ المَنَصَّةُ بِأَنَّ الدَّارِسَ الكَرِيم:
          </p>

          {/* Student Name */}
          <div className="py-2 border-b-2 border-dashed border-amber-400 max-w-md mx-auto">
            <span className="text-2xl sm:text-4xl font-black text-amber-800 font-['Alexandria',sans-serif]">
              {recipientName || 'طالب العلم النبيل'}
            </span>
          </div>

          <p className="text-sm sm:text-base text-slate-800 font-bold max-w-xl mx-auto leading-relaxed">
            قَدْ أَتَمَّ بِنَجَاحٍ وَجَدَارَةٍ مَرَاحِلَ تَعَلُّمِ الحُرُوفِ العَرَبِيَّةِ، وَتَرْكِيبِ الكَلِمَاتِ، وَقِرَاءَةِ لَافِتَاتِ الحَيَاةِ اليَوْمِيَّةِ، وَحِسَابِ العُمْلَةِ المِصْرِيَّةِ، لِيَفْتَحَ لِنَفْسِهِ بَابَ النُّورِ وَالمَعْرِفَةِ.
          </p>

          {/* Signatures & Seal */}
          <div className="pt-6 grid grid-cols-3 gap-2 items-center text-center text-xs text-slate-600 border-t border-amber-200">
            <div>
              <span className="block font-bold text-slate-900 mb-1">تاريخ الاجتياز</span>
              <span>{todayArabic}</span>
            </div>

            <div className="flex flex-col items-center">
              <div className="w-14 h-14 rounded-full border-2 border-amber-600 bg-amber-50 flex items-center justify-center text-amber-800 text-[10px] font-black shadow-xs transform rotate-[-6deg]">
                ختم التميز
              </div>
            </div>

            <div>
              <span className="block font-bold text-slate-900 mb-1">المعلم والمشرف</span>
              <span className="font-['Alexandria',sans-serif] font-extrabold text-amber-800">
                عم صلاح والمعلمون
              </span>
            </div>
          </div>
        </div>

        {/* Modal Actions */}
        <div className="flex flex-col sm:flex-row gap-3 pt-2">
          <button
            onClick={handleReadCertificate}
            className="flex-1 py-3 px-4 bg-amber-100 hover:bg-amber-200 text-amber-900 font-bold rounded-2xl border border-amber-300 flex items-center justify-center gap-2 text-sm transition-colors"
          >
            <Volume2 className="w-4 h-4" />
            <span>نطق نص الشهادة</span>
          </button>

          <button
            onClick={handlePrint}
            className="flex-1 py-3 px-4 bg-emerald-600 hover:bg-emerald-700 text-white font-black rounded-2xl shadow-md flex items-center justify-center gap-2 text-sm transition-all"
          >
            <Printer className="w-4 h-4" />
            <span>طباعة الشهادة (ورقياً أو PDF)</span>
          </button>
        </div>
      </div>
    </div>
  );
};
