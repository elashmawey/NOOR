import React, { useState } from 'react';
import { Volume2, Coins, Calculator, Check, AlertCircle, Sparkles, ArrowRight } from 'lucide-react';
import { EGYPTIAN_BANKNOTES, EgyptianBanknote } from '../data/literacyData';
import { audioService } from '../utils/audio';

export const NumbersSection: React.FC = () => {
  const [selectedNote, setSelectedNote] = useState<EgyptianBanknote>(EGYPTIAN_BANKNOTES[1]); // 10 EGP
  const [activeNumberTab, setActiveNumberTab] = useState<'notes' | 'digits' | 'calc'>('notes');

  // Interactive Change Game State
  const [walletAmount, setWalletAmount] = useState<number>(50);
  const [costAmount, setCostAmount] = useState<number>(35);
  const [selectedChangeAnswer, setSelectedChangeAnswer] = useState<number | null>(null);
  const [calcResult, setCalcResult] = useState<'correct' | 'wrong' | null>(null);

  const digitsList = [
    { eastern: '٠', western: '0', name: 'صِفْر', desc: 'لاشيء، نقطة البداية' },
    { eastern: '١', western: '1', name: 'وَاحِد', desc: 'واحد صحيح' },
    { eastern: '٢', western: '2', name: 'اثْنَان', desc: 'زوج أو اتنين' },
    { eastern: '٣', western: '3', name: 'ثَلَاثَة', desc: 'تلاتة' },
    { eastern: '٤', western: '4', name: 'أَرْبَعَة', desc: 'أربعة' },
    { eastern: '٥', western: '5', name: 'خَمْسَة', desc: 'خمسة صوابع في الإيد' },
    { eastern: '٦', western: '6', name: 'سِتَّة', desc: 'ستة' },
    { eastern: '٧', western: '7', name: 'سَبْعَة', desc: 'سبعة باصة لفوق' },
    { eastern: '٨', western: '8', name: 'ثَمَانِيَة', desc: 'تمانية باصة لتحت' },
    { eastern: '٩', western: '9', name: 'تِسْعَة', desc: 'تسعة' },
    { eastern: '١٠', western: '10', name: 'عَشَرَة', desc: 'عشرة كاملة' },
    { eastern: '٢٠', western: '20', name: 'عِشْرُون', desc: 'عشرين' },
    { eastern: '٥٠', western: '50', name: 'خَمْسُون', desc: 'خمسين' },
    { eastern: '١٠٠', western: '100', name: 'مِائَة', desc: 'مية' },
  ];

  const handleBanknoteClick = (note: EgyptianBanknote) => {
    setSelectedNote(note);
    audioService.playSound('pop');
    audioService.speak(
      `ورقة ${note.arabicName}. قيمتها ${note.easternDigits} بالرمز الشرقي وتكتب بالإنجليزية ${note.westernDigits}. لونها ${note.colorName}. معالمها: ${note.frontLandmark}. ومن استخداماتها: ${note.commonUses}`
    );
  };

  const checkShoppingChange = (val: number) => {
    setSelectedChangeAnswer(val);
    const correctChange = walletAmount - costAmount;
    if (val === correctChange) {
      setCalcResult('correct');
      audioService.playSound('celebrate');
      audioService.speak(
        `إجابة صحيحة وممتازة! الباقي هو ${correctChange} جنيهاً بالضبط. شاطر ومصحصح في حساب فلوسك!`
      );
    } else {
      setCalcResult('wrong');
      audioService.playSound('wrong');
      audioService.speak(
        `احسبها تاني على مهلك: معاك ${walletAmount} جنيه واشتريت بـ ${costAmount} جنيه، اطرح التكلفة من المبلغ وشوف الباقي كام.`
      );
    }
  };

  return (
    <div className="space-y-8">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-emerald-800 via-teal-900 to-slate-900 rounded-3xl p-6 sm:p-8 text-white shadow-lg relative overflow-hidden">
        <div className="relative z-10 max-w-2xl">
          <div className="inline-flex items-center gap-2 bg-emerald-500/40 text-emerald-100 font-bold px-3 py-1 rounded-full text-xs sm:text-sm border border-emerald-400/40 mb-3">
            <Coins className="w-4 h-4 text-emerald-200" />
            المستوى الثالث: الأرقام والعملات الورقية المصرية وحساب الباقي
          </div>
          <h1 className="text-2xl sm:text-4xl font-black font-['Alexandria',sans-serif] leading-tight mb-2">
            الأرقام والفلوس في السوق والحياة
          </h1>
          <p className="text-emerald-100 text-sm sm:text-base leading-relaxed">
            معرفة الأرقام وفئات الجنيه المصري بتحميك وتخليك واثق في نفسك وأنت بتشتري من البقالة أو بتدفع في المواصلات أو بتحسب الباقي.
          </p>
        </div>
      </div>

      {/* Subtab Selector */}
      <div className="flex flex-wrap items-center gap-2 border-b border-slate-200 pb-3">
        <button
          onClick={() => {
            setActiveNumberTab('notes');
            audioService.speak('قسم العملات الورقية وفئات الجنيه المصري');
          }}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl font-bold text-sm transition-all ${
            activeNumberTab === 'notes'
              ? 'bg-emerald-700 text-white shadow-md'
              : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200'
          }`}
        >
          <Coins className="w-4 h-4" />
          <span>العملات الورقية وفئات الجنيه</span>
        </button>

        <button
          onClick={() => {
            setActiveNumberTab('digits');
            audioService.speak('قسم قراءة الأرقام بالأشكال المشرقية والإنجليزية');
          }}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl font-bold text-sm transition-all ${
            activeNumberTab === 'digits'
              ? 'bg-emerald-700 text-white shadow-md'
              : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200'
          }`}
        >
          <span>🔢</span>
          <span>الأرقام (عربي وإنجليزي)</span>
        </button>

        <button
          onClick={() => {
            setActiveNumberTab('calc');
            audioService.speak('قسم لعبة وتدريب حساب الباقي في السوق');
          }}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl font-bold text-sm transition-all ${
            activeNumberTab === 'calc'
              ? 'bg-emerald-700 text-white shadow-md'
              : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200'
          }`}
        >
          <Calculator className="w-4 h-4" />
          <span>لعبة حساب الباقي في السوق</span>
        </button>
      </div>

      {/* TAB 1: Egyptian Banknotes */}
      {activeNumberTab === 'notes' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900">
              اختر فئة الجنيه لاستعراضها وسماع مواصفاتها:
            </h2>
            <button
              onClick={() => {
                audioService.speak(
                  'فئات العملة المصرية تشمل خمسة جنيهات، عشرة جنيهات، عشرون جنيهاً، خمسون جنيهاً، مائة جنيه، ومائتا جنيه.'
                );
              }}
              className="flex items-center gap-1.5 text-xs sm:text-sm font-bold text-emerald-800 bg-emerald-50 px-3 py-1.5 rounded-xl border border-emerald-200"
            >
              <Volume2 className="w-4 h-4 text-emerald-600" />
              <span>استمع لكل الفئات</span>
            </button>
          </div>

          {/* Grid of Banknotes */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
            {EGYPTIAN_BANKNOTES.map((note) => {
              const isSelected = selectedNote.value === note.value;
              return (
                <div
                  key={note.value}
                  onClick={() => handleBanknoteClick(note)}
                  className={`cursor-pointer rounded-2xl p-4 transition-all border-2 text-center select-none ${
                    isSelected
                      ? 'bg-emerald-900 text-white border-emerald-500 shadow-lg scale-105'
                      : 'bg-white hover:bg-slate-50 text-slate-800 border-slate-200 hover:border-emerald-300'
                  }`}
                >
                  <div
                    className={`h-16 rounded-xl bg-gradient-to-br ${note.frontBg} text-white flex flex-col items-center justify-center p-2 mb-2 shadow-xs`}
                  >
                    <span className="text-lg font-black font-['Alexandria',sans-serif]">
                      {note.easternDigits}
                    </span>
                    <span className="text-[10px] opacity-80 font-mono">{note.westernDigits}</span>
                  </div>
                  <span className="block text-xs font-bold truncate">{note.arabicName}</span>
                </div>
              );
            })}
          </div>

          {/* Detailed Banknote Showcase */}
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-emerald-200 shadow-md">
            <div className="flex flex-col md:flex-row gap-6 items-center">
              {/* Visual Simulated Banknote Card */}
              <div
                className={`w-full md:w-80 h-48 rounded-3xl bg-gradient-to-br ${selectedNote.frontBg} text-white p-5 flex flex-col justify-between shadow-xl relative overflow-hidden`}
              >
                <div className="flex justify-between items-start">
                  <div>
                    <span className="text-[10px] tracking-widest text-emerald-200 block uppercase">
                      البنك المركزي المصري
                    </span>
                    <span className="text-2xl font-black font-['Alexandria',sans-serif]">
                      {selectedNote.easternDigits}
                    </span>
                  </div>
                  <span className="text-xl font-mono font-black">{selectedNote.westernDigits}</span>
                </div>

                <div className="text-center my-auto">
                  <span className="text-xs text-white/80 block">المعلم الأثري المصري</span>
                  <span className="text-sm font-bold text-amber-300">{selectedNote.frontLandmark}</span>
                </div>

                <div className="flex justify-between items-end text-[11px] text-white/70">
                  <span>جمهورية مصر العربية</span>
                  <span>{selectedNote.arabicName}</span>
                </div>
              </div>

              {/* Explanatory Details */}
              <div className="flex-1 space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-2xl font-black text-slate-900">
                    ورقة {selectedNote.arabicName} ({selectedNote.easternDigits})
                  </h3>
                  <button
                    onClick={() => {
                      audioService.speak(
                        `ورقة ${selectedNote.arabicName}. معالمها: ${selectedNote.frontLandmark} على الوجه، و${selectedNote.backLandmark} على الظهر. ولونها ${selectedNote.colorName}. ومن استخداماتها: ${selectedNote.commonUses}`
                      );
                    }}
                    className="p-3 bg-emerald-100 hover:bg-emerald-200 text-emerald-900 rounded-2xl transition-colors border border-emerald-300"
                    title="استمع للشرح"
                  >
                    <Volume2 className="w-5 h-5" />
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
                  <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200">
                    <span className="block text-xs font-bold text-slate-500 mb-0.5">
                      المعلم على الوجه:
                    </span>
                    <span className="font-extrabold text-slate-800">
                      {selectedNote.frontLandmark}
                    </span>
                  </div>
                  <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200">
                    <span className="block text-xs font-bold text-slate-500 mb-0.5">
                      المعلم على الظهر:
                    </span>
                    <span className="font-extrabold text-slate-800">{selectedNote.backLandmark}</span>
                  </div>
                  <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200">
                    <span className="block text-xs font-bold text-slate-500 mb-0.5">
                      اللون المميز:
                    </span>
                    <span className="font-extrabold text-slate-800">{selectedNote.colorName}</span>
                  </div>
                  <div className="bg-emerald-50 p-3.5 rounded-2xl border border-emerald-200">
                    <span className="block text-xs font-bold text-emerald-800 mb-0.5">
                      استخداماتها المعتادة في مصر:
                    </span>
                    <span className="font-extrabold text-emerald-950">
                      {selectedNote.commonUses}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: Digits (Arabic & Western) */}
      {activeNumberTab === 'digits' && (
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-md space-y-6">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h2 className="text-xl sm:text-2xl font-black text-slate-900">
                لوحة الأرقام (المشرقية والإنجليزية)
              </h2>
              <p className="text-sm text-slate-500 mt-1">
                في مصر بنشوف الأرقام المشرقية (٠، ١، ٢) في اليافطات والعدادات، والأرقام الإنجليزية (0, 1, 2) في الموبايل والآلات الحاسبة.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-7 gap-3">
            {digitsList.map((d) => (
              <div
                key={d.western}
                onClick={() => {
                  audioService.playSound('pop');
                  audioService.speak(`رقم ${d.name}. ويكتب هكذا ${d.eastern} أو هكذا ${d.western}.`);
                }}
                className="p-4 bg-slate-50 hover:bg-emerald-50/70 border border-slate-200 hover:border-emerald-300 rounded-2xl text-center cursor-pointer transition-all group"
              >
                <div className="flex items-center justify-center gap-3 mb-1">
                  <span className="text-3xl font-black text-emerald-800 font-['Alexandria',sans-serif]">
                    {d.eastern}
                  </span>
                  <span className="text-slate-300">/</span>
                  <span className="text-2xl font-bold font-mono text-slate-600">{d.western}</span>
                </div>
                <span className="block text-xs font-extrabold text-slate-900">{d.name}</span>
                <span className="block text-[10px] text-slate-400 mt-0.5">{d.desc}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 3: Shopping Change Calculator Game */}
      {activeNumberTab === 'calc' && (
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-emerald-300 shadow-md space-y-6">
          <div className="pb-3 border-b border-slate-100">
            <span className="text-xs bg-emerald-100 text-emerald-800 font-bold px-3 py-1 rounded-full border border-emerald-300">
              تدريب حسابي تفاعلي
            </span>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 mt-2">
              احسب الباقي في السوق والمحل
            </h2>
            <p className="text-sm text-slate-500">
              درب نفسك على معرفة الباقي الصح عشان محدش يغلط في حسابك.
            </p>
          </div>

          {/* Scenario Generator Controls */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-2">
              <label className="text-xs font-bold text-slate-600 block">
                ١. معاك ورقة فئة كام؟
              </label>
              <div className="grid grid-cols-3 gap-2">
                {[20, 50, 100, 200].map((amt) => (
                  <button
                    key={amt}
                    onClick={() => {
                      setWalletAmount(amt);
                      setSelectedChangeAnswer(null);
                      setCalcResult(null);
                      audioService.speak(`معاك ورقة ${amt} جنيه`);
                    }}
                    className={`py-2 px-3 rounded-xl font-bold text-sm border transition-all ${
                      walletAmount === amt
                        ? 'bg-emerald-700 text-white border-emerald-800 shadow-xs'
                        : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-100'
                    }`}
                  >
                    {amt} جنيه
                  </button>
                ))}
              </div>
            </div>

            <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-2">
              <label className="text-xs font-bold text-slate-600 block">
                ٢. حساب المشتريات كام؟
              </label>
              <div className="grid grid-cols-3 gap-2">
                {[15, 35, 65, 80, 120].map((amt) => {
                  if (amt >= walletAmount) return null;
                  return (
                    <button
                      key={amt}
                      onClick={() => {
                        setCostAmount(amt);
                        setSelectedChangeAnswer(null);
                        setCalcResult(null);
                        audioService.speak(`المشتريات بـ ${amt} جنيه`);
                      }}
                      className={`py-2 px-3 rounded-xl font-bold text-sm border transition-all ${
                        costAmount === amt
                          ? 'bg-amber-600 text-white border-amber-700 shadow-xs'
                          : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-100'
                      }`}
                    >
                      {amt} جنيه
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Question Banner */}
          <div className="bg-amber-50 border-2 border-amber-200 p-5 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-4">
            <div>
              <p className="text-lg font-black text-amber-950">
                أعطيت البائع ورقة <span className="text-emerald-700">{walletAmount} جنيه</span>، والحساب{' '}
                <span className="text-amber-800">{costAmount} جنيه</span>.
              </p>
              <p className="text-sm font-semibold text-amber-800 mt-1">
                كم جنيهاً يجب أن يرجع لك الباقي؟
              </p>
            </div>

            <button
              onClick={() => {
                audioService.speak(
                  `معاك ورقة ${walletAmount} جنيه، والحساب ${costAmount} جنيه. المفروض البائع يرجعلك كام باقي؟`
                );
              }}
              className="flex items-center gap-1.5 px-3 py-2 bg-amber-200 hover:bg-amber-300 text-amber-900 font-bold rounded-xl text-xs sm:text-sm border border-amber-300"
            >
              <Volume2 className="w-4 h-4" />
              <span>استمع للسؤال</span>
            </button>
          </div>

          {/* Options to Choose */}
          <div className="space-y-3">
            <span className="text-xs font-bold text-slate-500">اختر الباقي الصحيح:</span>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {(() => {
                const correct = walletAmount - costAmount;
                const choices = Array.from(
                  new Set([correct, correct + 10, Math.max(5, correct - 10), correct + 5])
                ).sort((a, b) => a - b);

                return choices.map((val) => {
                  const isSelected = selectedChangeAnswer === val;
                  return (
                    <button
                      key={val}
                      onClick={() => checkShoppingChange(val)}
                      className={`p-4 rounded-2xl border-2 font-extrabold text-lg sm:text-xl transition-all ${
                        isSelected
                          ? calcResult === 'correct'
                            ? 'bg-emerald-600 text-white border-emerald-700'
                            : 'bg-rose-500 text-white border-rose-600'
                          : 'bg-slate-50 hover:bg-slate-100 text-slate-800 border-slate-300'
                      }`}
                    >
                      {val} جنيهاً
                    </button>
                  );
                });
              })()}
            </div>
          </div>

          {/* Result Alert */}
          {calcResult === 'correct' && (
            <div className="p-4 bg-emerald-50 border border-emerald-300 rounded-2xl flex items-center gap-3 text-emerald-900">
              <Check className="w-6 h-6 text-emerald-600 shrink-0" />
              <div className="text-sm">
                <b className="font-extrabold text-base block">الله ينور عليك يا فنان!</b>
                الحسبة صحيحة: {walletAmount} - {costAmount} = {walletAmount - costAmount} جنيهات.
              </div>
            </div>
          )}

          {calcResult === 'wrong' && (
            <div className="p-4 bg-rose-50 border border-rose-300 rounded-2xl flex items-center gap-3 text-rose-900">
              <AlertCircle className="w-6 h-6 text-rose-600 shrink-0" />
              <div className="text-sm">
                <b className="font-extrabold text-base block">حاول مرة تانية بالراحة</b>
                اطرح ثمن المشتريات من الورقة اللي معاك.
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
