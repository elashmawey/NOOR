/**
 * ElevenLabs Audio Mapping Registry
 * When you generate audio files on ElevenLabs, name them according to these IDs
 * and place them in the `/public/audio/` directory.
 * The app will immediately use them as the primary studio voice!
 */

export interface AudioAsset {
  id: string;
  filename: string;
  arabicScript: string;
  category: 'general' | 'letters' | 'phonics' | 'banknotes' | 'life' | 'praises';
}

export const ELEVENLABS_AUDIO_MAP: Record<string, string> = {
  // Master All-in-One Audio Files (ملف واحد أو ملفين شاملين)
  'noor_master_guide': '/audio/noor_master_guide.mp3',
  'noor_letters_complete': '/audio/noor_letters_complete.mp3',

  // General & Guides
  'welcome_intro': '/audio/welcome_intro.mp3',
  'guide_alphabet': '/audio/guide_alphabet.mp3',
  'guide_phonics': '/audio/guide_phonics.mp3',
  'guide_words': '/audio/guide_words.mp3',
  'guide_numbers': '/audio/guide_numbers.mp3',
  'guide_life': '/audio/guide_life.mp3',
  'guide_canvas': '/audio/guide_canvas.mp3',
  'guide_teacher': '/audio/guide_teacher.mp3',
  'guide_quiz': '/audio/guide_quiz.mp3',

  // Letters (All 28)
  'letter_alif': '/audio/letter_alif.mp3',
  'letter_baa': '/audio/letter_baa.mp3',
  'letter_taa': '/audio/letter_taa.mp3',
  'letter_thaa': '/audio/letter_thaa.mp3',
  'letter_jeem': '/audio/letter_jeem.mp3',
  'letter_haa': '/audio/letter_haa.mp3',
  'letter_khaa': '/audio/letter_khaa.mp3',
  'letter_daal': '/audio/letter_daal.mp3',
  'letter_thaal': '/audio/letter_thaal.mp3',
  'letter_raa': '/audio/letter_raa.mp3',
  'letter_zayn': '/audio/letter_zayn.mp3',
  'letter_seen': '/audio/letter_seen.mp3',
  'letter_sheen': '/audio/letter_sheen.mp3',
  'letter_saad': '/audio/letter_saad.mp3',
  'letter_daad': '/audio/letter_daad.mp3',
  'letter_toaa': '/audio/letter_toaa.mp3',
  'letter_dhaa': '/audio/letter_dhaa.mp3',
  'letter_ayn': '/audio/letter_ayn.mp3',
  'letter_ghayn': '/audio/letter_ghayn.mp3',
  'letter_faa': '/audio/letter_faa.mp3',
  'letter_qaaf': '/audio/letter_qaaf.mp3',
  'letter_kaaf': '/audio/letter_kaaf.mp3',
  'letter_laam': '/audio/letter_laam.mp3',
  'letter_meem': '/audio/letter_meem.mp3',
  'letter_noon': '/audio/letter_noon.mp3',
  'letter_haa_soft': '/audio/letter_haa_soft.mp3',
  'letter_waaw': '/audio/letter_waaw.mp3',
  'letter_yaa': '/audio/letter_yaa.mp3',

  // Phonics Secrets & Similar Letters
  'phonics_dots_family': '/audio/phonics_dots_family.mp3',
  'phonics_sin_saad': '/audio/phonics_sin_saad.mp3',
  'phonics_dal_daad': '/audio/phonics_dal_daad.mp3',
  'phonics_taa_toaa': '/audio/phonics_taa_toaa.mp3',
  'lam_shamsiya': '/audio/lam_shamsiya.mp3',
  'lam_qamariya': '/audio/lam_qamariya.mp3',

  // Banknotes
  'note_5': '/audio/note_5.mp3',
  'note_10': '/audio/note_10.mp3',
  'note_20': '/audio/note_20.mp3',
  'note_50': '/audio/note_50.mp3',
  'note_100': '/audio/note_100.mp3',
  'note_200': '/audio/note_200.mp3',

  // Life Scenarios
  'scenario_metro': '/audio/scenario_metro.mp3',
  'scenario_microbus': '/audio/scenario_microbus.mp3',
  'scenario_pharmacy': '/audio/scenario_pharmacy.mp3',
  'scenario_national_id': '/audio/scenario_national_id.mp3',
  'scenario_vodafone': '/audio/scenario_vodafone.mp3',

  // Praises & Cheers
  'cheer_1': '/audio/cheer_1.mp3',
  'cheer_2': '/audio/cheer_2.mp3',
  'cheer_3': '/audio/cheer_3.mp3',
  'retry_1': '/audio/retry_1.mp3',
  'retry_2': '/audio/retry_2.mp3',
  'certificate_recitation': '/audio/certificate_recitation.mp3',
};
