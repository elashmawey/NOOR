/**
 * Advanced Audio and Egyptian Colloquial Speech System
 * Combines server-side Gemini 3.8 Flash Lite TTS for human-grade Egyptian Arabic
 * with instant client-side Web Speech API + Web Audio sound effects.
 */

import { ELEVENLABS_AUDIO_MAP } from './audioRegistry';
import { egyptianizeText } from './egyptianPhonetics';

export type AudioMode = 'free' | 'hybrid';

interface AudioManifest {
  version: number;
  voices: Record<string, Record<string, string>>;
}

let manifestPromise: Promise<AudioManifest> | null = null;
function getManifest(): Promise<AudioManifest> {
  if (!manifestPromise) {
    manifestPromise = fetch('/audio/manifest.json')
      .then(async (res) => (res.ok ? await res.json() : { version: 1, voices: {} }))
      .catch(() => ({ version: 1, voices: {} }));
  }
  return manifestPromise;
}

const normalizeArabicText = (t: string) => t.normalize('NFC').trim().replace(/\s+/g, ' ');

class AudioService {
  private speechRequest: number = 0;
  private synth: SpeechSynthesis | null = null;
  private audioCtx: AudioContext | null = null;
  public speechRate: number = 0.85; // Natural and articulate for adult learners
  public isAudioEnabled: boolean = true;
  public voicePreference: 'salah' | 'eman' = 'salah'; // 'salah' (male - Puck) or 'eman' (female - Kore)
  public audioMode: AudioMode = 'hybrid'; // Primary: authentic Egyptian studio voice with instant caching!
  private currentAudioElement: HTMLAudioElement | null = null;
  private audioCache = new Map<string, string>(); // In-memory cache for audio Data URLs
  public isPlaying: boolean = false;
  private onStateChangeListeners: Array<(isPlaying: boolean) => void> = [];

  constructor() {
    if (typeof window !== 'undefined') {
      if ('speechSynthesis' in window) {
        this.synth = window.speechSynthesis;
      }
      try {
        const savedVoice = localStorage.getItem('noor_voice_preference');
        if (savedVoice === 'salah' || savedVoice === 'eman') {
          this.voicePreference = savedVoice;
        }
        const savedRate = localStorage.getItem('noor_speech_rate');
        if (savedRate) {
          this.speechRate = parseFloat(savedRate);
        }
      } catch {}
    }
  }

  public setAudioMode(mode: AudioMode) {
    this.audioMode = mode;
    try {
      localStorage.setItem('noor_audio_mode', mode);
    } catch {}
  }

  public setVoicePreference(pref: 'salah' | 'eman') {
    this.voicePreference = pref;
    try {
      localStorage.setItem('noor_voice_preference', pref);
    } catch {}
  }

  /**
   * Play pre-recorded ElevenLabs studio audio by ID, falling back to speech synthesis if file not present
   */
  public playAudioId(audioId: string, fallbackText: string, onEnd?: () => void) {
    if (!this.isAudioEnabled) {
      if (onEnd) onEnd();
      return;
    }

    const audioUrl = ELEVENLABS_AUDIO_MAP[audioId];
    if (!audioUrl) {
      this.speak(fallbackText, onEnd);
      return;
    }

    this.stop();
    this.notifyState(true);

    try {
      const audio = new Audio(audioUrl);
      this.currentAudioElement = audio;

      audio.onended = () => {
        this.currentAudioElement = null;
        this.notifyState(false);
        if (onEnd) onEnd();
      };

      audio.onerror = () => {
        this.currentAudioElement = null;
        this.speak(fallbackText, onEnd);
      };

      const playPromise = audio.play();
      if (playPromise) {
        playPromise.catch(() => {
          this.speak(fallbackText, onEnd);
        });
      }
    } catch {
      this.speak(fallbackText, onEnd);
    }
  }

  public subscribeState(listener: (isPlaying: boolean) => void) {
    this.onStateChangeListeners.push(listener);
    return () => {
      this.onStateChangeListeners = this.onStateChangeListeners.filter((l) => l !== listener);
    };
  }

  private notifyState(playing: boolean) {
    this.isPlaying = playing;
    this.onStateChangeListeners.forEach((l) => l(playing));
  }

  private getAudioContext(): AudioContext | null {
    if (typeof window === 'undefined') return null;
    if (!this.audioCtx) {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioContextClass) {
        this.audioCtx = new AudioContextClass();
      }
    }
    if (this.audioCtx && this.audioCtx.state === 'suspended') {
      this.audioCtx.resume();
    }
    return this.audioCtx;
  }

  /**
   * Stop any ongoing speech or audio
   */
  public stop() {
    this.speechRequest += 1;
    if (this.currentAudioElement) {
      this.currentAudioElement.pause();
      this.currentAudioElement.currentTime = 0;
      this.currentAudioElement = null;
    }
    if (this.synth) {
      this.synth.cancel();
    }
    this.notifyState(false);
  }

  /**
   * Speak authentic Egyptian Arabic with highest fidelity.
   * Checks manifest -> Memory Cache -> Browser CacheStorage -> Server TTS Proxy -> Client Fallback.
   */
  public async speak(text: string, onEnd?: () => void, _useColloquialScript: boolean = true) {
    if (!this.isAudioEnabled) {
      if (onEnd) onEnd();
      return;
    }

    const cleanText = normalizeArabicText(text);
    if (!cleanText) {
      if (onEnd) onEnd();
      return;
    }

    this.stop();
    const requestId = this.speechRequest;
    this.notifyState(true);

    // 1. Check pre-cached audio manifest
    try {
      const manifest = await getManifest();
      if (requestId !== this.speechRequest) return;
      const manifestUrl = manifest.voices[this.voicePreference]?.[cleanText];
      if (manifestUrl) {
        this.playAudioSource(manifestUrl, onEnd, cleanText);
        return;
      }
    } catch {}

    const voiceName = this.voicePreference === 'salah' ? 'Puck' : 'Kore';
    const cacheKey = `${voiceName}_${cleanText}`;
    const storageKey = `/__noor-voice/${encodeURIComponent(cacheKey)}`;

    // 2. Check in-memory audio cache
    const memCached = this.audioCache.get(cacheKey);
    if (memCached) {
      this.playAudioSource(memCached, onEnd, cleanText);
      return;
    }

    // 3. Check persistent Browser CacheStorage ('noor-egyptian-voice-v1')
    try {
      if (typeof window !== 'undefined' && 'caches' in window) {
        const cache = await caches.open('noor-egyptian-voice-v1');
        const match = await cache.match(storageKey);
        if (requestId !== this.speechRequest) return;
        if (match) {
          const cachedData = await match.text();
          this.audioCache.set(cacheKey, cachedData);
          this.playAudioSource(cachedData, onEnd, cleanText);
          return;
        }
      }
    } catch {}

    // 4. Fetch from Server Egyptian TTS Proxy
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 12000);

    try {
      const res = await fetch('/api/voice/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: cleanText,
          voiceName: voiceName,
        }),
        signal: controller.signal,
      });
      clearTimeout(timeoutId);

      if (requestId !== this.speechRequest) return;

      if (res.ok) {
        const data = await res.json();
        if (data.audioBase64) {
          const audioSrc = `data:${data.format || 'audio/wav'};base64,${data.audioBase64}`;
          this.audioCache.set(cacheKey, audioSrc);

          // Store in CacheStorage for instant offline re-use
          try {
            if (typeof window !== 'undefined' && 'caches' in window) {
              const cache = await caches.open('noor-egyptian-voice-v1');
              await cache.put(storageKey, new Response(audioSrc));
            }
          } catch {}

          this.playAudioSource(audioSrc, onEnd, cleanText);
          return;
        }
      }
    } catch (e) {
      // Network timeout or error
    } finally {
      clearTimeout(timeoutId);
    }

    // 5. Fallback if completely offline or unreachable
    if (requestId === this.speechRequest) {
      this.speakClientFallback(cleanText, onEnd);
    }
  }

  private playAudioSource(src: string, onEnd?: () => void, fallbackText?: string) {
    try {
      const audio = new Audio(src);
      this.currentAudioElement = audio;

      audio.onended = () => {
        this.currentAudioElement = null;
        this.notifyState(false);
        if (onEnd) onEnd();
      };

      audio.onerror = () => {
        this.currentAudioElement = null;
        if (fallbackText) {
          this.speakClientFallback(fallbackText, onEnd);
        } else {
          this.notifyState(false);
          if (onEnd) onEnd();
        }
      };

      const playPromise = audio.play();
      if (playPromise) {
        playPromise.catch(() => {
          if (fallbackText) {
            this.speakClientFallback(fallbackText, onEnd);
          } else {
            this.notifyState(false);
            if (onEnd) onEnd();
          }
        });
      }
    } catch (err) {
      if (fallbackText) {
        this.speakClientFallback(fallbackText, onEnd);
      } else {
        this.notifyState(false);
        if (onEnd) onEnd();
      }
    }
  }

  /**
   * Browser SpeechSynthesis fallback with Egyptian accent optimization
   */
  private speakClientFallback(text: string, onEnd?: () => void) {
    if (!this.synth) {
      this.notifyState(false);
      if (onEnd) onEnd();
      return;
    }

    try {
      this.synth.cancel();

      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = this.speechRate;
      utterance.pitch = this.voicePreference === 'salah' ? 0.95 : 1.1;
      utterance.lang = 'ar-EG'; // Egyptian Arabic priority

      const voices = this.synth.getVoices();
      const egyptianVoice =
        voices.find((v) => v.lang.toLowerCase().includes('ar-eg')) ||
        voices.find((v) => v.lang.toLowerCase().startsWith('ar')) ||
        voices.find((v) => v.name.toLowerCase().includes('arabic') || v.name.includes('عربي'));

      if (egyptianVoice) {
        utterance.voice = egyptianVoice;
      }

      utterance.onend = () => {
        this.notifyState(false);
        if (onEnd) onEnd();
      };

      utterance.onerror = () => {
        this.notifyState(false);
        if (onEnd) onEnd();
      };

      this.synth.speak(utterance);
    } catch (e) {
      this.notifyState(false);
      if (onEnd) onEnd();
    }
  }

  public setSpeechRate(rate: number) {
    this.speechRate = Math.max(0.6, Math.min(1.4, rate));
    try {
      localStorage.setItem('noor_speech_rate', rate.toString());
    } catch {}
  }

  /**
   * Test and showcase the 100% free Egyptian voice
   */
  public testVoice() {
    this.playSound('pop');
    const testText =
      this.voicePreference === 'salah'
        ? 'أهلاً بيك يا غالي! معاك عم صلاح، بصوت مصري دافئ ومجاني تماماً بدون أي استهلاك للرصيد!'
        : 'أهلاً بحضرتك! معاك مس إيمان، الصوت شغال معاك مجاناً وبكل وضوح على موبايلك!';
    this.speak(testText);
  }

  /**
   * Play cheering encouragement in authentic Egyptian phrasing
   */
  public cheerSuccess(customWord?: string) {
    this.playSound('celebrate');
    const praises = [
      customWord ? `الله ينور عليك يا بطل! قرأت كلمة ${customWord} مية مية!` : 'الله ينور عليك يا بطل! إجابة صح وعظمة!',
      'تسلم إيدك وعينك! خطوة بخطوة وهتبقى أستاذ كبير!',
      'يا سيدي على الشطارة! القراءة سهلة لما تفهمها بالراحة!',
      'عاش يا غالي! ربنا يفتح عليك ويزيدك نور وعلم!',
      'جدع وممتاز! مجهودك يرفع الرأس ويشرف!',
    ];
    const picked = praises[Math.floor(Math.random() * praises.length)];
    this.speak(picked);
  }

  /**
   * Play gentle encouragement on mistake in authentic Egyptian phrasing
   */
  public encourageRetry() {
    this.playSound('wrong');
    const encouragements = [
      'ولا يهمك يا غالي، الغلط بيعلم، بص على الحرف وكرر معايا بالراحة.',
      'قربت جداً! خد نفس عميق وجرب تركز في شكل الحرف ونطقه.',
      'بالراحة خالص، محدش بيجري ورانا، التعليم بيحب الصبر والتكرار.',
      'شاطر في المحاولة! بص تاني على النقطة بتاعة الحرف وجرب.',
    ];
    const picked = encouragements[Math.floor(Math.random() * encouragements.length)];
    this.speak(picked);
  }

  /**
   * Play Web Audio Chimes
   */
  public playSound(type: 'correct' | 'wrong' | 'celebrate' | 'click' | 'pop') {
    try {
      const ctx = this.getAudioContext();
      if (!ctx) return;

      const now = ctx.currentTime;

      if (type === 'correct') {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(523.25, now); // C5
        osc.frequency.setValueAtTime(783.99, now + 0.12); // G5
        gain.gain.setValueAtTime(0.2, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.45);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now);
        osc.stop(now + 0.45);
      } else if (type === 'celebrate') {
        [523.25, 659.25, 783.99, 1046.5].forEach((freq, i) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = 'sine';
          osc.frequency.setValueAtTime(freq, now + i * 0.1);
          gain.gain.setValueAtTime(0.25, now + i * 0.1);
          gain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.1 + 0.5);
          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.start(now + i * 0.1);
          osc.stop(now + i * 0.1 + 0.5);
        });
      } else if (type === 'wrong') {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(220, now);
        osc.frequency.setValueAtTime(196, now + 0.15);
        gain.gain.setValueAtTime(0.12, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now);
        osc.stop(now + 0.35);
      } else if (type === 'click') {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(800, now);
        gain.gain.setValueAtTime(0.08, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.08);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now);
        osc.stop(now + 0.08);
      } else if (type === 'pop') {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(400, now);
        osc.frequency.exponentialRampToValueAtTime(880, now + 0.09);
        gain.gain.setValueAtTime(0.15, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.12);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now);
        osc.stop(now + 0.12);
      }
    } catch (e) {
      console.warn('Web Audio error:', e);
    }
  }
}

export const audioService = new AudioService();
