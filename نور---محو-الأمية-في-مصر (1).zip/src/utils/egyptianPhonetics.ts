/**
 * Egyptian Colloquial Phonetic Transformer (محوّل النطق الصوتي المصري)
 * Transforms standard or unvocalized Arabic text into phonetically diacritized
 * Egyptian colloquial Arabic optimized for client-side SpeechSynthesis engines.
 * This guarantees 100% FREE, OFFLINE, and natural Egyptian cadence with ZERO API costs.
 */

// Common Egyptian colloquial substitutions with full diacritics
const EGYPTIAN_DICTIONARY: Record<string, string> = {
  // Demonstratives & Pronouns
  'هذا': 'دَهْ',
  'هذه': 'دِي',
  'هؤلاء': 'دُولْ',
  'هنا': 'هِنَا',
  'هناك': 'هِنَاكْ',
  'الآن': 'دِلْوَقْتِي',
  'أيضاً': 'كَمَانْ',
  'جداً': 'قَوِي',
  'لماذا': 'لِيهْ',
  'كيف': 'إِزَّايْ',
  'أين': 'فِينْ',
  'متى': 'إِمْتَى',
  'نعم': 'أَيْوَهْ',
  'لا': 'لَأْ',
  'فقط': 'بَسْ',
  'كثيراً': 'كْتِيرْ',
  'قليلاً': 'شُوَيَّةْ صُغَيَّرِينْ',

  // Welcomes & Greetings
  'أهلاً بك': 'أَهْلاً بِيكْ يَا غَالِي',
  'أهلاً بكم': 'أَهْلاً بِيكُمْ يَا حَبَايِبْنَا',
  'مرحباً': 'يَا هَلَا وَمَرْحَبْ',
  'شكراً لك': 'تِسْلَمْ وَرَبِّنَا يْخَلِّيكْ',
  'شكراً': 'أَلْفِ شُكْرْ',
  'مع السلامة': 'مَعَ أَلْفِ سَلَامَةْ وَنَوَّرْتِنَا',

  // Encouragements
  'أحسنت': 'شَاطِرْ وَاللَّهْ يْنَوَّرْ عَلِيكْ',
  'ممتاز': 'مُمْتَازْ وَعَظَمَةْ عَلَى عَظَمَةْ',
  'رائع': 'عَاشْ يَا بَطَلْ',
  'صحيح': 'إِجَابَةْ صَحْ مِيَّةْ فِيلْ مِيَّةْ',
  'خطأ': 'وَلَا يْهِمَّكْ، جَرَّبْ تَانِي بِالرَّاحَةْ',
  'حاول مرة أخرى': 'حَاوِلْ تَانِي عَلَى مَهْلَكْ، التَّكْرَارْ بِيْعَلِّمْ الشُّطَّارْ',

  // Educational keywords
  'حرف': 'حَرْفِ',
  'الحروف': 'الْحُرُوفْ',
  'كلمة': 'كِلْمَةْ',
  'الكلمات': 'الْكَلِمَاتْ',
  'اقرأ': 'اِقْرَأْ مَعَايَا',
  'اكتب': 'اِكْتِبْ بِإِيدَكْ',
  'اسمع': 'اِسْمَعْ كُوَيِّسْ',
  'انطق': 'اِنْطَقْ وَرَايَا',
  'فتحة': 'فَتْحَةْ فُوقْ (اِفْتَحْ بَقَّكْ)',
  'ضمة': 'ضَمَّةْ (ضُمِّ شَفَايْفَكْ)',
  'كسرة': 'كَسْرَةْ تَحْتْ (اِبْتَسِمْ وَاكْسِرْ)',
  'سكون': 'سُكُونْ (اِقِفْ عَلَى الْحَرْفْ)',

  // Numbers & Money
  'جنيه': 'جِنِيهْ',
  'جنيهات': 'جِنِيهْ',
  'جنيهاً': 'جِنِيهْ',
  'فكة': 'فَكَّةْ',
  'باقي': 'الْبَاقِي',
  'فلوس': 'فِلُوسْ',
  'سوق': 'السُّوقْ',
  'شراء': 'شِرَا',
  'بيع': 'بِيعْ',
  'محطة': 'مَحَطَّةْ',
  'ميكروباص': 'مِيكْرُوبَاصْ',
  'مترو': 'الْمِتْرُو',
  'عربية': 'عَرَبِيَّةْ',
  'دواء': 'عِلَاجْ وَدَوَا',
  'صيدلية': 'صَيْدَلِيَّةْ (الأَجْزَخَانَةْ)',
  'تموين': 'تَمْوِينْ وَعَيْشْ بَلَدِي',
  'كهرباء': 'كَهْرَبَا',
  'عداد': 'عَدَّادْ',
};

/**
 * Phonetically tunes Arabic text for natural Egyptian cadence on client device TTS
 */
export function egyptianizeText(rawText: string): string {
  if (!rawText) return '';

  let processed = rawText.trim();

  // Replace common whole words/phrases using our Egyptian dictionary
  for (const [standard, colloquial] of Object.entries(EGYPTIAN_DICTIONARY)) {
    const regex = new RegExp(`\\b${standard}\\b`, 'g');
    processed = processed.replace(regex, colloquial);
  }

  // Replace Eastern digits with spoken Egyptian Arabic words when isolated
  processed = processed
    .replace(/\b1\b|١/g, ' وَاحِدْ ')
    .replace(/\b2\b|٢/g, ' اِتْنِينْ ')
    .replace(/\b3\b|٣/g, ' تَلَاتَةْ ')
    .replace(/\b4\b|٤/g, ' أَرْبَعَةْ ')
    .replace(/\b5\b|٥/g, ' خَمْسَةْ ')
    .replace(/\b6\b|٦/g, ' سِتَّةْ ')
    .replace(/\b7\b|٧/g, ' سَبْعَةْ ')
    .replace(/\b8\b|٨/g, ' تَمَانْيَةْ ')
    .replace(/\b9\b|٩/g, ' تِسْعَةْ ')
    .replace(/\b10\b|١٠/g, ' عَشَرَةْ ')
    .replace(/\b20\b|٢٠/g, ' عِشْرِينْ ')
    .replace(/\b50\b|٥٠/g, ' خَمْسِينْ ')
    .replace(/\b100\b|١٠٠/g, ' مِيَّةْ ')
    .replace(/\b200\b|٢٠٠/g, ' مِيتِينْ ');

  // Clean double spaces
  processed = processed.replace(/\s+/g, ' ').trim();

  return processed;
}
